/**
 * Natural sort
 * @link https://blog.praveen.science/natural-sorting-in-javascript/#humansortversion
 */
function compare(a, b) {
  const cmp = s => (isNaN(parseInt(s,10))) ? s : parseInt(s,10);
  const aa = a.split(/(\d+)/), bb = b.split(/(\d+)/);
  for(let x = 0; x < Math.max(aa.length, bb.length); x++) {
    if(aa[x] !== bb[x]) {
      const cmp1 = cmp(aa[x]), cmp2 = cmp(bb[x]);
      return (cmp1 === undefined || cmp2 === undefined)
        ? aa.length - bb.length : ((cmp1 < cmp2) ? -1 : 1);
    }
  }
  return 0;
}

/*const arr = Array.from({length: 20}, (it, i) => {
  return {region: `Регион ${++i}`};
});

const sortedArr = arr.sort((a, b) => {
  return compare(a.region, b.region);
});

console.log(JSON.stringify(sortedArr.map(it => it.region)));*/


















