import { Injectable } from '@angular/core';
import {TasksService} from '@app/services/tasks.service';
import {LoadingService} from '@app/services/loading.service';
import {MatDialog} from '@angular/material';
import {PromptDialogComponent} from '@app/components/dialogs/prompt-dialog/prompt-dialog.component';
import {City, Client, MachineModel, MachineType} from '@app/models';
import {from, Observable} from 'rxjs';
import {ClientFormDialogComponent} from '@app/components/dialogs/client-form-dialog/client-form-dialog.component';

@Injectable({
  providedIn: 'root'
})
export class ClassifierEditorService {

  constructor(
    private tasksService: TasksService,
    private loading: LoadingService,
    private dialog: MatDialog
  ) { }

  addCity(value): Observable<City> {
    return new Observable(subscriber => {
      PromptDialogComponent.openAsDialog(this.dialog, {value})
        .afterClosed().subscribe(value => {
          if(value) {
            this.loading.show();
            City.create(this.tasksService, value).subscribe(city => {
              subscriber.next(city);
              subscriber.complete();
              this.loading.hide();
            });
          }
        });
    });
  }

  addClient(description: string): Observable<Client> {
    return from(new Promise(resolve => {
      ClientFormDialogComponent.openAsDialog(this.dialog, {description})
        .afterClosed().subscribe(client => {
          if(client) resolve(client);
        });
    }));
  }

  editClient(client: Client): Observable<Client> {
    return from(new Promise(resolve => {
      ClientFormDialogComponent.openAsDialog(this.dialog, {client})
        .afterClosed().subscribe(client => {
          if(client) resolve(client);
        });
    }));
  }

  addMachineModel(value): Observable<MachineModel> {
    return from(new Promise(resolve => {
      PromptDialogComponent.openAsDialog(this.dialog, {value})
        .afterClosed().subscribe(value => {
          if(value) {
            this.loading.show();
            MachineModel.create(this.tasksService, value).subscribe(machineModel => {
              this.loading.hide();
              resolve(machineModel);
            });
          }
        });
    }));
  }
}
