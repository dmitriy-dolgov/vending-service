import {Injectable} from '@angular/core';
import {BehaviorSubject, forkJoin, from, Observable, of, throwError} from 'rxjs';
import {debounceTime, filter, map, switchMap, take} from 'rxjs/operators';

import {
  AngularFireDatabase,
  AngularFireList,
  AngularFireObject,
  PathReference,
  QueryFn,
  SnapshotAction
} from '@angular/fire/database';

import {
  ActionType, City, Client, ClientStatuses, Division, Machine, MachineModel, MachineState, MachineType,
  Model, OperationType, Region, Task, TaskState, TaskStateTypes, User
} from '@app/models';
import {AngularFireStorage} from '@angular/fire/storage';
import {DataSnapshot} from '@angular/fire/database/interfaces';
import {ClientStatus} from '@app/interfaces';

class Collection<T extends Model> {

  items: T[] = [];

  get name(): string {
    return this._name;
  }

  constructor(
    private _name: string,
    private model: { new (tasksService: TasksService, collectionName: string): T; },
    private tasksService: TasksService,
    private _filter?: (it: T) => boolean
  ) {
  }

  addItem(data: any, pkName: string = 'iD', pkAlgoritmNumeric: boolean = true): Observable<T> {

    let newPrimaryKey: number|string;

    if(pkAlgoritmNumeric) {
      const keys = this.items.map(m => Number(m[pkName])).sort((a, b) => a - b);
      newPrimaryKey = (keys.length ? keys.pop() : 0) + 1;
    } else {
      newPrimaryKey = this.tasksService.db.createPushId();
    }

    return from(new Promise((resolve, reject) => {
      const createItem = (newPrimaryKey) => {
        // @docs https://firebase.google.com/docs/reference/js/firebase.database.Reference.html#transaction
        this.tasksService.db.database.ref(`/${this._name}/${newPrimaryKey}`).transaction(
          (current: any|null) => {
            if(current) {
              createItem(pkAlgoritmNumeric ? ++newPrimaryKey : this.tasksService.db.createPushId());
            } else {
              return {[pkName]: newPrimaryKey, ...data};
            }
          }, (error: Error, committed: boolean, snapshot: DataSnapshot) => {
            if(error) {
              reject(error.message);
            } else if(!committed) {
            } else {
              resolve(this.buildModel(snapshot.val()));
            }
          }
        );
      };

      createItem(newPrimaryKey);

    }));
  }

  buildModel(data: T) {
    return Object.assign(new this.model(this.tasksService, this.name), data);
  }

  valueChanges(): Observable<T[]> {
    return this.fireList().valueChanges().pipe(map(items => {
      return this.filter(items).map(it => this.buildModel(it));
    }));
  }

  stateChanges(): Observable<SnapshotAction<T>> {
    return this.fireList().stateChanges();
  }

  fireList(queryFn?: QueryFn):AngularFireList<T> {
    return this.tasksService.fireList<T>(this._name, queryFn);
  }

  private filter(items: T[]): T[] {
    return  this._filter ? items.filter(this._filter) : items;
  }
}

@Injectable({
  providedIn: 'root'
})
export class TasksService {

  private _taskStates: TaskState[] = [
    new TaskState(TaskStateTypes.CREATED, 'Создано'),
    new TaskState(TaskStateTypes.PERFORMED, 'Выполняется'),
    new TaskState(TaskStateTypes.FINISHED, 'Завершено'),
    new TaskState(TaskStateTypes.REMOVED, 'Удалено'),
  ];

  private _clientStatuses: ClientStatus[] = [
    {id: ClientStatuses.STANDARD, title: 'Стандартный'},
    {id: ClientStatuses.SIGNIFICANT, title: 'Значимый'},
    {id: ClientStatuses.CRUCIAL, title: 'Ключевой'},
  ];

  private _collections: Collection<any>[] = [
    new Collection<Machine>('machines', Machine, this),
    new Collection<MachineState>('machineStates', MachineState, this),
    new Collection<MachineType>('machineTypes', MachineType, this),
    new Collection<MachineModel>('machineModels', MachineModel, this),
    new Collection<OperationType>('operationTypes', OperationType, this),
    new Collection<Division>('divisions', Division, this),
    new Collection<Client>('clients', Client, this),
    new Collection<City>('cities', City, this),
    new Collection<Region>('regions', Region, this),
    new Collection<User>('users', User, this)
  ];

  private readonly _tasksCollection = new Collection<Task>('tasks', Task, this);

  private readonly _tasksSubject = new BehaviorSubject<Task[]>([]);
  private readonly _tasks$ = this._tasksSubject.asObservable().pipe(filter(t => !!t), debounceTime(200));
  private _readySubject = new BehaviorSubject<boolean>(false);
  private readonly _ready$ = this._readySubject.asObservable();

  get db(): AngularFireDatabase {
    return this._db;
  }

  get storage(): AngularFireStorage {
    return this._storage;
  }

  get ready(): Observable<boolean> {
    return this._ready$;
  }

  get tasks(): Observable<Task[]> {
    return this._tasks$;
  }

  get taskStates(): TaskState[] {
    return this._taskStates;
  }

  get clientStatuses(): ClientStatus[] {
    return this._clientStatuses;
  }

  get machines(): Machine[] {
    return this.getCollection<Machine>('machines').items.sort((m1, m2) => {
      return m1.description == m2.description ? 0 : (m1.description > m2.description ? 1 : -1);
    });
  }

  get machineStates(): MachineState[] {
    return this.getCollection<MachineState>('machineStates').items;
  }

  get machineTypes(): MachineType[] {
    return this.getCollection<MachineType>('machineTypes').items;
  }

  get machineModels(): MachineModel[] {
    return this.getCollection<MachineModel>('machineModels').items;
  }

  get operationTypes(): OperationType[] {
    return this.getCollection<OperationType>('operationTypes').items;
  }

  get divisions(): Division[] {
    return this.getCollection<Division>('divisions').items.sort((d1, d2) => {
      return d1.description == d2.description ? 0 : (d1.description > d2.description ? 1 : -1);
    });
  }

  get clients(): Client[] {
    return this.getCollection<Client>('clients').items.sort((c1, c2) => {
      return c1.description == c2.description ? 0 : (c1.description > c2.description ? 1 : -1);
    });
  }

  get cities(): City[] {
    return this.getCollection<City>('cities').items.sort((c1, c2) => {
      return c1.description == c2.description ? 0 : (c1.description > c2.description ? 1 : -1);
    });
  }

  get regions(): Region[] {
    return this.getCollection<Region>('regions').items.sort((r1, r2) => {
      return r1.description == r2.description ? 0 : (r1.description > r2.description ? 1 : -1);
    });
  }

  get users(): User[] {
    return this.getCollection<User>('users').items;
  }

  constructor(private _db: AngularFireDatabase, private _storage: AngularFireStorage) {

    const collections = this._collections.concat(this._tasksCollection);

    forkJoin(collections.map(collection => collection.valueChanges().pipe(take(1))))
      .subscribe(results => {

        results.forEach((items, i) => collections[i].items = items.filter(it => it && it.uid));

        this._tasksCollection.valueChanges().subscribe(tasks => {
          this._tasksCollection.items = tasks.filter(task => task && task.uid);
          this._tasksSubject.next(this._tasksCollection.items);
        });

        this._collections.forEach(collection => {

          collection.stateChanges().subscribe(action => {

            const currentItem = collection.items.find(t => t.uid.toString() === action.key.toString());
            const targetItem = collection.buildModel(action.payload.val());

            switch (action.type) {
              case ActionType.CHANGED:
                collection.items.splice(collection.items.indexOf(currentItem), 1, targetItem);
                break;
              case ActionType.REMOVED:
                collection.items.splice(collection.items.indexOf(currentItem), 1);
                break;
              case ActionType.ADDED:
                if (!currentItem) collection.items.push(targetItem);
                break;
            }

          });

        });

        this._tasksSubject.next(this._tasksCollection.items);
        this._readySubject.next(true);

      });
  }

  getCollection<T extends Model>(name):Collection<T> {
    return this._collections.find(c => c.name == name);
  }

  getList<T extends Model>(
    model: { new (tasksService: TasksService, collectionName: string): T; },
    path: PathReference,
    queryFn?: QueryFn,
    collectionName?: string
  ): Observable<T[]> {
    return this.fireList<T>(path, queryFn).valueChanges().pipe(
      map(items => items.map(item => Object.assign(new model(this, collectionName), item)))
    );
  }

  fireList<T extends Model>(path: PathReference, queryFn?: QueryFn):AngularFireList<T> {
    return this._db.list<T>(path, queryFn);
  }

  getObject<T extends Model>(storagePath: PathReference): Observable<T> {
    return this.db.object<T>(storagePath).valueChanges();
  }

  getTask(taskUID: string): Observable<Task|null> {
    return this.getObject<Task>(`/tasks/${taskUID}`).pipe(switchMap(task => {
      return task ? of(Object.assign(new Task(this), task)) : throwError(new Error(`Task ${taskUID} not exists!`));
    }));
  }

  fireObject<T extends Model>(path: PathReference, queryFn?: QueryFn):AngularFireObject<T> {
    return this._db.object<T>(path);
  }
}
