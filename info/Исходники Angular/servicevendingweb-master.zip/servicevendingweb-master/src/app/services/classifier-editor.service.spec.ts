import { TestBed } from '@angular/core/testing';

import { ClassifierEditorService } from './classifier-editor.service';

describe('ClassifierEditorService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ClassifierEditorService = TestBed.get(ClassifierEditorService);
    expect(service).toBeTruthy();
  });
});
