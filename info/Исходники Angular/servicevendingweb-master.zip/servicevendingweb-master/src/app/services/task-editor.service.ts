import { Injectable } from '@angular/core';
import {MatDialog} from '@angular/material';
import {ConfirmDialogComponent} from '@app/components/dialogs/confirm-dialog/confirm-dialog.component';
import {TaskFormDialogComponent} from '@app/components/dialogs/task-form-dialog/task-form-dialog.component';
import {Task} from '@app/models';
import {Observable} from 'rxjs';
import {TaskFilters} from '@app/interfaces';
import {map} from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class TaskEditorService {

  constructor(private dialog: MatDialog) { }

  addTask(filters?: TaskFilters): Observable<Task|null> {
    return TaskFormDialogComponent.openAsDialog(this.dialog, {taskFilters: filters}).afterClosed();
  }

  editTask(task: Task, filters?: TaskFilters): Observable<Task|null> {
    return TaskFormDialogComponent.openAsDialog(this.dialog, {task: task, taskFilters: filters}).afterClosed();
  }

  removeTask(task: Task, successFn?: () => void) {
    ConfirmDialogComponent.openAsDialog(this.dialog, {
      message: 'Вы уверены, что хотите удалить задачу?',
      btnText: 'Удалить'
    }).afterClosed().subscribe(confirm => {
      if(confirm) task.remove().subscribe(successFn);
    });
  }
}
