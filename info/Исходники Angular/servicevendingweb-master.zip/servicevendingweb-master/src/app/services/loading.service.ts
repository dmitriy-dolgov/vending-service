import {ComponentRef, Injectable} from '@angular/core';
import {Overlay, OverlayRef} from '@angular/cdk/overlay';
import {ComponentPortal} from '@angular/cdk/portal';
import {SpinnerComponent} from '@app/components/spinner/spinner.component';
import {Observable, Subject} from 'rxjs';

export interface LoadingState {
  show: boolean;
}

@Injectable({
  providedIn: 'root'
})
export class LoadingService {
  private overlayRef: OverlayRef;
  private readonly _subject = new Subject<LoadingState>();
  private readonly _observ = this._subject.asObservable();
  private _shown = false;

  get shown(): boolean {
    return this._shown;
  }

  get state(): Observable<LoadingState> {
    return this._observ;
  }

  constructor(private overlay: Overlay) {}

  public show() {

    if (!this.overlayRef) {
      this.overlayRef = this.overlay.create();
    }

    setTimeout(() => {

      // Create ComponentPortal that can be attached to a PortalHost
      const spinnerOverlayPortal = new ComponentPortal(SpinnerComponent);

      // Attach ComponentPortal to PortalHost
      const componentRef: ComponentRef<SpinnerComponent> = this.overlayRef.attach(spinnerOverlayPortal);
      this._subject.next({show: true});
      this._shown = true;

    });
  }

  public hide() {
    if (!!this.overlayRef) {
      setTimeout(() => {
        this.overlayRef.detach();
        this._subject.next({show: false});
        this._shown = false;
      });
    }
  }
}
