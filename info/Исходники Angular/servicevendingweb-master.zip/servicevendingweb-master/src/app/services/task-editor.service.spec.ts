import { TestBed } from '@angular/core/testing';

import { TaskEditorService } from './task-editor.service';

describe('TaskEditorService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: TaskEditorService = TestBed.get(TaskEditorService);
    expect(service).toBeTruthy();
  });
});
