import { Injectable } from '@angular/core';
import {Model} from '@app/models';
import * as moment from 'moment';
import {TasksService} from '@app/services/tasks.service';
import {TaskFilters} from '@app/interfaces';
import {LocalStorageService} from '@app/services/local-storage.service';

type SerialisedFilters = {
  [key: string]: {
    value: any,
    type?: 'Model' | 'Moment' | any,
    collectionName?: string
  };
};

@Injectable({
  providedIn: 'root'
})
export class TaskFilterService {

  private readonly STORAGE_KEY = 'taskFilters';

  constructor(
    private tasksService: TasksService,
    private storage: LocalStorageService
  ) {}

  getFilters(): TaskFilters|null {
    const filters = this.storage.getItem(this.STORAGE_KEY);
    return filters ? this.filtersUnserialize(filters) : null;
  }

  setFilters(taskFilters: TaskFilters) {
    this.storage.setItem(this.STORAGE_KEY, this.filtersSerialize(taskFilters));
  }

  clearFilters() {
    this.storage.removeItem(this.STORAGE_KEY);
  }

  private filtersSerialize(taskFilters: TaskFilters): string {

    const serialisedFilers: SerialisedFilters = {};

    Object.entries(taskFilters)
      .filter(([name, value]) => !!value)
      .forEach(([name, value]) => {
        if(typeof value != 'object' || value instanceof Array) {
          serialisedFilers[name] = {value: value};
        } else if (value instanceof Model) {
          serialisedFilers[name] = {value: value.uid, type: 'Model', collectionName: value.collectionName};
        } else if (moment.isMoment(value)) {
          serialisedFilers[name] = {value: value.format(), type: 'Moment'};
        } else {
          serialisedFilers[name] = {value: value};
        }
      });

    return JSON.stringify(serialisedFilers);
  }

  private filtersUnserialize(data: string) {

    if(!this.isJSON(data)) {
      return null;
    }

    const serialisedFilers: SerialisedFilters = JSON.parse(data);
    const filters: TaskFilters = {};

    Object.entries(serialisedFilers).forEach(([name, data]) => {
      switch (data.type) {
        case 'Model':
          const items = this.tasksService.getCollection(data.collectionName).items;
          filters[name] = items.find((m: Model) => m.uid == data.value);
          break;
        case 'Moment':
          filters[name] = moment(data.value);
          break;
        default:
          filters[name] = data.value;
      }
    });

    return filters;
  }

  isJSON(v) {
    return /^\{[\S\s]*\}$/.test((v || '').toString());
  }
}
