import {Client, ClientStatuses, Division, Machine, Task} from '@app/models';
import * as moment from 'moment';

export enum MachineServiceStates {
  NORMAL,
  WARNING,
  CRITICAL
}

export type MachineServiceState = MachineServiceStates;

export function machineServiceState(machine: Machine, tasks: Task[], divis?: Division): MachineServiceState {
/*if (moment (machine.redDate) > moment())
  return MachineServiceStates.CRITICAL;
else if (moment (machine.orangeDate) > moment())
  return MachineServiceStates.WARNING;
else 
  return MachineServiceStates.NORMAL;*/

  const machineTasks = (tasks || [])
    .filter(task => Number(task.machineID) === machine.iD && task.isFinished)
    .sort((t1, t2) => t2.datetime - t1.datetime);

  if (!machineTasks.length) {
    return MachineServiceStates.CRITICAL;
  }
  let division;
  if (divis) {
    division = divis;
  } else {
    division = machine.division;
  }
  let delta: number;

  switch (division.clientID ? division.client.status : Client.DEFAULT_STATUS) {
    case ClientStatuses.CRUCIAL:
      delta = 0;
      break;

    case ClientStatuses.SIGNIFICANT:
      delta = 0.5;
      break;

    default:
      delta = 1;
  }

  const lastTaskFinishedTime = moment(machineTasks[0].datetime);
  const diffMonth = moment().diff(lastTaskFinishedTime, 'months', true);

  switch (true) {
    case(diffMonth > 1 + delta):
      return MachineServiceStates.CRITICAL;

    case(diffMonth > 0.5 + delta):
      return MachineServiceStates.WARNING;

    default:
      return MachineServiceStates.NORMAL;
  }
}

export function divisionServiceState(division: Division, tasks: Task[], machines?: Machine[]): MachineServiceState {
  let states = [];
  if (machines) {
    const currentMachine = machines.filter(m => {
      return m.divisionID === division.iD;
    });
    states = currentMachine
      .map(machine => machineServiceState(machine, tasks))
      .sort((a, b) => b - a);
  } else {
    states = division.machines
      .map(machine => machineServiceState(machine, tasks))
      .sort((a, b) => b - a);
  }

  return states.length ? states[0] : MachineServiceStates.CRITICAL;
}

export function divisionCenterCoordinates(divisions: Division[]): [number, number] {
  divisions = (divisions || []).filter(d => d.gPSLocationX && d.gPSLocationY);

  if (!divisions.length) {
    return [55.796289, 49.108795];
  }

  // x - чем больше тем левее на карте
  const xList = divisions.map(d => d.gPSLocationX).sort((x1, x2) => x1 - x2);
  // y - чем больше тем ниже на карте
  const yList = divisions.map(d => d.gPSLocationY).sort((y1, y2) => y1 - y2);

  return [
    parseFloat((xList[0] + (xList[xList.length - 1] - xList[0]) / 2).toFixed(6)),
    parseFloat((yList[0] + (yList[yList.length - 1] - yList[0]) / 2).toFixed(6))
  ];
}

export function parentNodes(node: Node): Node[] {
  const parents = [];
  while (node.parentNode) {
    parents.push(node);
    node = node.parentNode;
  }
  return parents;
}

export function uuidGenerate() {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c, r) => {
    return ('x' == c ? (r = Math.random() * 16 | 0) : (r & 0x3 | 0x8)).toString(16);
  });
}
