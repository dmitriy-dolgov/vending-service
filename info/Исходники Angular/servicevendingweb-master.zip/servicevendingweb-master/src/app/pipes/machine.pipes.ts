import {Pipe, PipeTransform} from '@angular/core';
import {TaskStateTypes, Task, Machine} from '@app/models';
import * as moment from 'moment';
import {Moment} from 'moment';
import {MachineServiceStates, machineServiceState} from '@app/utils';
import {TasksService} from '@app/services/tasks.service';

@Pipe({name: 'todayTaskAdded'})
export class TodayTaskAddedPipe implements PipeTransform {

  transform(machine: Machine, tasks: Task[]): boolean {
    let currentDayTime = this.getUtcTime(moment(), '00:00:00');

    return !!(tasks || []).find(task => {
      return task.machine.iD == machine.iD
        && task.state != TaskStateTypes.REMOVED
        && task.datetime >= currentDayTime;
    });
  }

  private getUtcTime(m: Moment, time: string) {
    return moment(`${m.format(moment.HTML5_FMT.DATE)} ${time}`).utc().valueOf();
  }
}



@Pipe({name: 'machineServiceState'})
export class MachineServiceStatePipe implements PipeTransform {
  // constructor(taskService: TasksService) {
  //
  // }
  // this.taskService
  transform(machine: Machine, tasks: Task[], d: any): string {
    const divis = d.filter(di => {
      return di.iD === machine.divisionID;
    })[0];
    if(!tasks) return '';
    const serviceState = MachineServiceStates[machineServiceState(machine, tasks, divis)].toLowerCase();
    return `machine-service-state-${serviceState}`;
  }
}

