import {Pipe, PipeTransform} from '@angular/core';
import * as moment from 'moment';
import {DATE_FORMAT, DATETIME_FORMAT, TIME_FORMAT} from '@src/environments/moment';

@Pipe({name: 'dateTimeFormat'})
export class DateTimeFormatPipe implements PipeTransform {
  transform(dt: string | Date | moment.Moment | number, dateTimeFormat?: string): any {
    return !dt ? '' : moment(moment.utc(dt).toDate()).local().format(dateTimeFormat || DATETIME_FORMAT);
  }
}

@Pipe({name: 'dateFormat'})
export class DateFormatPipe implements PipeTransform {
  transform(dt: string | Date | moment.Moment | number, dateFormat?: string): any {
    return !dt ? '' : moment(moment.utc(dt).toDate()).local().format(dateFormat || DATE_FORMAT);
  }
}

@Pipe({name: 'timeFormat'})
export class TimeFormatPipe implements PipeTransform {
  transform(dt: string | Date | moment.Moment | number, timeFormat?: string): any {
    return !dt ? '' : moment(moment.utc(dt).toDate()).local().format(timeFormat || TIME_FORMAT);
  }
}
