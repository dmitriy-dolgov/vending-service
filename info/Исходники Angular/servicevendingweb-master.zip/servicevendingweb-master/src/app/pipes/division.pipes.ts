import {Pipe, PipeTransform} from '@angular/core';
import {Division, Task} from '@app/models';
import {divisionCenterCoordinates, divisionServiceState, MachineServiceStates} from '@app/utils';

@Pipe({name: 'divisionServiceState'})
export class DivisionServiceStatePipe implements PipeTransform {
  transform(division: Division, tasks: Task[]): string {
    if(!tasks) return '';
    const serviceState = MachineServiceStates[divisionServiceState(division, tasks)].toLowerCase();
    return `machine-service-state-${serviceState}`;
  }
}

@Pipe({name: 'divisionCenterCoordinates'})
export class DivisionCenterCoordinatesPipe implements PipeTransform {
  transform(divisions: Division[]): [number, number] {
    return divisionCenterCoordinates(divisions);
  }
}

@Pipe({name: 'divisionPlacemarkProperties'})
export class DivisionPlacemarkPropertiesPipe implements PipeTransform {
  transform(division: Division): any {
    return {
      hintContent: division.fullDescription,
      balloonContent: division.fullDescription,
      clusterCaption: division.fullDescription,
    };
  }
}

@Pipe({name: 'divisionPlacemarkOptions'})
export class DivisionPlacemarkOptionsPipe implements PipeTransform {
  transform(division: Division, tasks: Task[]): any {

    let iconColor = 'red';

    if(tasks) {
      switch (divisionServiceState(division, tasks)) {
        case MachineServiceStates.NORMAL:
          iconColor = 'green';
          break;
        case MachineServiceStates.WARNING:
          iconColor = 'orange';
          break;
      }
    }

    return {
      // Необходимо указать данный тип макета.
      iconLayout: 'default#image',
      // Своё изображение иконки метки.
      iconImageHref: require(`../../assets/icons/map/ic_pin_${iconColor}.png`),
      // Размеры метки.
      iconImageSize: [64, 64],
      // Смещение левого верхнего угла иконки относительно её "ножки" (точки привязки).
      iconImageOffset: [-32, -64]
    };
  }
}
