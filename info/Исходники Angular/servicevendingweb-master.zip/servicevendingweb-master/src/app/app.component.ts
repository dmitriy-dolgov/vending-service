import {Component, OnInit} from '@angular/core';
import {Title} from '@angular/platform-browser';
import {environment} from '@src/environments/environment';
import {AuthenticationService} from './services/authentication.service';
import {NavItem} from '@app/interfaces';
import {ActivatedRoute, NavigationEnd, ResolveEnd, RouteConfigLoadEnd, Router} from '@angular/router';
import {filter} from 'rxjs/operators';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {

  title = environment.app.title;
  loading = true;

  navItems: NavItem[] = [
    {routeLink: '/tasks', title: 'Список задач', icon: 'ic_menu_task'},
    {routeLink: '/classifier', title: 'Классификатор', icon: 'ic_menu_class'},
    {routeLink: '/report', title: 'Отчёт по баллам', icon: 'ic_menu_list'},
    {routeLink: '/map', title: 'Карта', icon: 'ic_menu_map'},
  ];

  public constructor(
    public auth: AuthenticationService,
    private titleService: Title,
    private router: Router
  ) {
  }

  ngOnInit(): void {
    this.titleService.setTitle(this.title);
    this.auth.user.subscribe(() => this.loading = false);
  }
}
