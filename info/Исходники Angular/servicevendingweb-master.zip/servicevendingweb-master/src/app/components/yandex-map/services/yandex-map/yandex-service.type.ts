import { Observable } from 'rxjs';

export interface IYandexMapService {
  mapReady(): Observable<any>;
}
