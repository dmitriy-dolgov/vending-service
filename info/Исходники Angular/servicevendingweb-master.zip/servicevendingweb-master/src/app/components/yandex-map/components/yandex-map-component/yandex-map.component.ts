import {
  Component,
  OnInit,
  Input,
  ViewChild,
  ElementRef,
  ContentChildren,
  QueryList,
  Output,
  EventEmitter,
  AfterContentInit, IterableDiffer, IterableDiffers, IterableChangeRecord, DoCheck
} from '@angular/core';
import { YandexPlacemarkComponent } from '../yandex-placemark-component/yandex-placemark.component';
import { YandexMultirouteComponent } from '../yandex-multiroute-component/yandex-multiroute.component';
import { YandexGeoObjectComponent } from '../yandex-geoobject-component/yandex-geoobject.component';
import { YandexControlComponent } from '../yandex-control-component/yandex-control.component';
import { YandexMapService } from '../../services/yandex-map/yandex-map.service';
import { take } from 'rxjs/operators';
import { generateRandomId } from '../../utils/utils';
import { IEvent, ILoadEvent } from '../../types/types';
import * as YMaps from 'yandex-maps';

@Component({
  selector: 'angular-yandex-map',
  templateUrl: './yandex-map.component.html',
  styleUrls: ['./yandex-map.component.scss']
})
export class YandexMapComponent implements OnInit, DoCheck {
  // Get MapContainer & components inside MapContainer
  @ViewChild('container') public mapContainer: ElementRef;
  @ContentChildren(YandexPlacemarkComponent) placemarks: QueryList<YandexPlacemarkComponent>;
  @ContentChildren(YandexMultirouteComponent) multiroutes: QueryList<YandexMultirouteComponent>;
  @ContentChildren(YandexGeoObjectComponent) geoObjects: QueryList<YandexGeoObjectComponent>;
  @ContentChildren(YandexControlComponent) controls: QueryList<YandexControlComponent>;

  // Inputs
  @Input() public center: Array<number>;
  @Input() public zoom: number = 10;
  @Input() public state: any = {};
  @Input() public options: any = {};
  @Input() public clusterer: any;

  // Outputs
  @Output() public load = new EventEmitter<ILoadEvent>();
  @Output() public action = new EventEmitter<IEvent>();
  @Output() public baloon = new EventEmitter<IEvent>();
  @Output() public yaclick = new EventEmitter<IEvent>();
  @Output() public hint = new EventEmitter<IEvent>();
  @Output() public mouse = new EventEmitter<IEvent>();
  @Output() public multitouch = new EventEmitter<IEvent>();

  private differ: IterableDiffer<any>;
  private placemarkLists: YMaps.Placemark[] = [];
  private collection: YMaps.GeoObjectCollection;
  private ymapsClusterer: any;
  private useClusterer: boolean;
  private _ymaps: typeof YMaps;
  private _map: YMaps.Map;

  get ymaps(): typeof YMaps {
    return this._ymaps;
  }

  get map(): ymaps.Map {
    return this._map;
  }

  constructor(
    private _yandexMapService: YandexMapService,
    private differs: IterableDiffers
  ) {
    this.differ = this.differs.find([]).create(null);
  }

  public ngOnInit(): void {
    this._logErrors();

    this._yandexMapService.mapReady()
      .pipe(take(1))
      .subscribe((ymaps: typeof YMaps) => {
        this._ymaps = ymaps;

        this._map = this._createMap(ymaps, generateRandomId());

        if(this.clusterer) {
          this.ymapsClusterer = new ymaps.Clusterer(this.clusterer);
          this._map.geoObjects.add(this.ymapsClusterer);
          this.useClusterer = true;
        } else {
          this.collection = new ymaps.GeoObjectCollection();
          this._map.geoObjects.add(this.collection);
          this.useClusterer = false;
        }

        this.emitEvents(ymaps, this._map);
        this._addObjectsOnMap(ymaps, this._map);

      });
  }

  ngDoCheck() {
    this.doCheckPlacemark();
  }

  setCenter(coordinates: [number, number], zoom?: number) {
    this._map.setCenter(coordinates, zoom);
  }

  private doCheckPlacemark() {
    if(!this._map || !this.placemarks) return;

    const changes = this.differ.diff(this.placemarks.toArray());
    if (!changes) return;

    changes.forEachOperation(((record: IterableChangeRecord<YandexPlacemarkComponent>,
                                        prevIndex, currentIndex) => {

      if (record.previousIndex == null) { // added
        this.placemarkLists.splice(currentIndex, 0, record.item.initPlacemark(this._ymaps, this._map));
      } else if (currentIndex == null) { // removed
        this.placemarkLists.splice(prevIndex, 1);
      } else { // moved
      }

    }));

    if(this.useClusterer) {
      this.ymapsClusterer.removeAll();
      this.ymapsClusterer.add(this.placemarkLists);
    } else {
      this.collection.removeAll();
      this.placemarkLists.forEach(placemark => {
        this.collection.add(placemark);
      });
    }
  }

  private _logErrors(): void {
    if (!this.center) {
      console.error('Map: center input is required.');
      this.center = [];
    }
  }

  /**
   * Create map
   * @param ymaps - class from Yandex.Map API
   * @param id - unique id
   */
  private _createMap(ymaps: typeof YMaps, id: string): YMaps.Map {
    this.mapContainer.nativeElement.setAttribute('id', id);

    return new ymaps.Map(
      id, { ...this.state, zoom: this.zoom, center: this.center }, this.options
    );
  }

  /**
   * Add YMaps entities/objects on map
   */
  private _addObjectsOnMap(ymaps: typeof YMaps, map: YMaps.Map): void {

    // Multiroutes
    this.multiroutes.forEach((multiroute) => {
      multiroute.initMultiroute(ymaps, map);
    });

    // GeoObjects
    this.geoObjects.forEach((geoObject) => {
      geoObject.initGeoObject(ymaps, map);
    });

    // Controls
    this.controls.forEach((control) => {
      control.initControl(ymaps, map);
    });
  }

  /**
   * Emit events
   * @param ymaps - class from Yandex.Map API
   * @param map - map instance
   */
  public emitEvents(ymaps: typeof YMaps, map: YMaps.Map): void {
    this.load.emit({ ymaps, instance: map });

    // Action
    map.events
      .add(
        ['actionbegin', 'actionend'],
        (e: any) => this.action.emit({ ymaps, instance: map, type: e.originalEvent.type, event: e })
      );

    // Baloon
    map.events
      .add(
        ['balloonopen', 'balloonclose'],
        (e: any) => this.baloon.emit({ ymaps, instance: map, type: e.originalEvent.type, event: e })
      );

    // Click
    map.events
      .add(
        ['click', 'dblclick'],
        (e: any) => this.yaclick.emit({ ymaps, instance: map, type: e.originalEvent.type, event: e })
      );

    // Hint
    map.events
      .add(
        ['hintopen', 'hintclose'],
        (e: any) => this.hint.emit({ ymaps, instance: map, type: e.originalEvent.type, event: e })
      );

    // Mouse
    map.events
      .add(
        ['mousedown', 'mouseenter', 'mouseleave', 'mousemove', 'mouseup'],
        (e: any) => this.mouse.emit({ ymaps, instance: map, type: e.originalEvent.type, event: e })
      );

    // Multitouch
    map.events
      .add(
        ['multitouchstart', 'multitouchmove', 'multitouchend'],
        (e: any) => this.multitouch.emit({ ymaps, instance: map, type: e.originalEvent.type, event: e })
      );
  }
}
