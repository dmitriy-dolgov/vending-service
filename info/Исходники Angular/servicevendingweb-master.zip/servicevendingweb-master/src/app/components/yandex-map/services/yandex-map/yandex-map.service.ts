import {Inject, Injectable, Injector, NgZone} from '@angular/core';
import { from, fromEvent, Observable } from 'rxjs';
import { IYandexMapService } from './yandex-service.type';
import { DOCUMENT } from '@angular/common';
import { map, switchMap } from 'rxjs/operators';
import * as YMaps from 'yandex-maps';

declare const ymaps: typeof YMaps;

@Injectable({
  providedIn: 'root'
})
export class YandexMapService implements IYandexMapService {
  private _scriptYmaps: HTMLScriptElement;
  private _apiKey: string;

  constructor(
    @Inject(DOCUMENT) private document: Document,
    private _injector: Injector,
    private zone: NgZone
  ) {
    this._apiKey = this._injector.get('API_KEY');
  }

  /**
   * Init YMaps script if it's not initiated
   * Return YMaps subject
   */
  public mapReady(): Observable<typeof YMaps | any> {

    return from(new Promise(resolve => {

      this.zone.runOutsideAngular(() => {

        if (!this._scriptYmaps) {
          const ymapScript = this.document.createElement('script');
          ymapScript.src = `https://api-maps.yandex.ru/2.1/?apikey=${this._apiKey}&lang=ru_RU`;
          this._scriptYmaps = this.document.head.appendChild(ymapScript);
        }

        if ('ymaps' in window) {
          return ymaps.ready().then(() => resolve(ymaps));
        }

        fromEvent(this._scriptYmaps, 'load')
          .pipe(switchMap(() => from(ymaps.ready()).pipe(map(() => ymaps))))
          .subscribe(resolve);

      });

    }));
  }
}
