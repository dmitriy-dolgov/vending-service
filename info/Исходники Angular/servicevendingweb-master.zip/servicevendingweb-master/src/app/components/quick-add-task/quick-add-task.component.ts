import {
  Component,
  Directive,
  EventEmitter,
  Input,
  OnDestroy,
  OnInit,
  Output,
  QueryList,
  ViewChildren,
  ViewContainerRef
} from '@angular/core';
import {TasksService} from '@app/services/tasks.service';
import {Machine, OperationType, Task, User} from '@app/models';
import {AbstractControl, FormArray, FormControl, FormGroup, Validators} from '@angular/forms';
import {AuthenticationService} from '@app/services/authentication.service';
import {map, switchMap, take} from 'rxjs/operators';
import {forkJoin, Observable, Subscription} from 'rxjs';
import {LoadingService} from '@app/services/loading.service';
import {MatAutocompleteTrigger} from '@angular/material';
import {AppValidators} from '@app/validators';


@Component({
  selector: 'app-quick-add-task',
  templateUrl: './quick-add-task.component.html',
  styleUrls: ['./quick-add-task.component.scss'],
  host: {
    'class': 'app-quick-add-task'
  }
})
export class QuickAddTaskComponent implements OnInit, OnDestroy {

  @ViewChildren(MatAutocompleteTrigger)
  autocompleteTriggers: QueryList<MatAutocompleteTrigger>;

  @Output() addTask: EventEmitter<Task> = new EventEmitter<Task>();
  @Input() machine: Machine;

  private _subscriptions: Subscription[] = [];
  operationTypeControls: FormControl[];
  operationTypes: OperationType[];
  controls: AbstractControl[];
  workers: Observable<User[]>;
  currentUser: User;
  form: FormGroup;

  get checkedOperationTypes(): OperationType[] {
    return this.operationTypeControls
      .map((control, index) => [control.value, index])
      .filter(([checked, index]) => checked)
      .map(([checked, index]) => this.operationTypes[index]);
  }

  constructor(
    private tasksService: TasksService,
    private auth: AuthenticationService,
    private loadingService: LoadingService
  ) {
  }

  ngOnInit() {
    this._subscriptions.push(
      this.auth.user.subscribe(user => {
        this.currentUser = this.tasksService.users.find(u => u.iD === user.uid);
      })
    );

    this._subscriptions.push(
      this.tasksService.getCollection<OperationType>('operationTypes')
        .valueChanges().subscribe(operationTypes => {
        this.operationTypes = operationTypes;
        this.initControls();
      })
    );
  }

  private initControls() {
    this.operationTypeControls = this.operationTypes.map(() => new FormControl(false));

    this.form = new FormGroup({
      operationTypes: new FormArray(this.operationTypeControls, [
        (control: AbstractControl) => control.value.some(v => !!v) ? null : {require: true}
      ]),
      worker: new FormControl('', [
        Validators.required,
        AppValidators.isModel
      ])
    });

    this.workers = this.form.get('worker').valueChanges.pipe(
      // startWith(''),
      //debounceTime(250),
      switchMap(value => {
        value = (value || '').toString().trim().toLowerCase();
        return this.tasksService.getCollection<User>('users').valueChanges().pipe(
          take(1),
          map(users => users.filter(user => user.displayName.toLowerCase().includes(value)))
        );
      })
    );
  }

  formSubmit() {
    if (this.form.valid) {
      this.loadingService.show();
      console.log('дата тест', {
        worker: this.form.get('worker').value,
        machine: this.machine,
        service: this.tasksService,
        user: this.currentUser
      });
      Task.create(this.tasksService, this.currentUser, {
        worker: this.form.get('worker').value,
        machine: this.machine
      }).pipe(switchMap(newTask => {
        console.log('new task : ', newTask);
        console.log('operation type : ', this.checkedOperationTypes);
        return forkJoin(this.checkedOperationTypes.map(operationType => {
          return newTask.addOperation({operationType, description: operationType.description});
        })).pipe(map(taskOperations => newTask));
      })).subscribe(newTask => {
        this.loadingService.hide();
        this.addTask.emit(newTask);
      });
    }
  }

  toggleAutocompletePanel(event: MouseEvent, trigger: MatAutocompleteTrigger, formControlName: string) {
    event.stopPropagation();
    this.autocompleteTriggers.forEach(t => {
      if (t.autocomplete.isOpen) {
        t.closePanel();
      } else if (t == trigger) {
        this.form.controls[formControlName].reset();
        t.openPanel();
      }
    });
  }

  ngOnDestroy(): void {
    while (this._subscriptions.length) {
      this._subscriptions.pop().unsubscribe();
    }
  }

}
