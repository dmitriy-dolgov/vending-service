import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {QuickAddTaskComponent} from '@app/components/quick-add-task/quick-add-task.component';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {MatAutocompleteModule, MatTooltipModule} from '@angular/material';

@NgModule({
  declarations: [
    QuickAddTaskComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatTooltipModule,
    MatAutocompleteModule
  ],
  exports: [
    QuickAddTaskComponent
  ],
  entryComponents: [
    QuickAddTaskComponent
  ]
})
export class QuickAddTaskModule { }
