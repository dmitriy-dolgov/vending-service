import {Component, EventEmitter, Input, OnInit, Output, QueryList, ViewChildren} from '@angular/core';
import {TasksService} from '@app/services/tasks.service';
import {AbstractControl, FormControl, FormGroup, ValidatorFn, Validators} from '@angular/forms';
import {City, Division, User, MachineType, Model} from '@app/models';
import {LoggerService} from '@app/services/logger.service';
import {MatAutocompleteTrigger} from '@angular/material';
import {AppValidators} from '@app/validators';
import {TaskEditorService} from '@app/services/task-editor.service';
import {TaskFilters} from '@app/interfaces';
import {map} from 'rxjs/operators';
import {Observable} from 'rxjs';



@Component({
  selector: 'app-task-filter-form',
  templateUrl: './task-filter-form.component.html',
  styleUrls: ['./task-filter-form.component.scss'],
  host: {
    'class': 'task-filter-filterForm'
  }
})
export class TaskFilterFormComponent implements OnInit {

  @Output() filtersChange = new EventEmitter<TaskFilters|null>();
  @Input() filters: TaskFilters|null;
  @Input() title: string;

  private defaultFilters: TaskFilters = {
    machineType: null,
    city: null,
    division: null,
    author: null,
    worker: null,
    states: [],
    dateFrom: null,
    dateTo: null,
  };
  filterForm: FormGroup;

  machineTypes: Observable<MachineType[]>;
  divisions: Observable<Division[]>;
  authors: Observable<User[]>;
  workers: Observable<User[]>;
  cities: Observable<City[]>;

  @ViewChildren(MatAutocompleteTrigger)
  autocompleteTriggers: QueryList<MatAutocompleteTrigger>;

  controls: {[key: string]: AbstractControl};

  constructor(
    private taskEditor: TaskEditorService,
    public tasksService: TasksService,
    private logger: LoggerService
  ) { }

  ngOnInit() {
    const formFilters: TaskFilters = {...this.defaultFilters, ...this.filters || {}};
    const controls: {[key: string]: AbstractControl} = {};

    Object.entries(formFilters).forEach(([name, value]) => {
      controls[name] = new FormControl(value, [
        AppValidators.noWhitespaceValidator
      ]);
    });

    controls.city.valueChanges.subscribe((city: City) => controls.division.reset());

    this.filterForm = new FormGroup(controls);
    this.controls = controls;
    this.initAutocompletes();
  }

  initAutocompletes() {

    const autocomplets: {

      [key: string]: {
        formControl: AbstractControl,
        validators?: ValidatorFn[] | ValidatorFn,
        filter?: (v: any) => Model[] | string[],
        collectionName?: string
      };

    } = {

      authors: {formControl: this.controls.author, validators: [AppValidators.isModel], collectionName: 'users'},
      workers: {formControl: this.controls.worker, validators: [AppValidators.isModel], collectionName: 'users'},
      machineTypes: {formControl: this.controls.machineType, validators: [AppValidators.isModel]},
      cities: {formControl: this.controls.city, validators: [AppValidators.isModel]},
      divisions: {
        formControl: this.controls.division,
        filter: (value: string) => {
          return this.autocompleteDivisionsFilter();
        }
      }
    };

    Object.entries(autocomplets).forEach(
      (
        [
          listKey,
          {
            formControl,
            validators,
            filter,
            collectionName = listKey
          }
        ]
      ) => {

        if(!filter) {
          filter = (value) => {
            if(!value) return this.tasksService[collectionName].slice();
            return this.tasksService[collectionName].filter((model: Model) => {
              return model.toString().toLowerCase().includes(value);
            });
          }
        }

        if(validators) {
          formControl.setValidators(validators);
        }

        this[listKey] = formControl.valueChanges.pipe(
          // startWith(''),
          map((v: Model|string) => {
            return filter((v || '').toString().trim().toLowerCase());
          })
        );
      }
    );
  }

  addTask() {
    this.taskEditor.addTask(this.filterForm.value);
  }

  isObject(v) {
    return v && typeof v == 'object';
  }

  toggleAutocompletePanel(event: MouseEvent, trigger: MatAutocompleteTrigger, formControlName :string) {
    event.stopPropagation();
    this.autocompleteTriggers.forEach(t => {
      if(t.autocomplete.isOpen) {
        t.closePanel();
      } else if(t == trigger) {
        this.filterForm.controls[formControlName].reset();
        t.openPanel();
      }
    });
  }

  formSubmit() {
    Object.entries(this.filterForm.controls).forEach(([name, control]) => {
      if(!control.valid) control.reset();
    });

    this.filters = this.filterForm.value as TaskFilters;
    this.filtersChange.emit(this.filters);
  }

  formReset() {
    this.filters = null;
    this.filtersChange.emit(this.filters);
  }

  private autocompleteDivisionsFilter(): string[] {
    const city = this.controls.city.value as City|null;
    let divisions: Division[];

    if(this.isObject(city)) {
      divisions = city.divisions;
    } else if(city) {
      return [];
    } else {
      divisions = this.tasksService.divisions.slice();
    }

    let divisionNames = divisions.map(d => d.fullDescription);

    const value = (this.controls.division.value || '').toString().trim().toLowerCase();
    return !value ? divisionNames : divisionNames.filter(divisionName => {
      return divisionName.toLowerCase().includes(value);
    });
  }
}
