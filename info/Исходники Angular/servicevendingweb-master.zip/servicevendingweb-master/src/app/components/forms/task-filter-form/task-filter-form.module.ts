import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import {MaterialModule} from '@app/material.module';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {TaskFilterFormComponent} from '@app/components/forms/task-filter-form/task-filter-form.component';
import {StatesDropdownComponent} from '@app/components/forms/task-filter-form/states-dropdown/states-dropdown.component';

@NgModule({
  declarations: [
    TaskFilterFormComponent,
    StatesDropdownComponent
  ],
  imports: [
    CommonModule,
    MaterialModule,
    FormsModule,
    ReactiveFormsModule
  ],
  exports: [
    TaskFilterFormComponent
  ]
})
export class TaskFilterFormModule { }
