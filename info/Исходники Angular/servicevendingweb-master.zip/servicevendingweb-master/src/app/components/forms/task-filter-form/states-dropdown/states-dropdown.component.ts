import {Component, ElementRef, forwardRef, Inject, OnDestroy, OnInit, ViewChild} from '@angular/core';
import {MatListOption, MatSelectionList, MatSelectionListChange} from '@angular/material';
import {ControlValueAccessor, NG_VALUE_ACCESSOR} from '@angular/forms';
import {TasksService} from '@app/services/tasks.service';
import {DOCUMENT} from '@angular/common';
import {TaskStateTypes} from '@app/models';
import {fromEvent, Subject} from 'rxjs';
import {takeUntil} from 'rxjs/operators';
import {parentNodes} from '@app/utils';

@Component({
  selector: 'app-states-dropdown',
  templateUrl: './states-dropdown.component.html',
  styleUrls: ['./states-dropdown.component.scss'],
  providers: [{
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => StatesDropdownComponent),
    multi: true
  }]
})
export class StatesDropdownComponent implements OnInit, ControlValueAccessor, OnDestroy {

  @ViewChild('stateLists') stateLists: MatSelectionList;
  private destroyed$ = new Subject();
  onTouched: any = () => {};
  onChange: any = () => {};
  disabled = false;
  opened = false;

  constructor(
    @Inject(DOCUMENT) private document: Document,
    private elemRef: ElementRef<HTMLElement>,
    public tasksService: TasksService
  ) { }

  ngOnInit() {
    fromEvent(this.document, 'click').pipe(takeUntil(this.destroyed$)).subscribe((e: MouseEvent) => {
      if(this.opened && parentNodes(<HTMLElement>e.target).indexOf(this.elemRef.nativeElement) == -1) {
        this.opened = false;
      }
    });
  }

  setDisabledState(isDisabled: boolean): void {
    this.disabled = isDisabled;
  }

  writeValue(values: TaskStateTypes[]): void {
    values = values || [];

    if(this.stateLists.options) {
      this.stateLists.options.forEach(opt => {
        opt.selected = values.indexOf(opt.value) != -1;
      });
    } else {
      setTimeout(() => this.writeValue(values), 1);
    }
  }

  registerOnTouched(fn: any): void {
    this.onTouched = fn;
  }

  registerOnChange(fn: any): void {
    this.onChange = fn;
  }

  select(e: MatSelectionListChange) {
    const values = e.source.selectedOptions.selected.map((opt: MatListOption) => opt.value);
    this.onChange(values);
    this.onTouched();
  }

  ngOnDestroy(): void {
    this.destroyed$.next();
  }
}
