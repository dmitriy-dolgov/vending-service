import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TaskFilterFormComponent } from './task-filter-form.component';

describe('TaskFilterFormComponent', () => {
  let component: TaskFilterFormComponent;
  let fixture: ComponentFixture<TaskFilterFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TaskFilterFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TaskFilterFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
