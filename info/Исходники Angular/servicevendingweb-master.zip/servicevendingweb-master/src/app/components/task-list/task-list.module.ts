import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {RouterModule, Routes} from '@angular/router';
import {TaskListComponent, TaskOperationsPipe} from './task-list.component';
import {TaskFilterFormModule} from '@app/components/forms/task-filter-form/task-filter-form.module';
import {BaseModule} from '@app/base.module';

const routes: Routes = [
  {path: '', component: TaskListComponent}
];

@NgModule({
  declarations: [
    TaskListComponent,
    TaskOperationsPipe
  ],
  imports: [
    CommonModule,
    TaskFilterFormModule,
    RouterModule.forChild(routes),
    BaseModule
  ]
})
export class TaskListModule { }
