import {Component, ElementRef, EventEmitter, Inject, OnDestroy, OnInit, Pipe, PipeTransform, ViewChild} from '@angular/core';
import {PaginatorComponent} from '@app/components/paginator/paginator.component';
import {Task, TaskStateTypes} from '@app/models';
import {debounceTime, delay, filter, map} from 'rxjs/operators';
import {DOCUMENT} from '@angular/common';
import * as moment from 'moment';
import {Moment} from 'moment';
import {Observable, of, Subscription} from 'rxjs';
import {TasksService} from '@app/services/tasks.service';
import {LoggerService} from '@app/services/logger.service';
import {TaskEditorService} from '@app/services/task-editor.service';
import {TaskFilterFormComponent} from '@app/components/forms/task-filter-form/task-filter-form.component';
import {ActivatedRoute, Params, Router} from '@angular/router';
import {environment} from '@src/environments/environment';
import {MatDialog} from '@angular/material';
import {TaskFilterService} from '@app/services/task-filter.service';
import {TaskFilters} from '@app/interfaces';
import {Title} from '@angular/platform-browser';
import {AuthenticationService} from '@app/services/authentication.service';


@Pipe({name: 'taskOperations'})
export class TaskOperationsPipe implements PipeTransform {
  transform(task: Task): Observable<string> {
    return task.finishedOperations.pipe(map(operations => {
      return operations.map(o => o.operationType.shortName).join(', ');
    }));
  }
}

@Component({
  selector: 'app-task-list',
  templateUrl: './task-list.component.html',
  styleUrls: ['./task-list.component.scss']
})
export class TaskListComponent implements OnInit, OnDestroy {

  @ViewChild(TaskFilterFormComponent) taskFilterForm: TaskFilterFormComponent;
  @ViewChild(PaginatorComponent) paginator: PaginatorComponent;
  @ViewChild('task_list') taskListElem: ElementRef<HTMLElement>;
  private _subscriptions: Subscription[] = [];
  taskFilters: TaskFilters|null;
  filteredTasks: Task[] = [];
  tasks: Observable<Task[]>;
  allTasks: Task[];
  loading = true;
  inited = false;

  get title() {
    return `${this.taskFilters ? `Задачи` : `Все задачи`} (${this.paginator.length})`;
  }

  constructor(
    private tasksService: TasksService,
    private taskFilterService: TaskFilterService,
    @Inject(DOCUMENT) private document: Document,
    private taskEditor: TaskEditorService,
    public auth: AuthenticationService,
    private logger: LoggerService,
    private route: ActivatedRoute,
    public titleService: Title,
    private dialog: MatDialog,
    private router: Router
  ) {
  }

  ngOnInit() {
    this.taskFilters = this.taskFilterService.getFilters();
    const rerender = new EventEmitter<boolean>();

    // subscribe rerender
    this._subscriptions.push(
      rerender.pipe(debounceTime(200)).subscribe(scrollToTop => {
        if(this.inited){
          this.tasks = of(this.sliceTasks(this.filteredTasks));
          this.titleService.setTitle(`${environment.app.title} / ${this.title}`);
          if(scrollToTop){
            this.scrollToTakList();
          }
          this.loading = false;
        }
      })
    );

    // subscribe queryParams
    this._subscriptions.push(
      this.route.queryParams.subscribe(queryParams => {
        this.validatePageIndex(queryParams).subscribe(pageIndex => {
          this.paginator.pageIndex = pageIndex;
          rerender.emit(true);
        });
      })
    );

    // subscribe tasks
    this._subscriptions.push(
      this.tasksService.tasks.subscribe(tasks => {
        this.allTasks = tasks;
        this.filteredTasks = this.filterTasks(tasks);
        this.paginator.length = this.filteredTasks.length;
        this.validatePageIndex(this.route.snapshot.queryParams);
        this.inited = true;
      })
    );

    // subscribe filtersChange
    this._subscriptions.push(
      this.taskFilterForm.filtersChange.subscribe(filters => {
        this.filteredTasks = this.filterTasks(this.allTasks);
        this.paginator.pageIndex = 0;
        this.paginator.length = this.filteredTasks.length;
        if(filters) {
          this.scrollToTakList(true);
        }
      })
    );

    // subscribe paginator.reRender
    this._subscriptions.push(
      this.paginator.reRender.pipe(debounceTime(100)).subscribe(isPage => {
        rerender.emit(isPage);
      })
    );

    // subscribe paginator.page
    this._subscriptions.push(
      this.paginator.page.subscribe(isPage => {
        this.router.navigate([], {
          queryParamsHandling: 'merge',
          relativeTo: this.route,
          queryParams: {
            tasksPage: this.paginator.pageIndex + 1
          }
        });
      })
    );
  }

  openTaskDetails(task: Task) {
    this.router.navigate(['tasks', task.gUID], {
      queryParams: this.route.snapshot.queryParams
    });
  }

  editTask(task: Task) {
    const scrollTop = this.document.scrollingElement.scrollTop;
    this.taskEditor.editTask(task).pipe(delay(1)).subscribe(() => {
      this.document.scrollingElement.scrollTop = scrollTop;
    });
  }

  removeTask(task: Task) {
    this.taskEditor.removeTask(task);
  }

  ngOnDestroy(): void {
    while (this._subscriptions.length) {
      this._subscriptions.pop().unsubscribe();
    }
  }

  private scrollToTakList(force: boolean = false) {
    setTimeout(() => {
      if(this.taskListElem) {
        const scrollTo = this.taskListElem.nativeElement.offsetTop - 10;
        const scrollingElement = this.document.scrollingElement;
        if(force || scrollingElement.scrollTop > scrollTo){
          scrollingElement.scrollTop = scrollTo;
        }
      }
    }, 1);
  }

  private validatePageIndex(queryParams: Params): Observable<number> {
    return new Observable<number>(subscriber => {
      const pageIndex = Number(queryParams.tasksPage || 1) - 1;
      if(this.paginator.total && pageIndex >= this.paginator.total) {
        this.router.navigate([], {
          queryParams: { tasksPage: 1 },
          queryParamsHandling: 'merge',
          relativeTo: this.route
        });
      } else {
        subscriber.next(pageIndex);
      }
      subscriber.complete();
    });
  }

  private filterTasks(tasks: Task[]) {

    let filteredTasks = tasks.slice();

    if(this.taskFilters && Object.values(this.taskFilters).some(el => Array.isArray(el) ? !!el.length : el !== null))
    {
      this.taskFilterService.setFilters(this.taskFilters);

      if(this.taskFilters.machineType) {
        filteredTasks = filteredTasks.filter((task: Task) => {
          return task.machine.type.iD === this.taskFilters.machineType.iD;
        });
      }

      if(this.taskFilters.city) {
        filteredTasks = filteredTasks.filter((task: Task) => {
          return task.machine.division.city.iD === this.taskFilters.city.iD;
        });
      }

      if(this.taskFilters.division) {
        const _division = this.taskFilters.division.toString().trim().toLowerCase();
        filteredTasks = filteredTasks.filter((task: Task) => {
          return task.machine.division.fullDescription.toLowerCase().includes(_division);
        });
      }

      if(this.taskFilters.author) {
        filteredTasks = filteredTasks.filter((task: Task) => {
          return task.author && task.author.iD === this.taskFilters.author.iD;
        });
      }

      if(this.taskFilters.worker) {
        filteredTasks = filteredTasks.filter((task: Task) => {
          return task.worker && task.worker.iD === this.taskFilters.worker.iD;
        });
      }

      if(this.taskFilters.states && this.taskFilters.states.length) {
        filteredTasks = filteredTasks.filter((task: Task) => {
          return this.taskFilters.states.indexOf(Number(task.state)) >= 0;
        });
      }

      if(this.taskFilters.dateFrom) {
        let time = this.getUtcTime(this.taskFilters.dateFrom, '00:00:00');
        filteredTasks = filteredTasks.filter((task: Task) => task.datetime >= time);
      }

      if(this.taskFilters.dateTo) {
        let time = this.getUtcTime(this.taskFilters.dateTo, '23:59:59');
        filteredTasks = filteredTasks.filter((task: Task) => task.datetime <= time);
      }
    }
    else
    {
      this.taskFilterService.clearFilters();
      filteredTasks = tasks.slice();
    }

    filteredTasks.sort((t1, t2) => {
      return t2.datetime - t1.datetime;
    });

    return filteredTasks;
  }

  private getUtcTime(m: Moment, time: string) {
    return moment(`${m.format(moment.HTML5_FMT.DATE)} ${time}`).utc().valueOf();
  }

  private sliceTasks(tasks) {
    const startIndex = this.paginator.pageIndex * this.paginator.pageSize;
    return tasks.slice(startIndex, startIndex + this.paginator.pageSize);
  }
}
