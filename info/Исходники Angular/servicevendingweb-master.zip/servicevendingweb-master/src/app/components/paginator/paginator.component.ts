import {Component, Directive, ElementRef, EventEmitter, Inject, Input, OnInit, Output} from '@angular/core';
import {LoggerService} from '@app/services/logger.service';
import {DOCUMENT} from '@angular/common';
import {TasksService} from '@app/services/tasks.service';
import {LocalStorageService} from '@app/services/local-storage.service';

interface Page {
  index: number;
}

@Component({
  selector: 'app-paginator',
  templateUrl: './paginator.component.html',
  styleUrls: ['./paginator.component.scss']
})
export class PaginatorComponent implements OnInit {

  @Output() reRender = new EventEmitter<boolean>();
  @Output() page = new EventEmitter<void>();
  @Output() init = new EventEmitter<void>();

  @Input() scrollToTop?: boolean;
  @Input() scrollToRef?: HTMLElement;
  @Input() pageIndex: number = 0;
  @Input() pageSizeList: number[] = [10, 20, 50, 100, 200];
  @Input() pageSizeChose: boolean = true;
  @Input() size: number = 4;
  @Input() paginatorId: string;

  _pageSize: number = 10;
  _config: any = {};

  @Input()
  set pageSize(pageSize: number) {
    if(this._pageSize == pageSize) {
      return;
    }

    this._pageSize = pageSize;

    if(this.pageSizeChose) {
      this.config('pageSize', pageSize);
    }

    if(this.total < this.pageIndex + 1) {
      this.changePage(this.total - 1);
    } else {
      this.pageRange = this.createPageRange();
      this.reRender.emit();
    }
  }
  get pageSize(): number {
    return this._pageSize;
  }

  @Input()
  set length(length: number) {
    if(this._length != length) {
      this._length = length;
      if(this.pageIndex + 1 > this.total) {
        this.pageIndex = 0;
      }
      this.pageRange = this.createPageRange();
      this.reRender.emit();
    }
  }

  get length(): number {
    return this._length;
  }

  private _length: number = 0;
  pageRange:Page[];

  get total(): number {
    return Math.ceil(this.length / this.pageSize);
  }

  constructor(
    @Inject(DOCUMENT) private document: Document,
    private storage: LocalStorageService
  ) {
  }

  ngOnInit() {
    if(!this.paginatorId) {
      const path = location.pathname.replace(/\//g, '-').replace(/^-|-$/, '');
      this.paginatorId = `app-paginator-${path}`;
    }

    this._config = JSON.parse(this.storage.getItem(this.paginatorId) || '{}');

    if(this.pageSizeChose && this.config('pageSize')) {
      this.pageSize = this.config('pageSize');
    }

    if(!this.pageRange){
      this.pageRange = this.createPageRange();
    }
    this.init.emit();
  }

  changePage(pageIndex: number) {
    if(pageIndex >= 0 && pageIndex < this.total) {
      this.pageIndex = pageIndex;
      this.pageRange = this.createPageRange();
      this.page.emit();
      this.reRender.emit(true);
      if(this.scrollToRef) {
        setTimeout(() => this.document.scrollingElement.scrollTop = this.scrollToRef.offsetTop);
      } else if(this.scrollToTop) {
        setTimeout(() => this.document.scrollingElement.scrollTop = 0);
      }
    }
  }

  private config(key, value?): any {
    if(arguments.length == 1) {
      return this._config[key];
    }
    this._config[key] = value;
    this.storage.setItem(this.paginatorId, JSON.stringify(this._config));
  }

  private createPageRange(): Page[] {

    const pageRange:Page[] = [];
    let len = Math.min(this.size - 1, this.total);
    let pageIndex = 0;

    if (this.pageIndex + 1 > this.size - 2) {
      len = Math.min(this.pageIndex + 1, this.total - 1);
      pageIndex = this.pageIndex - (this.size - 2);
    }

    for (; pageIndex < len; pageIndex++) {
      pageRange.push({index: pageIndex});
    }

    if (pageIndex < this.total) {
      pageRange.push({index: pageIndex});
    }

    return  pageRange;
  }

}
