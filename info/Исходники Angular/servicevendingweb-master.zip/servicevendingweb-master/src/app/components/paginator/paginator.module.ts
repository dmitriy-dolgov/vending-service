import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {PaginatorComponent} from './paginator.component';
import {MatSelectModule} from '@angular/material';

@NgModule({
  declarations: [
    PaginatorComponent
  ],
  imports: [
    CommonModule,
    MatSelectModule
  ],
  exports: [
    PaginatorComponent
  ]
})
export class PaginatorModule { }
