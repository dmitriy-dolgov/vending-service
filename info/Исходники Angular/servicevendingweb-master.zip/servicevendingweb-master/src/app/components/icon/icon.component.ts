import {ChangeDetectionStrategy, Component, ElementRef, Input, OnInit} from '@angular/core';

@Component({
  selector: 'app-icon',
  template: '<ng-content></ng-content>',
  styleUrls: ['./icon.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  host: {
    '[style.backgroundImage]': 'iconUrl',
    '[style.minHeight.px]': 'size',
    '[style.minWidth.px]': 'size',
    '[style.height.px]': 'size',
    '[style.width.px]': 'size',
    'class': 'app-icon'
  }
})
export class IconComponent implements OnInit {

  @Input() size: number;
  @Input() name: string;

  get iconUrl() {
    return `url(${require(`../../../assets/icons/${this.name}.png`)})`;
  }

  constructor() { }

  ngOnInit() {
  }

}
