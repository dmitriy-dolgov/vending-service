import {
  Component, Directive, Input, Inject, Output,
  AfterContentInit,
  AfterViewInit,
  ContentChild,
  DoCheck,
  ElementRef,
  IterableDiffer,
  IterableDiffers,
  OnChanges,
  OnDestroy,
  OnInit,
  SimpleChanges,
  TemplateRef,
  ViewChild,
  ViewContainerRef,
  ViewEncapsulation,
  ComponentFactoryResolver,
  Renderer2, NgZone, ChangeDetectionStrategy, ChangeDetectorRef, EventEmitter
} from '@angular/core';
import {NavItem} from '@app/interfaces';
import {TasksService} from '@app/services/tasks.service';
import {Title} from '@angular/platform-browser';
import {ActivatedRoute, Router} from '@angular/router';
import {PaginatorComponent} from '@app/components/paginator/paginator.component';
import {fromEvent, Subject, Subscription} from 'rxjs';
import {environment} from '@src/environments/environment';
import {DOCUMENT} from '@angular/common';
import {MatDialog} from '@angular/material';
import {takeUntil} from 'rxjs/operators';


@Component({
  selector: 'app-classifier-row',
  template: `
      <div class="list-group-item">
          <ng-content></ng-content>
      </div>
      <ng-template #_viewContainerRef></ng-template>
  `,
  styles: [],
  host: {
    class: 'app-classifier-row'
  },
  exportAs: 'classifierRow'
})
export class ClassifierRowComponent implements OnInit {

  @ViewChild('_viewContainerRef', {read: ViewContainerRef})
  viewContainer: ViewContainerRef;

  ngOnInit(): void {
  }

  constructor() {

  }
}

class DataSourcerContext {
  constructor(
    public $implicit: any,
    public index: number
  ) {
  }
}

export interface ClassifierOutlet {
  viewContainer: ViewContainerRef;
  elementRef: ElementRef;
}

export interface ClassifierDef {
  container: ViewContainerRef;
  template: TemplateRef<Object>;
}

@Component({
  selector: 'app-classifier-row-group-header',
  template: `
      <ng-content></ng-content>`,
  host: {
    'class': 'app-classifier-row-group-header'
  }
})
export class ClassifierRowGroupHeaderComponent {
}

@Directive({selector: '[classifierRowDef]'})
export class ClassifierRowDef implements ClassifierDef {
  constructor(public container: ViewContainerRef, public template: TemplateRef<Object>) {
  }
}

@Directive({selector: '[classifierActionsDef]'})
export class ClassifieActionsDef implements ClassifierDef {
  constructor(public container: ViewContainerRef, public template: TemplateRef<Object>) {
  }
}

@Directive({selector: '[classifierFilterFormDef]'})
export class ClassifieFilterFormDef implements ClassifierDef {
  constructor(public container: ViewContainerRef, public template: TemplateRef<Object>) {
  }
}

@Directive({selector: '[classifierRowOutlet]'})
export class ClassifierRowOutlet implements ClassifierOutlet {
  constructor(public viewContainer: ViewContainerRef, public elementRef: ElementRef) {
  }
}

@Directive({selector: '[classifierActionsOutlet]'})
export class ClassifierActionsOutlet implements ClassifierOutlet {
  constructor(public viewContainer: ViewContainerRef, public elementRef: ElementRef) {
  }
}

@Directive({selector: '[classifierFilterFormOutlet]'})
export class ClassifierFilterFormOutlet implements ClassifierOutlet {
  constructor(public viewContainer: ViewContainerRef, public elementRef: ElementRef) {
  }
}

@Component({
  selector: 'app-classifier',
  templateUrl: './classifier.component.html',
  styleUrls: ['./classifier.component.scss'],
  host: {
    class: 'app-classifier'
  },
  encapsulation: ViewEncapsulation.None
})
export class ClassifierComponent implements OnInit, OnChanges, DoCheck, AfterContentInit, OnDestroy {

  @Input() pageTitle?: string = 'Классификатор';
  @Input() paginate?: boolean = true;
  @Input() dataSource: any[];

  @Input() groupBy?: string;
  @Input() sortFn?: (it1, b) => number = (it1, it2) => {
    const compare = (s1, s2) => s1.toString().localeCompare(s2.toString(), undefined, {
      sensitivity: 'base', numeric: true
    });
    return compare(it1[this.groupBy], it2[this.groupBy]) || compare(it1, it2);
  };

  @Input() navItems: NavItem[] = [
    {routeLink: '/classifier/machines', title: 'Оборудование'},
    {routeLink: '/classifier/divisions', title: 'Торговые точки'},
  ];

  @ContentChild(ClassifieFilterFormDef) filterFormDef: ClassifieFilterFormDef;
  @ContentChild(ClassifieActionsDef) actionsDef: ClassifieActionsDef;
  @ContentChild(ClassifierRowDef) rowDef: ClassifierRowDef;

  @ViewChild(ClassifierFilterFormOutlet) filterFormOutlet: ClassifierFilterFormOutlet;
  @ViewChild(ClassifierActionsOutlet) actionsOutlet: ClassifierActionsOutlet;
  @ViewChild(ClassifierRowOutlet) rowOutlet: ClassifierRowOutlet;
  @ViewChild(PaginatorComponent) paginator: PaginatorComponent;
  @ViewChild('classifierFilterForm') filterForm: ElementRef<HTMLElement>;
  @ViewChild('classifierList') classifierList: ElementRef<HTMLElement>;

  private differ: IterableDiffer<any>;
  private destroyed$ = new Subject();
  loading = true;
  items: any[];

  get hasNav(): boolean {
    return this.navItems && this.navItems.length > 0;
  }

  constructor(
    public tasksService: TasksService,
    protected titleService: Title,
    private componentFactoryResolver: ComponentFactoryResolver,
    @Inject(DOCUMENT) private document: Document,
    private changeDetector: ChangeDetectorRef,
    private differs: IterableDiffers,
    private renderer: Renderer2,
    private route: ActivatedRoute,
    private router: Router,
    private zone: NgZone
  ) {
  }

  ngOnInit() {
    const pageTitle = `${environment.app.title} / ${this.pageTitle}`;
    if (this.hasNav) {
      const activeNavItemTitle = this.navItems.find(it => this.navItemIsActive(it)).title;
      this.titleService.setTitle(`${pageTitle} / ${activeNavItemTitle}`);
    } else {
      this.titleService.setTitle(`${pageTitle}`);
    }

    this.differ = this.differs.find([]).create(null);

    this.paginator.reRender.pipe(takeUntil(this.destroyed$)).subscribe(() => {
      this.items = this.sliceItems(this.dataSource);
      // const viewContainer = this.rowOutlet.viewContainer;
      // let currentIndex = 0;
      // this.items.forEach(((record) => {
      //   const recordItemKeys = Object.keys(record);
      //   if (this.groupBy && recordItemKeys.length === 1 && recordItemKeys[0] === this.groupBy) {
      //     const componentFactory = this.componentFactoryResolver.resolveComponentFactory(ClassifierRowGroupHeaderComponent);
      //     viewContainer.createComponent(componentFactory, currentIndex!, null, [[
      //       this.renderer.createText(record[this.groupBy])
      //     ]]);
      //   } else {
      //     const cxt = new DataSourcerContext(record, record.currentIndex);
      //     viewContainer.createEmbeddedView(this.rowDef.template, cxt, currentIndex!);
      //   }
      //   currentIndex++;
      // }));
    });
    this.loading = false;

    this.zone.runOutsideAngular(() => {
      const classifierListElem = this.classifierList.nativeElement;
      const filterFormElem = this.filterForm.nativeElement;
      fromEvent(this.document, 'scroll').pipe(takeUntil(this.destroyed$)).subscribe(() => {
        const filterFormSticky = filterFormElem.offsetTop + filterFormElem.clientHeight > classifierListElem.offsetTop;
        filterFormElem.classList.toggle('sticky', filterFormSticky);
      });
    });
  }

  ngAfterContentInit(): void {
    this.filterFormOutlet.viewContainer.createEmbeddedView(this.filterFormDef.template);
    this.actionsOutlet.viewContainer.createEmbeddedView(this.actionsDef.template);
  }

  ngOnChanges(changes: SimpleChanges): void {
    console.log('oncahges')
    if (changes.dataSource && changes.dataSource.currentValue) {
      if (this.groupBy) {
        this.dataSource = this.dataSource.sort(this.sortFn);
      }
      if (!this.paginate) {
        this.paginator.pageSize = this.dataSource.length;
      }
      this.paginator.length = this.dataSource.length;
      this.items = this.sliceItems(this.dataSource);
      // Эта необходимость может возникнуть при удалении последнего элемента на странице.
      if (!this.items.length && this.paginator.pageIndex > 0) {
        this.paginator.changePage(this.paginator.pageIndex - 1);
      }
      this.loading = false;
    }
  }

  ngDoCheck() {
    const changes = this.differ.diff(this.items);
    if (!changes) return;
    const viewContainer = this.rowOutlet.viewContainer;
    changes.forEachOperation(((record, prevIndex, currentIndex) => {
      if (record.previousIndex == null) { // added
        const recordItemKeys = Object.keys(record.item);
        if(this.groupBy && recordItemKeys.length == 1 && recordItemKeys[0] == this.groupBy) {
          const componentFactory = this.componentFactoryResolver.resolveComponentFactory(ClassifierRowGroupHeaderComponent);
          viewContainer.createComponent(componentFactory, currentIndex!, null, [[
            this.renderer.createText(record.item[this.groupBy])
          ]]);
        } else {
          const cxt = new DataSourcerContext(record.item, record.currentIndex);
          viewContainer.createEmbeddedView(this.rowDef.template, cxt, currentIndex!);
        }
      } else if (currentIndex == null) { // removed
        viewContainer.remove(prevIndex!);
      } else { // moved
        const view = viewContainer.get(prevIndex!);
        viewContainer.move(view!, currentIndex);
      }
    }));
  }

  navItemIsActive(navItem: NavItem): boolean {
    let childRoute = this.router.createUrlTree([navItem.routeLink], {relativeTo: this.route});
    return this.router.isActive(childRoute, true);
  }

  ngOnDestroy(): void {
    this.destroyed$.next();
  }

  private sliceItems(items: any[]): any[] {
    const startIndex = this.paginator.pageIndex * this.paginator.pageSize;
    items = items.slice(startIndex, startIndex + this.paginator.pageSize);

    if (!this.groupBy) {
      return items;
    }

    const groupedItems = [];
    const groups = [];

    items.forEach(item => {
      if (groups.indexOf(item[this.groupBy]) < 0) {
        groupedItems.push({[this.groupBy]: item[this.groupBy]});
        groups.push(item[this.groupBy]);
      }
      groupedItems.push(item);
    });

    return groupedItems;
  }

}
