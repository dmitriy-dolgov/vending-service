import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import {
  ClassifierComponent,
  ClassifierRowOutlet,
  ClassifierActionsOutlet,
  ClassifierFilterFormOutlet,
  ClassifierRowComponent,
  ClassifieActionsDef,
  ClassifierRowDef,
  ClassifieFilterFormDef,
  ClassifierRowGroupHeaderComponent
} from '@app/components/classifier/classifier.component';
import {BaseModule} from '@app/base.module';
import {FormsModule} from '@angular/forms';

const exports = [
  ClassifierComponent,
  ClassifierRowComponent,
  ClassifieActionsDef,
  ClassifieFilterFormDef,
  ClassifierRowDef
];

@NgModule({
  declarations: [
    ClassifierRowOutlet,
    ClassifierActionsOutlet,
    ClassifierFilterFormOutlet,
    ClassifierRowGroupHeaderComponent,
    ...exports
  ],
  imports: [
    BaseModule,
    CommonModule,
    FormsModule
  ],
  exports: exports,
  entryComponents: [
    ClassifierRowGroupHeaderComponent
  ]
})
export class ClassifierModule { }
