import {Component, Inject, OnInit} from '@angular/core';
import {MAT_DIALOG_DATA, MatDialog, MatDialogRef, MatOptionSelectionChange} from '@angular/material';
import {TasksService} from '@app/services/tasks.service';
import {City, Client, Division, Region} from '@app/models';
import {Observable} from 'rxjs';
import {FormControl, FormGroup, Validators} from '@angular/forms';
import {AppValidators} from '@app/validators';
import {map, startWith} from 'rxjs/operators';
import {FormDialogComponent} from '@app/components/dialogs/FormDialogComponent';
import {ClassifierEditorService} from '@app/services/classifier-editor.service';

interface DivisionFormDialogData {
  description?: string;
  division?: Division;
  city?: City;
}

@Component({
  selector: 'app-division-form-dialog',
  templateUrl: './division-form-dialog.component.html',
  styleUrls: ['./division-form-dialog.component.scss']
})
export class DivisionFormDialogComponent extends FormDialogComponent implements OnInit {

  cities: Observable<City[]>;
  regions: Observable<Region[]>;
  clients: Observable<Client[]>;
  division: Division;
  form: FormGroup;
  submited = false;

  private readonly controls: {[name: string]: FormControl} = {
    city: new FormControl('', [
      AppValidators.isModel,
      Validators.required
    ]),
    region: new FormControl('', [
      AppValidators.isModel
    ]),
    client: new FormControl('', [
      AppValidators.isModel
    ]),
    address: new FormControl('', [
      AppValidators.noWhitespaceValidator,
      Validators.required
    ]),
    description: new FormControl('', [
      AppValidators.noWhitespaceValidator,
      Validators.required,
    ])
  };

  constructor(
    protected dialogRef: MatDialogRef<DivisionFormDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: DivisionFormDialogData,
    private classifierEditor: ClassifierEditorService,
    private tasksService: TasksService
  ) {
    super();
    this.division = data.division;
  }

  static openAsDialog(dialog: MatDialog, data: DivisionFormDialogData = {}){
    return dialog.open(DivisionFormDialogComponent, {
      disableClose: true,
      autoFocus: false,
      width: '900px',
      height: 'auto',
      data
    });
  }

  addCity(e: MatOptionSelectionChange) {
    const control = this.controls.city;
    this.classifierEditor.addCity(control.value).subscribe(city => {
      control.setValue(city);
    });
  }

  addClient(e: MatOptionSelectionChange) {
    const control = this.controls.client;
    this.classifierEditor.addClient(control.value).subscribe(client => {
      control.setValue(client);
    });
  }

  getForm(): FormGroup {
    return this.form;
  }

  ngOnInit() {
    this.form = new FormGroup(this.controls);
    this.formFill(true);
    this.initAutocompletes();
  }

  initAutocompletes() {
    this.cities = this.controls.city.valueChanges.pipe(
      // startWith(''),
      map((v: City|string) => {
        const val = (v || '').toString().trim().toLowerCase();
        return !val ? this.tasksService.cities.slice() : this.tasksService.cities.filter(city => {
          return city.description.toLowerCase().includes(val);
        });
      })
    );

    this.regions = this.controls.region.valueChanges.pipe(
      // startWith(''),
      map((v: Region|string) => {
        const val = (v || '').toString().trim().toLowerCase();
        return !val ? this.tasksService.regions.slice() : this.tasksService.regions.filter(region => {
          return region.description.toLowerCase().includes(val);
        });
      })
    );

    this.clients = this.controls.client.valueChanges.pipe(
      // startWith(''),
      map((v: Client|string) => {
        const val = (v || '').toString().trim().toLowerCase();
        return !val ? this.tasksService.clients.slice() : this.tasksService.clients.filter(client => {
          return client.description.toLowerCase().includes(val);
        });
      })
    );
  }

  formSubmit() {
    if(this.form.valid) {
      this.submited = true;

      (
        this.division
          ? this.division.update(this.form.value)
          : Division.create(this.tasksService, this.form.value)

      ).subscribe((division: Division) => {

        this.division = division;
        this.dialogRef.close(division);

      });

    }
  }

  formReset() {
    this.form.reset();
    this.formFill();
  }

  formFill(setDefault = false) {
    if(this.division) {
      this.controls.city.setValue(this.division.city);
      this.controls.region.setValue(this.division.region);
      this.controls.client.setValue(this.division.client);
      this.controls.address.setValue(this.division.address);
      this.controls.description.setValue(this.division.description);
    } else if(setDefault) {
      (['city', 'description', 'region', 'client']).forEach(k => {
        if(this.data[k]) this.controls[k].setValue(this.data[k]);
      });
    }
  }

}
