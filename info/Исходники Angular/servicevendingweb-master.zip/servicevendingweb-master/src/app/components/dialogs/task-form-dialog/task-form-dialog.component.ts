import {Component, Inject, OnInit, QueryList, ViewChildren} from '@angular/core';
import {MAT_DIALOG_DATA, MatAutocompleteTrigger, MatDialog, MatDialogRef, MatOptionSelectionChange} from '@angular/material';
import {AbstractControl, FormControl, FormGroup, Validators} from '@angular/forms';
import {City, Division, Machine, MachineType, Model, Task, User} from '@app/models';
import {AuthenticationService} from '@app/services/authentication.service';
import {TaskFilterService} from '@app/services/task-filter.service';
import {TasksService} from '@app/services/tasks.service';
import {debounceTime, map, startWith} from 'rxjs/operators';
import {Observable, Subject} from 'rxjs';
import {AppValidators} from '@app/validators';
import {TaskFilters, TaskFormData} from '@app/interfaces';
import {LoadingService} from '@app/services/loading.service';
import {DivisionFormDialogComponent} from '@app/components/dialogs/division-form-dialog/division-form-dialog.component';
import {MachineFormDialogComponent} from '@app/components/dialogs/machine-form-dialog/machine-form-dialog.component';
import {ClassifierEditorService} from '@app/services/classifier-editor.service';
import * as moment from 'moment';

interface TaskDialogData {
  taskFilters?: TaskFilters,
  task?: Task
}

@Component({
  selector: 'app-task-form-dialog',
  templateUrl: './task-form-dialog.component.html',
  styleUrls: ['./task-form-dialog.component.scss']
})
export class TaskFormDialogComponent implements OnInit {

  @ViewChildren(MatAutocompleteTrigger)
  autocompleteTriggers: QueryList<MatAutocompleteTrigger>;

  machineTypes: Observable<MachineType[]>;
  divisions: Observable<Division[]>;
  machines: Observable<Machine[]>;
  cities: Observable<City[]>;
  users: Observable<User[]>;

  taskFilters: TaskFilters;
  currentUser: User;
  form: FormGroup;
  submited = false;
  task?: Task;

  datepicker = new FormControl('', [
    Validators.required
  ]);

  readonly controls: {[name: string]: FormControl} = {
    machineType: new FormControl('', [
      AppValidators.isModel
    ]),
    city: new FormControl('', [
      AppValidators.isModel
    ]),
    division: new FormControl('', [
      AppValidators.isModel
    ]),
    machine: new FormControl('', [
      AppValidators.isModel,
      Validators.required
    ]),
    worker: new FormControl('', [
      AppValidators.isModel,
      Validators.required
    ]),
    datetime: new FormControl('', [])
  };

  constructor(
    protected dialogRef: MatDialogRef<TaskFormDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: TaskDialogData,
    private classifierEditor: ClassifierEditorService,
    private taskFilterService: TaskFilterService,
    private auth: AuthenticationService,
    private tasksService: TasksService,
    private loading: LoadingService,
    private dialog: MatDialog
  ) {
    this.taskFilters = this.taskFilterService.getFilters();
    this.task = this.data.task;
    this.auth.user.subscribe(user => {
      this.currentUser = this.tasksService.users.find(u => u.iD === user.uid);
    });
  }

  ngOnInit() {

    const controls = this.controls;
    this.form = new FormGroup(controls);
    this.initAutocompletes();

    if(this.task) {
      this.formFill(this.task);
    } else {
      const filters = this.taskFilterService.getFilters();
      controls.worker.setValue(this.currentUser);
      this.datepicker.setValue(moment());
      if(this.data.taskFilters) {
        controls.machineType.setValue(this.data.taskFilters.machineType);
        controls.city.setValue(this.data.taskFilters.city);
        controls.division.setValue(this.data.taskFilters.division);
      } else if(filters) {
        controls.machineType.setValue(filters.machineType);
        controls.city.setValue(filters.city);
        controls.division.setValue(filters.division);
      }
    }
  }

  static openAsDialog(dialog: MatDialog, data: TaskDialogData = {}){
    return dialog.open(TaskFormDialogComponent, {
      disableClose: true,
      autoFocus: false,
      width: '900px',
      height: 'auto',
      // height: '90%',
      data
    });
  }

  addCity(e: MatOptionSelectionChange) {
    const control = this.controls.city;
    this.classifierEditor.addCity(control.value).subscribe(city => {
      control.setValue(city);
    });
  }

  addDivision(e: MatOptionSelectionChange) {
    const control = this.controls.division;

    DivisionFormDialogComponent.openAsDialog(this.dialog, {
      description: control.value,
      city: this.controls.city.value
    }).afterClosed().subscribe((division: Division) => {
      control.setValue(division);
    });

    control.reset();
  }

  addMachine(e: MatOptionSelectionChange) {

    const control = this.controls.machine;

    MachineFormDialogComponent.openAsDialog(this.dialog, {

      machineType: this.controls.machineType.value,
      division: this.controls.division.value,
      city: this.controls.city.value,
      description: control.value

    }).afterClosed().subscribe((machine: Machine) => {
      control.setValue(machine);
    });

    control.reset();
  }

  formSubmit() {
    if(this.form.valid) {
      this.submited = true;

      (this.task
          ? this.task.update(this.currentUser, this.form.value)
          : Task.create(this.tasksService, this.currentUser, this.form.value)
      ).subscribe((task: Task) => {
        this.dialogRef.close(this.task = task);
      });
    }
  }

  formReset() {
    this.form.reset();
    if(this.task) {
      this.formFill(this.task);
    } else {
      this.datepicker.setValue(moment());
    }
  }

  formFill(task: Task) {
    this.controls.machineType.setValue(task.machine.type);
    this.controls.city.setValue(task.machine.division.city);
    this.controls.division.setValue(task.machine.division);
    this.controls.worker.setValue(task.worker);
    this.controls.machine.setValue(task.machine);
    this.datepicker.setValue(moment(task.datetime));
  }

  initAutocompletes() {

    this.initMachineAutocompletes();

    if(!this.isObject(this.controls.city.value)){
      this.controls.division.disable();
    }

    this.controls.city.valueChanges.subscribe((city: City) => {

      this.isObject(this.controls.city.value)
        ? this.controls.division.enable()
        : this.controls.division.disable();

      if(!this.isObject(this.controls.city.value)
        || !this.isObject(this.controls.division.value)
        || (<Division>this.controls.division.value).city.iD != (<City>this.controls.city.value).iD
      ){
        this.controls.division.reset();
      }

    });

    const autocompletes: {

      [key: string]: {
        formControl: AbstractControl,
        filter?: (v: any) => Model[],
        collectionName?: string
      };

    } = {
      machineTypes: {formControl: this.controls.machineType},
      users: {formControl: this.controls.worker},
      cities: {formControl: this.controls.city},
      divisions: {
        formControl: this.controls.division,
        filter: (value: string) => {
          const city = this.controls.city.value as City|null;
          return !this.isObject(city) ? [] : (
            !value ? city.divisions.slice() : city.divisions.filter((division: Division) => {
              return division.fullDescription.toLowerCase().includes(value);
            })
          );
        }
      }
    };

    Object.entries(autocompletes).forEach(
      ([listKey, {formControl, filter, collectionName = listKey}]) => {

        if(!filter) {
          filter = (value) => {
            if(!value) return this.tasksService[collectionName].slice();
            return this.tasksService[collectionName].filter((model: Model) => {
              return model.toString().toLowerCase().includes(value);
            });
          }
        }

        this[listKey] = formControl.valueChanges.pipe(
          // startWith(''),
          map((v: Model|string) => {
            return filter((v || '').toString().trim().toLowerCase());
          })
        );
      }
    );
  }

  initMachineAutocompletes() {
    const allSubject = new Subject<Machine[]>();
    const refSubject = new Subject<Machine[]>();

    this.controls.machine.valueChanges.subscribe(value => {
      if(this.isObject(value)) {
        const machine = <Machine>value;
        this.controls.machineType.setValue(machine.type);
        this.controls.division.setValue(machine.division);
        this.controls.city.setValue(machine.division.city);
      }
    });

    (['machineType', 'city', 'division', 'machine']).forEach(controlName => {
      this.controls[controlName].valueChanges.subscribe(() => {
        allSubject.next();
      });
    });

    (['machineType', 'city', 'division']).forEach(controlName => {
      this.controls[controlName].valueChanges.subscribe(() => {
        refSubject.next();
      });
    });

    refSubject.asObservable().pipe(debounceTime(100)).subscribe(() => {
      if(!this.autocompleteMachinesFilter().length) {
        this.controls.machine.reset();
      }
    });

    this.machines = allSubject.asObservable().pipe(
      debounceTime(100),
      startWith(''),
      map(() => this.autocompleteMachinesFilter())
    );
  }

  isObject(v) {
    return v && typeof v == 'object';
  }

  toggleAutocompletePanel(event: MouseEvent, trigger: MatAutocompleteTrigger, formControlName :string) {
    event.stopPropagation();
    this.autocompleteTriggers.forEach(t => {
      if(t.autocomplete.isOpen) {
        t.closePanel();
      } else if(t == trigger) {
        this.form.controls[formControlName].reset();
        t.openPanel();
      }
    });
  }

  autocompleteDisplayWithMachines(machine: Machine) {
    return machine ? machine.fullDescription : undefined;
  }

  autocompleteDisplayWithDivision(division: Division) {
    return division ? division.fullDescription : undefined;
  }

  private autocompleteMachinesFilter():Machine[] {
    const machine = this.form.controls.machine.value as Machine|null;
    const machineType = this.form.controls.machineType.value as MachineType|null;
    const division = this.form.controls.division.value as Division|null;
    const city = this.form.controls.city.value as City|null;
    let machines: Machine[];

    if(this.isObject(division)) {
      machines = division.machines;
    } else if(this.isObject(city)) {
      machines = city.machines;
    } else {
      machines = this.tasksService.machines.slice();
    }

    if(this.isObject(machineType)) {
      machines = machines.filter(machine => machine.type.iD == machineType.iD);
    }

    const machineDescription = this.isObject(machine) ? machine.fullDescription : (machine || '');
    const machineValue = machineDescription.toString().trim().toLowerCase();

    return !machineValue ? machines.slice() : machines.filter((machine: Machine) => {
      return machine.fullDescription.toLowerCase().includes(machineValue);
    });
  }

}
