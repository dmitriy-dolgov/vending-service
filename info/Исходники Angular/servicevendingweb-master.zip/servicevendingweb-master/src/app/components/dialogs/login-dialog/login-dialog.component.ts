import {Component, ElementRef, Inject, OnInit, ViewChild} from '@angular/core';
import {MAT_DIALOG_DATA, MatDialog, MatDialogRef} from '@angular/material';
import {LoggerService} from '@app/services/logger.service';
import {FormControl, Validators} from '@angular/forms';
import {AngularFireAuth} from '@angular/fire/auth';
import {Router} from '@angular/router';
import * as fb from 'firebase/app';
import {AppValidators} from '@app/validators';

@Component({
  selector: 'app-login-dialog',
  templateUrl: './login-dialog.component.html',
  styleUrls: ['./login-dialog.component.scss']
})
export class LoginDialogComponent implements OnInit {

  @ViewChild('phoneField') phoneField: ElementRef<HTMLElement>;
  @ViewChild('codeField') codeField: ElementRef<HTMLElement>;
  @ViewChild('recaptcha') recaptcha: ElementRef<HTMLElement>;
  recaptchaVerifier: fb.auth.RecaptchaVerifier;
  authConfirmation: fb.auth.ConfirmationResult;
  verificationError = null;
  phoneSubmited = false;
  codeSubmited = false;
  showSpinner = false;
  authError = null;

  phoneFormControl = new FormControl('', [
    Validators.required,
    AppValidators.noWhitespaceValidator,
    AppValidators.phoneValidator()
  ]);

  codeFormControl = new FormControl('', [
    Validators.required,
    Validators.pattern(/^\d{6}$/),
    AppValidators.noWhitespaceValidator
  ]);

  constructor(
    protected dialogRef: MatDialogRef<LoginDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private afAuth: AngularFireAuth,
    private logger: LoggerService,
    private router: Router
  ) {
  }

  static openAsDialog(dialog: MatDialog, {disableClose = true, data = {}} = {}) {
    return dialog.open(LoginDialogComponent, {
      panelClass: 'login-dialog',
      hasBackdrop: true,
      autoFocus: false,
      width: 'auto',
      height: 'auto',
      disableClose,
      data
    });
  }

  ngOnInit() {
    try {
      this.recaptchaVerifier = new fb.auth.RecaptchaVerifier('recaptcha-container', {
        'expired-callback': resp => { this.logger.log('recaptcha expired', resp) },
        callback: resp => {},
        // size: 'invisible'
      });
    } catch (e) {
      this.logger.log('RecaptchaVerifier taskNotExists$ ', e);
    }
  }

  telephoneFormSubmit() {
    this.phoneSubmited = true;
    if (this.phoneFormControl.valid) {
      this.verifyPhoneNumber(AppValidators.clearPhone(this.phoneFormControl));
    }
  }

  verifyPhoneNumber(phoneNumber: string) {

    phoneNumber = phoneNumber.toString();

    if(phoneNumber.length === 10 || Number(String(phoneNumber).slice(-11, 1)) == 8) {
      phoneNumber = `7${String(phoneNumber).slice(-10, 11)}`;
    }

    if (!/^\+/.test(phoneNumber)) {
      phoneNumber = `+${phoneNumber}`;
    }

    this.afAuth.auth.signInWithPhoneNumber(phoneNumber, this.recaptchaVerifier)
      .then((confirm: fb.auth.ConfirmationResult) => {
        this.authConfirmation = confirm;
        setTimeout(() => {
          this.codeField.nativeElement.focus();
        }, 1);
      })
      .catch(e => {
        // https://firebase.google.com/docs/reference/js/firebase.auth.Error
        if (e.code === 'auth/too-many-requests') {
          this.verificationError = 'Ваш номер заблокирован из-за необычной активности. Попробуйте позже.';
        } else {
          this.verificationError = e.message;
        }
        this.logger.log('Auth Verifier', e);
      })
      .finally(() => {
        this.showSpinner = false;
        // @todo-arman Форма не переключается, ошибки не отображаются, пока поле телефона не получит фокус.
        // Пока профиксена так.
        this.phoneField.nativeElement.focus();
      });
  }

  codeFormSubmit() {
    this.codeSubmited = true;
    this.authError = '';
    if (this.codeFormControl.valid) {
      this.showSpinner = true;
      this.authConfirmation.confirm(this.codeFormControl.value)
        .then((credential: fb.auth.UserCredential) => {
          this.dialogRef.close(credential.user);
          this.recaptchaVerifier.clear();
        })
        .catch(e => {
          if (e.code === 'auth/invalid-verification-code') {
            this.authError = 'Неверный код авторизации';
          } else {
            this.authError = e.message;
          }
          this.codeField.nativeElement.focus();
          this.logger.log('Auth confirm', e);
        })
        .finally(() => {
          this.showSpinner = false;
        });
    }
  }
}
