import {Component, Inject, OnInit} from '@angular/core';
import {MAT_DIALOG_DATA, MatDialog, MatDialogRef} from '@angular/material';
import {AsyncValidatorFn, FormControl, FormGroup, ValidatorFn, Validators} from '@angular/forms';
import {AppValidators} from '@app/validators';

export class PromptDialogData {
  header?: string;
  placeholder?: string;
  value?: string;
  btnText?: string;
  validators?: ValidatorFn[] | AsyncValidatorFn[];
  isEdit?: boolean;
}

@Component({
  selector: 'app-prompt-dialog',
  templateUrl: './prompt-dialog.component.html',
  styleUrls: ['./prompt-dialog.component.scss']
})
export class PromptDialogComponent implements OnInit {

  form: FormGroup;
  submited = false;

  private readonly controls: {[name: string]: FormControl} = {
    description: new FormControl('', [
        ...(this.data.validators || []),
      AppValidators.noWhitespaceValidator,
      Validators.required,
    ])
  };

  constructor(
    protected dialogRef: MatDialogRef<PromptDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: PromptDialogData
  ) { }

  static openAsDialog(dialog: MatDialog, data: PromptDialogData = {}){
    return dialog.open(PromptDialogComponent, {
      disableClose: true,
      autoFocus: false,
      width: '900px',
      height: 'auto',
      data
    });
  }

  ngOnInit() {
    this.form = new FormGroup(this.controls);
    if(this.data.value) {
      this.controls.description.setValue(this.data.value);
    }
  }

  formSubmit() {
    if(this.form.valid) {
      this.dialogRef.close(this.controls.description.value);
    }
  }

  formReset() {
    this.form.reset();
  }

}
