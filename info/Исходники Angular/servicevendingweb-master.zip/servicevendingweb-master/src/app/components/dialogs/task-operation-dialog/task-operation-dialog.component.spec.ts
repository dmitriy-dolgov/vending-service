import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TaskOperationDialogComponent } from './task-operation-dialog.component';

describe('TaskOperationDialogComponent', () => {
  let component: TaskOperationDialogComponent;
  let fixture: ComponentFixture<TaskOperationDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TaskOperationDialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TaskOperationDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
