import {Component, Inject, OnInit} from '@angular/core';
import {MAT_DIALOG_DATA, MatDialog, MatDialogRef} from '@angular/material';

interface AlertDialogData {
  message: string;
  btnText?: string;
}

@Component({
  selector: 'app-alert-dialog',
  templateUrl: './alert-dialog.component.html',
  styleUrls: ['./alert-dialog.component.scss']
})
export class AlertDialogComponent implements OnInit {

  constructor(
    protected dialogRef: MatDialogRef<AlertDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: AlertDialogData
  ) { }

  ngOnInit() {
  }

  static openAsDialog(dialog: MatDialog, message: string, btnText?: string){
    return dialog.open(AlertDialogComponent, {
      data: {message, btnText},
      disableClose: true,
      autoFocus: true,
      width: '600px',
      height: 'auto',
    });
  }

}
