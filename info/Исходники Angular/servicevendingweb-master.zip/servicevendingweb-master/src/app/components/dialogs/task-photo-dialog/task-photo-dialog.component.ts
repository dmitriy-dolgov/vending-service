import {Component, ElementRef, Inject, OnInit, ViewChild} from '@angular/core';
import {MAT_DIALOG_DATA, MatDialog, MatDialogRef} from '@angular/material';
import {TasksService} from '@app/services/tasks.service';
import {Task, TaskPhoto} from '@app/models';
import {fromEvent} from 'rxjs';
import {LoadingService} from '@app/services/loading.service';
import {ConfirmDialogComponent} from '@app/components/dialogs/confirm-dialog/confirm-dialog.component';
import {ActivatedRoute} from '@angular/router';

interface TaskPhotoDialogData {
  currentPhoto: TaskPhoto;
  task: Task;
}

@Component({
  selector: 'app-task-photo-dialog',
  templateUrl: './task-photo-dialog.component.html',
  styleUrls: ['./task-photo-dialog.component.scss']
})
export class TaskPhotoDialogComponent implements OnInit {

  @ViewChild('photoImage') photoImage: ElementRef<HTMLImageElement>;

  currentPhoto: TaskPhoto;
  currentIndex: number;
  isVertical: boolean;
  photos: TaskPhoto[];

  get hasPrevPhoto() {
    return this.photos && this.currentIndex > 0;
  }

  get hasNextPhoto() {
    return this.photos && this.currentIndex + 1 < this.photos.length;
  }

  constructor(
    protected dialogRef: MatDialogRef<TaskPhotoDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: TaskPhotoDialogData,
    private tasksService: TasksService,
    private loading: LoadingService,
    private dialog: MatDialog
  ) {
    this.currentPhoto = this.data.currentPhoto;
    this.data.task.photos.subscribe(photos => {
      this.photos = photos;
      if(!photos.length) {
        this.dialogRef.close();
      } else if(!this.currentPhoto) {
        this.currentIndex = photos.length - 1;
        this.currentPhoto = photos[this.currentIndex];
      } else if(typeof this.currentIndex == 'undefined') {
        this.currentIndex = photos.indexOf(photos.find(p => p.gUID === this.currentPhoto.gUID));
      }
    });
  }

  ngOnInit() {
    this.loading.show();
    const image = this.photoImage.nativeElement;

    fromEvent(image, 'load').subscribe(() => {
      this.dialogRef.removePanelClass('loading');
      this.isVertical = image.height >= image.width;
      this.loading.hide();
    });
  }

  static openAsDialog(dialog: MatDialog, task: Task, currentPhoto: TaskPhoto){
    return dialog.open(TaskPhotoDialogComponent, {
      panelClass: ['task-photo-dialog', 'loading'],
      disableClose: true,
      autoFocus: false,
      height: 'auto',
      width: 'auto',
      data: {
        currentPhoto,
        task
      }
    });
  }

  prevPhoto() {
    if(this.hasPrevPhoto) {
      this.loading.show();
      this.currentPhoto = this.photos[--this.currentIndex];
    }
  }

  nextPhoto() {
    if(this.hasNextPhoto) {
      this.loading.show();
      this.currentPhoto = this.photos[++this.currentIndex];
    }
  }

  removePhoto() {
    ConfirmDialogComponent.openAsDialog(this.dialog, {
      message: 'Вы уверены, что хотите удалить фотографию?',
      btnText: 'Удалить фотографию'
    }).afterClosed().subscribe(confirm => {
      if(confirm) {
        this.loading.show();
        this.currentPhoto.remove().subscribe(() => {
          if(this.photos.length) {
            this.currentIndex = Math.min(this.currentIndex, this.photos.length - 1);
            this.currentPhoto = this.photos[this.currentIndex];
          } else {
            this.loading.hide();
            this.dialogRef.close();
          }
        });
      }
    });
  }

}
