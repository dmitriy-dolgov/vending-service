import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DivisionFormDialogComponent } from './division-form-dialog.component';

describe('DivisionFormDialogComponent', () => {
  let component: DivisionFormDialogComponent;
  let fixture: ComponentFixture<DivisionFormDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DivisionFormDialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DivisionFormDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
