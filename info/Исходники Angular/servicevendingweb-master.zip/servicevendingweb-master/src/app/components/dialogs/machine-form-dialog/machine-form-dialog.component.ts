import {Component, Inject, OnInit} from '@angular/core';
import {MAT_DIALOG_DATA, MatDialog, MatDialogRef, MatOptionSelectionChange} from '@angular/material';
import {DivisionFormDialogComponent} from '@app/components/dialogs/division-form-dialog/division-form-dialog.component';
import {City, Division, Machine, MachineModel, MachineType, Model} from '@app/models';
import {AbstractControl, FormControl, FormGroup, Validators} from '@angular/forms';
import {TasksService} from '@app/services/tasks.service';
import {AppValidators} from '@app/validators';
import {map, startWith} from 'rxjs/operators';
import {Observable} from 'rxjs';
import {FormDialogComponent} from '@app/components/dialogs/FormDialogComponent';
import {LoadingService} from '@app/services/loading.service';
import {ClassifierEditorService} from '@app/services/classifier-editor.service';


export interface MachineFormDialogData {
  machineType?: MachineType;
  serialNumber?: string;
  description?: string;
  division?: Division;
  machine?: Machine;
  city?: City;
}

@Component({
  selector: 'app-machine-form-dialog',
  templateUrl: './machine-form-dialog.component.html',
  styleUrls: ['./machine-form-dialog.component.scss']
})
export class MachineFormDialogComponent extends FormDialogComponent implements OnInit {

  machineTypes: Observable<MachineType[]>;
  machineModels: Observable<MachineModel[]>;
  divisions: Observable<Division[]>;
  cities: Observable<City[]>;

  form: FormGroup;
  submited = false;

  private readonly controls: {[name: string]: FormControl} = {
    machineType: new FormControl('', [
      AppValidators.isModel,
      Validators.required
    ]),
    machineModel: new FormControl('', [
      AppValidators.isModel,
      Validators.required
    ]),
    city: new FormControl('', [
      AppValidators.isModel,
      Validators.required
    ]),
    division: new FormControl('', [
      AppValidators.isModel,
      Validators.required
    ]),
    serialNumber: new FormControl('', [
      AppValidators.noWhitespaceValidator,
      Validators.required,
    ]),
    description: new FormControl('', [
      AppValidators.noWhitespaceValidator,
      Validators.required,
    ]),
    comment: new FormControl('', [
      AppValidators.noWhitespaceValidator
    ])
  };

  machine: Machine;

  constructor(
    protected dialogRef: MatDialogRef<MachineFormDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: MachineFormDialogData,
    private classifierEditor: ClassifierEditorService,
    private tasksService: TasksService,
    private loading: LoadingService,
    private dialog: MatDialog
  ) {
    super();
    this.machine = data.machine;
  }

  static openAsDialog(dialog: MatDialog, data: MachineFormDialogData = {}){
    return dialog.open(MachineFormDialogComponent, {
      disableClose: true,
      autoFocus: false,
      width: '900px',
      height: 'auto',
      data
    });
  }

  getForm(): FormGroup {
    return this.form;
  }

  ngOnInit() {

    const controls = this.controls;
    this.form = new FormGroup(controls);
    this.initAutocompletes();
    this.formFill(true);

    controls.machineModel.valueChanges.subscribe((value: MachineModel) => {
      if(controls.machineModel.valid && !controls.description.value) {
        controls.description.setValue(value.description);
      }
    });
  }

  addCity(e: MatOptionSelectionChange) {
    const control = this.controls.city;
    this.classifierEditor.addCity(control.value).subscribe(city => {
      control.setValue(city);
    });
  }

  addDivision(e: MatOptionSelectionChange) {
    const control = this.controls.division;

    DivisionFormDialogComponent.openAsDialog(this.dialog, {
      description: control.value,
      city: this.controls.city.value
    }).afterClosed().subscribe((division: Division) => {
      control.setValue(division);
    });

    control.reset();
  }

  addMachineModel(e: MatOptionSelectionChange) {
    const control = this.controls.machineModel;
    this.classifierEditor.addMachineModel(control.value).subscribe(machineModel => {
      control.setValue(machineModel);
    });
  }

  formSubmit() {

    if(this.form.valid) {
      this.submited = true;

      (
        this.machine
          ? this.machine.update(this.form.value)
          : Machine.create(this.tasksService, this.form.value)

      ).subscribe((machine: Machine) => {

        this.machine = machine;
        this.dialogRef.close(machine);

      });

    }
  }

  formReset() {
    this.form.reset();
    this.formFill();
  }

  formFill(setDefault = false) {
    if(this.machine) {
      this.controls.machineType.setValue(this.machine.type);
      this.controls.machineModel.setValue(this.machine.model);
      this.controls.city.setValue(this.machine.division.city);
      this.controls.division.setValue(this.machine.division);
      this.controls.serialNumber.setValue(this.machine.serialNumber);
      this.controls.description.setValue(this.machine.description);
      this.controls.comment.setValue(this.machine.comment);
    } else if(setDefault) {
      (['machineType', 'city', 'division', 'serialNumber', 'description', 'comment']).forEach(k => {
        if(this.data[k]) this.controls[k].setValue(this.data[k]);
      });
    }
  }

  initAutocompletes() {

    if(!this.isObject(this.controls.city.value)){
      this.controls.division.disable();
    }

    this.controls.city.valueChanges.subscribe((city: City) => {
      this.isObject(this.controls.city.value) ? this.controls.division.enable() : this.controls.division.disable();
      if(this.controls.division.value) this.controls.division.reset();
    });

    const autocompletes: {

      [key: string]: {
        formControl: AbstractControl,
        filter?: (v: any) => Model[],
        collectionName?: string
      };

    } = {
      machineTypes: {formControl: this.controls.machineType},
      machineModels: {formControl: this.controls.machineModel},
      cities: {formControl: this.controls.city},
      divisions: {
        formControl: this.controls.division,
        filter: (value: string) => {
          const city = this.controls.city.value as City|null;
          return !this.isObject(city) ? [] : (
            !value ? city.divisions.slice() : city.divisions.filter((division: Division) => {
              return division.description.toLowerCase().includes(value);
            })
          );
        }
      }
    };

    Object.entries(autocompletes).forEach(
      ([listKey, {formControl, filter, collectionName = listKey}]) => {

        if(!filter) {
          filter = (value) => {
            if(!value) return this.tasksService[collectionName].slice();
            return this.tasksService[collectionName].filter((model: Model) => {
              return model.toString().toLowerCase().includes(value);
            });
          }
        }

        this[listKey] = formControl.valueChanges.pipe(
          // startWith(''),
          map((v: Model|string) => {
            return filter((v || '').toString().trim().toLowerCase());
          })
        );
      }
    );
  }

}
