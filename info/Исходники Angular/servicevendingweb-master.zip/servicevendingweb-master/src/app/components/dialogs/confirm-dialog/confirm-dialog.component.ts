import {Component, Inject, OnInit} from '@angular/core';
import {MAT_DIALOG_DATA, MatDialog, MatDialogRef} from '@angular/material';

interface ConfirmDialogData {
  message: string;
  btnText?: string;
}

@Component({
  selector: 'app-confirm-dialog',
  templateUrl: './confirm-dialog.component.html',
  styleUrls: ['./confirm-dialog.component.scss']
})
export class ConfirmDialogComponent implements OnInit {

  constructor(
    protected dialogRef: MatDialogRef<ConfirmDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: ConfirmDialogData
  ) { }

  ngOnInit() {
  }

  static openAsDialog(dialog: MatDialog, data: ConfirmDialogData){
    return dialog.open(ConfirmDialogComponent, {
      disableClose: true,
      autoFocus: true,
      width: '600px',
      height: 'auto',
      data
    });
  }

  confirm() {
    this.dialogRef.close(true);
  }

}
