import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TaskPhotoDialogComponent } from './task-photo-dialog.component';

describe('TaskPhotoDialogComponent', () => {
  let component: TaskPhotoDialogComponent;
  let fixture: ComponentFixture<TaskPhotoDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TaskPhotoDialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TaskPhotoDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
