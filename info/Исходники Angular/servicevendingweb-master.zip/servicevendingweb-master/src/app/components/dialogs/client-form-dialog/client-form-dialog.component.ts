import {Component, Inject, OnInit} from '@angular/core';
import {FormControl, FormGroup, Validators} from '@angular/forms';
import {MAT_DIALOG_DATA, MatDialog, MatDialogRef} from '@angular/material';
import {ClientFormData, ClientStatus} from '@app/interfaces';
import {TasksService} from '@app/services/tasks.service';
import {Client} from '@app/models';

interface ClientFormDialogData {
  status?: ClientStatus,
  description?: string,
  client?: Client
}

@Component({
  selector: 'app-client-form-dialog',
  templateUrl: './client-form-dialog.component.html',
  styleUrls: ['./client-form-dialog.component.scss']
})
export class ClientFormDialogComponent implements OnInit {

  statuses: ClientStatus[];
  form: FormGroup;
  submited = false;
  client?: Client;

  private readonly controls: {[name: string]: FormControl} = {
    status: new FormControl('', [ Validators.required ]),
    description: new FormControl('', [ Validators.required ]),
  };

  constructor(
    protected dialogRef: MatDialogRef<ClientFormDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: ClientFormDialogData,
    private tasksService: TasksService
  ) {
    this.client = data.client;
    this.statuses = tasksService.clientStatuses;
  }

  static openAsDialog(dialog: MatDialog, data: ClientFormDialogData = {}){
    return dialog.open(ClientFormDialogComponent, {
      disableClose: true,
      autoFocus: false,
      width: '900px',
      height: 'auto',
      data
    });
  }

  ngOnInit() {
    this.form = new FormGroup(this.controls);
    this.formFill(true);
  }

  formSubmit() {
    if(this.form.valid) {
      this.submited = true;

      (this.client
          ? this.client.update(<ClientFormData>this.form.value)
          : Client.create(this.tasksService, <ClientFormData>this.form.value)
      ).subscribe((client: Client) => {
        this.dialogRef.close(this.client = client);
      });

    }
  }

  formReset() {
    this.form.reset();
    this.formFill();
  }

  formFill(setDefault = false) {
    if(this.client) {
      this.controls.status.setValue(this.client.status);
      this.controls.description.setValue(this.client.description);
    } else if(setDefault) {
      (['status', 'description']).forEach(k => {
        if(this.data[k]) this.controls[k].setValue(this.data[k]);
      });
    }
  }

}
