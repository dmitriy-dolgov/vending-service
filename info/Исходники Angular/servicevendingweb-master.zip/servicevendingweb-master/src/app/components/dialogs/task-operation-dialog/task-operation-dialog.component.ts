import {Component, Inject, OnInit} from '@angular/core';
import {MAT_DIALOG_DATA, MatDialog, MatDialogRef} from '@angular/material';
import {FormControl, FormGroup, Validators} from '@angular/forms';
import {TasksService} from '@app/services/tasks.service';
import {OperationType, Task} from '@app/models';
import {Observable} from 'rxjs';
import {map, startWith} from 'rxjs/operators';
import {AppValidators} from '@app/validators';
import {FormDialogComponent} from '@app/components/dialogs/FormDialogComponent';


interface TaskOperationDialogData {
  task: Task
}

@Component({
  selector: 'app-task-operation-dialog',
  templateUrl: './task-operation-dialog.component.html',
  styleUrls: ['./task-operation-dialog.component.scss']
})
export class TaskOperationDialogComponent extends FormDialogComponent implements OnInit {

  operationTypes: Observable<OperationType[]>;
  form: FormGroup;
  loading = false;
  task: Task;

  constructor(
    protected dialogRef: MatDialogRef<TaskOperationDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: TaskOperationDialogData,
    private tasksService: TasksService
  ) {
    super();
    this.task = this.data.task;
  }

  getForm(): FormGroup {
    return this.form;
  }

  ngOnInit() {
    const controls = {
      operationType: new FormControl('', [
        AppValidators.isModel,
        Validators.required
      ]),
      description: new FormControl('', [

      ])
    };

    this.form = new FormGroup(controls);
    const operationTypes = this.tasksService.operationTypes;

    this.operationTypes = controls.operationType.valueChanges.pipe(
      startWith(''),
      map((v: OperationType|string) => {
        const value = (v || '').toString().trim().toLowerCase();
        return !value ? operationTypes.slice() : operationTypes.filter(operation => {
          return operation.description.toLowerCase().includes(value);
        });
      })
    );

    controls.operationType.valueChanges.subscribe((value: OperationType) => {
      if(controls.operationType.valid && (!controls.description.value || !controls.description.dirty)) {
        controls.description.setValue(value.description);
      }
    });
  }

  static openAsDialog(dialog: MatDialog, task: Task){
    return dialog.open(TaskOperationDialogComponent, {
      disableClose: true,
      autoFocus: false,
      width: '900px',
      height: 'auto',
      data: {task}
    });
  }

  addNewTaskOperation() {
    if(this.form.valid) {
      this.loading = true;
      this.task.addOperation(this.form.value).subscribe(() => {
        this.dialogRef.close();
      });
    }
  }

}
