import {QueryList, ViewChildren} from '@angular/core';
import {MatAutocompleteTrigger} from '@angular/material';
import {FormGroup} from '@angular/forms';

export abstract class FormDialogComponent {

  @ViewChildren(MatAutocompleteTrigger)
  autocompleteTriggers: QueryList<MatAutocompleteTrigger>;

  abstract getForm(): FormGroup;

  toggleAutocompletePanel(event: MouseEvent, trigger: MatAutocompleteTrigger, formControlName :string) {
    event.stopPropagation();
    this.autocompleteTriggers.forEach(t => {
      if(t.autocomplete.isOpen) {
        t.closePanel();
      } else if(t == trigger) {
        this.getForm().controls[formControlName].reset();
        t.openPanel();
      }
    });
  }

  isObject(v) {
    return v && typeof v == 'object';
  }
}
