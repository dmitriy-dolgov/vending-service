import {Component, Input, OnInit} from '@angular/core';
import {ThemePalette} from '@angular/material';

export enum SpinnerModes {DETERMINATE = 'determinate', INDETERMINATE = 'indeterminate'}
export type SpinnerModeType = SpinnerModes.DETERMINATE | SpinnerModes.INDETERMINATE;

@Component({
  selector: 'app-spinner',
  template: `
      <div class="spinner">
          <mat-progress-spinner [color]="color" [strokeWidth]="strokeWidth" [mode]="mode" [value]="progress"></mat-progress-spinner>
      </div>`,
  styleUrls: ['./spinner.component.scss']
})
export class SpinnerComponent implements OnInit {

  @Input() mode: SpinnerModeType = SpinnerModes.INDETERMINATE;
  @Input() progress: number = 0;
  color: ThemePalette = 'primary';
  strokeWidth = 3;

  constructor() {
  }

  ngOnInit() {
  }

}
