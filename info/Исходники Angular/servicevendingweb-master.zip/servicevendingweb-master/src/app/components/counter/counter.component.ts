import {Component, EventEmitter, forwardRef, Input, OnInit, Output} from '@angular/core';
import {ControlValueAccessor, NG_VALUE_ACCESSOR} from '@angular/forms';

@Component({
  selector: 'app-counter',
  template: `
      <button (click)="decrement()" class="btn" [disabled]="disabled">-</button>
      <div class="value">{{ value }}</div>
      <button (click)="increment()" class="btn" [disabled]="disabled">+</button>
  `,
  styleUrls: ['./counter.component.scss'],
  providers: [{
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => CounterComponent),
    multi: true
  }],
  host: {
    'class': 'app-counter',
    '[class.disabled]': 'disabled'
  }
})
export class CounterComponent implements OnInit, ControlValueAccessor {

  @Output() change = new EventEmitter<number>();

  @Input() disabled: boolean = false;
  @Input() value: number = 0;
  @Input() min: number;
  @Input() max: number;

  onTouched: any = () => {};
  onChange: any = () => {};

  constructor() { }

  ngOnInit() {
  }

  registerOnTouched(fn: any): void {
    this.onTouched = fn;
  }

  registerOnChange(fn: any): void {
    this.onChange = fn;
  }

  setDisabledState(isDisabled: boolean): void {
    this.disabled = isDisabled;
  }

  writeValue(value: number): void {
    this.value = value;
  }

  increment() {
    if(typeof this.max != 'number' || this.value < this.max) {
      this.change.emit(++this.value);
    }
  }

  decrement() {
    if(typeof this.min != 'number' || this.value > this.min) {
      this.change.emit(--this.value);
    }
  }

}
