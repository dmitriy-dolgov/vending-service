import {
  City,
  Client,
  ClientStatusType,
  Division,
  Machine,
  MachineModel,
  MachineType,
  Region,
  Task,
  TaskStateTypes,
  User
} from '@app/models';
import * as moment from 'moment';

export interface NavItem {
  routeLink: string;
  title: string;
  active?: boolean;
  icon?: string;
}

export interface TaskFilters {
  machineType?: MachineType;
  city?: City;
  division?: Division|string;
  author?: User;
  worker?: User;
  states?: TaskStateTypes[];
  dateFrom?: moment.Moment;
  dateTo?: moment.Moment;
}

export interface TaskFormData {
  machine: Machine;
  worker: User;
  datetime?: moment.Moment;
}

export interface MachineFormData {
  machineModel: MachineModel;
  machineType: MachineType;
  division: Division;
  description: string;
  serialNumber: string;
  comment?: string;
}

export interface DivisionFormData {
  city: City;
  region?: Region;
  client?: Client;
  address: string;
  description: string;
}

export interface ClientFormData {
  status: ClientStatusType;
  description: string;
}

export interface ClientStatus {
  id: ClientStatusType;
  title: string;
}
