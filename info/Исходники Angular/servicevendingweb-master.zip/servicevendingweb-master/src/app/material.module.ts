import { NgModule } from '@angular/core';
import {
  MatButtonModule,
  MatCheckboxModule,
  MatDialogModule,
  MatProgressSpinnerModule,
  MatInputModule,
  MatDatepickerModule, DateAdapter, MAT_DATE_LOCALE, MAT_DATE_FORMATS,
  MatAutocompleteModule,
  MatListModule,
  MatMenuModule,
  MatSelectModule,
  MatTooltipModule
} from '@angular/material';
import {MomentDateAdapter} from '@angular/material-moment-adapter';
import * as momentConf from '@src/environments/moment';

@NgModule({
  providers: [
    {provide: DateAdapter, useClass: MomentDateAdapter, deps: [MAT_DATE_LOCALE]},
    {provide: MAT_DATE_FORMATS, useValue: momentConf.DATEPICKER_FORMATS},
    {provide: MAT_DATE_LOCALE, useValue: momentConf.LOCALE},
  ],
  declarations: [],
  exports: [
    MatButtonModule,
    MatCheckboxModule,
    MatDialogModule,
    MatProgressSpinnerModule,
    MatInputModule,
    MatDatepickerModule,
    MatAutocompleteModule,
    MatListModule,
    MatMenuModule,
    MatSelectModule,
    MatTooltipModule
  ],
})
export class MaterialModule { }
