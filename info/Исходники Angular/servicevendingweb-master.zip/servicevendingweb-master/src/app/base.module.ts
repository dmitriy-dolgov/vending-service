import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {IconComponent} from '@app/components/icon/icon.component';
import {SpinnerComponent} from '@app/components/spinner/spinner.component';
import {MaterialModule} from '@app/material.module';
import {PaginatorModule} from '@app/components/paginator/paginator.module';
import {RouterModule} from '@angular/router';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {DateFormatPipe, DateTimeFormatPipe, TimeFormatPipe} from '@app/pipes/moment.pipes';
import {SearchNotFoundComponent} from '@app/components/search-not-found/search-not-found.component';
import {QuickAddTaskModule} from '@app/components/quick-add-task/quick-add-task.module';

@NgModule({
  declarations: [
    IconComponent,
    SpinnerComponent,
    SearchNotFoundComponent,
    DateTimeFormatPipe,
    DateFormatPipe,
    TimeFormatPipe
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MaterialModule,
    PaginatorModule,
    QuickAddTaskModule
  ],
  exports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule,
    MaterialModule,
    PaginatorModule,
    IconComponent,
    SpinnerComponent,
    SearchNotFoundComponent,
    DateTimeFormatPipe,
    DateFormatPipe,
    TimeFormatPipe,
    QuickAddTaskModule
  ],
  entryComponents: [
    SearchNotFoundComponent,
    SpinnerComponent
  ]
})
export class BaseModule { }
