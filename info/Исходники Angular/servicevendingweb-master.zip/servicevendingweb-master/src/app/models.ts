import {TasksService} from './services/tasks.service';
import {map, switchMap, take} from 'rxjs/operators';
import {forkJoin, from, Observable, of} from 'rxjs';
import * as firebase from 'firebase';
import * as moment from 'moment';
import {ClientFormData, DivisionFormData, MachineFormData, TaskFormData} from '@app/interfaces';
import {AngularFireObject, QueryFn} from '@angular/fire/database';

export abstract class Model {
  constructor(
    protected tasksService: TasksService,
    private _collectionName?: string
  ) {
  }

  abstract get uid(): string | number;

  abstract toString(): string;

  get collectionName(): string | undefined {
    return this._collectionName;
  }
}

export enum ActionType {
  ADDED = 'child_added',
  CHANGED = 'child_changed',
  MOVED = 'child_moved',
  REMOVED = 'child_removed'
}

export enum TaskStateTypes {
  CREATED,
  PERFORMED, // Выполняется
  FINISHED,
  REMOVED
}

export type TaskStateType = TaskStateTypes;

export enum TaskOperationStateTypes {
  PENDING,
  FINISHED,
  REMOVED
}

export type TaskOperationStateType = TaskOperationStateTypes;

export enum ServiceStateTypes {
  IN_EXPLOITATION = 1, // в эксплуатации
  DEFECTIVE = 2, // Неисправен
  ON_SERVICE = 3, // На обслуживании
  ON_CONSERVATION = 4 // На консервации
}

export type ServiceStateType = ServiceStateTypes;

export enum MachineStateTypes {
  IN_PAUSE = 1, // в простое
  IDLE_WORK = 2, // Работа в холостую
  WORK_BY_PLAN = 3, // Работа по плану
  CRASH = 4 // Авария
}

export type MachineStateType = MachineStateTypes;

export enum TaskPhotoStates { CREATED, REMOVED}

export type TaskPhotoStateType = TaskPhotoStates.CREATED | TaskPhotoStates.REMOVED;

export enum ClientStatuses {
  CRUCIAL = 1, // Ключевой
  SIGNIFICANT = 2, // Значимый
  STANDARD = 3 // Стандартный
}

export type ClientStatusType = ClientStatuses;

export class Task extends Model {
  gUID: string;
  authorUserID: string;
  lastChangeUserID: string;
  workerUserID: string;
  changedOnClient: boolean;
  machineID: number;
  state: TaskStateType;
  timeChanged: number;
  timeCreated: number;
  timeFinished: number;
  operationsText: string;
  private _operations: Observable<TaskOperation[]>;
  private _photos: Observable<TaskPhoto[]>;

  get uid(): string {
    return this.gUID;
  }

  toString(): string {
    return this.gUID;
  }

  get machine(): Machine {
    return this.tasksService.machines.find(machine => Number(machine.iD) === Number(this.machineID));
  }

  get author(): User | undefined {
    return this.tasksService.users.find(user => user.iD === this.authorUserID);
  }

  get lastChangeUser(): User | undefined {
    return this.tasksService.users.find(user => user.iD === this.lastChangeUserID);
  }

  get worker(): User | undefined {
    return this.tasksService.users.find(user => user.iD === this.workerUserID);
  }

  get status(): TaskState {
    return this.tasksService.taskStates.find(state => Number(state.iD) === Number(this.state));
  }

  private get photoStoragePath() {
    return `/taskPhotos/${this.machineID}/${this.gUID}`;
  }

  get isFinished(): boolean {
    return this.state === TaskStateTypes.FINISHED;
  }

  get datetime(): number {
    switch (this.state) {
      case TaskStateTypes.CREATED:
        return this.timeCreated;

      case TaskStateTypes.FINISHED:
        return this.timeFinished;

      default:
        return this.timeChanged;
    }
  }

  get finishedOperations(): Observable<TaskOperation[]> {
    return this.operations.pipe(map(operations => operations.filter(
      operation => operation.state == TaskOperationStateTypes.FINISHED
    )));
  }

  get operations(): Observable<TaskOperation[]> {

    if (!this._operations) {
      this._operations = this.getList<TaskOperation>(TaskOperation, 'serviceOperations', ref => {
        return ref.orderByChild('orderID');
      }).pipe(
        map(operations => operations.filter(
          operation => operation.state != TaskOperationStateTypes.REMOVED
        ))
      );
    }

    return this._operations;
  }

  set operations(operations) {

    this._operations = operations;
  }

  get photos(): Observable<TaskPhoto[]> {
    if (!this._photos) {
      this._photos = this.getList<TaskPhoto>(TaskPhoto, 'taskPhotos', ref => {
        return ref.orderByChild('orderID');
      }).pipe(
        map(photos => photos.filter(p => p.state !== TaskPhotoStates.REMOVED))
      );
    }
    return this._photos;
  }

  private get fireObject(): AngularFireObject<Task> {
    return this.tasksService.fireObject<Task>(`/tasks/${this.gUID}`);
  }

  static create(tasksService: TasksService, editor: User, formData: TaskFormData): Observable<Task> {
    const newTaskID = tasksService.db.createPushId();
    const collectionName = 'tasks';

    const data = {
      gUID: newTaskID,
      machineID: formData.machine.iD,
      workerUserID: formData.worker.iD,
      lastChangeUserID: editor.iD,
      authorUserID: editor.iD,
      state: TaskStateTypes.CREATED,
      changedOnClient: true,

      timeCreated: moment.utc().valueOf(),
      timeChanged: 0,
      timeFinished: 0
    };

    if (formData.datetime) {
      data.timeCreated = formData.datetime.utc().valueOf();
    }

    return from(new Promise((resolve, error) => {
      tasksService.fireObject<any>(`/${collectionName}/${newTaskID}`).set(data).then(() => {
        resolve(Object.assign(new Task(tasksService, collectionName), data));
      }, error);
    }));
  }

  update(editor: User, formData: TaskFormData): Observable<Task> {
    const data: any = {
      workerUserID: formData.worker.iD,
      machineID: formData.machine.iD,
      lastChangeUserID: editor.iD,
      changedOnClient: true,

      timeChanged: moment.utc().valueOf()
    };

    if (formData.datetime) {
      if (this.state == TaskStateTypes.CREATED) {
        data.timeCreated = formData.datetime.utc().valueOf();
      } else if (this.state == TaskStateTypes.FINISHED) {
        data.timeFinished = formData.datetime.utc().valueOf();
      } else {
        data.timeChanged = formData.datetime.utc().valueOf();
      }
    }

    return from(new Promise((resolve, error) => {
      this.tasksService.fireObject<any>(`/tasks/${this.gUID}`).update(data).then(() => {
        resolve(Object.assign(this, data));
      }, error);
    }));
  }

  addPhoto(file: File, author: firebase.User, progress?: (percent: number) => void): Observable<any> {

    const fileName = `${String(Math.random()).slice(2)}.${file.type.split('/')[1]}`;
    const path = `${this.photoStoragePath}/${fileName}`;
    const fileRef = this.tasksService.storage.ref(path);
    const upload = fileRef.put(file);

    if (progress) {
      upload.percentageChanges().subscribe(progress);
    }

    return from(new Promise((resolve, error) => {

      from(upload.then()).pipe(
        switchMap(() => fileRef.getDownloadURL())
      ).subscribe(downloadURL => {

        const taskPhoto = this.tasksService.fireList<any>(`/taskPhotos/${this.gUID}`);
        const newTaskPhotoID = this.tasksService.db.createPushId();

        return taskPhoto.valueChanges().pipe(
          take(1),
          map(photos => photos.length + 1)
        ).subscribe(orderID => {

          taskPhoto.set(newTaskPhotoID, {

            gUID: newTaskPhotoID,
            authorUserID: author.uid,
            orderID: orderID,
            photoUrl: downloadURL,
            size: 0,
            state: TaskPhotoStates.CREATED,
            taskGUID: this.gUID,
            timeChanged: 0,
            timeCreated: moment.utc().valueOf()

          }).then(() => {
            this.fireObject.update({timeChanged: moment.utc().valueOf()}).then(resolve);
          }, error);

        });

      });

    }));
  }

  addOperation(data: { operationType: OperationType, description: string }): Observable<TaskOperation> {
    const taskOperations = this.tasksService.fireList<any>(`/serviceOperations/${this.gUID}`);
    const newTaskOperationID = this.tasksService.db.createPushId();

    return from(new Promise((resolve, error) => {

      taskOperations.valueChanges().pipe(
        take(1),
        map(operations => operations.length + 1)
      ).subscribe(orderID => {

        const taskOperationData = {
          description: data.description.trim() || data.operationType.description,
          operationTypeID: data.operationType.iD,
          state: TaskOperationStateTypes.PENDING,
          mark: data.operationType.defaultMark,
          gUID: newTaskOperationID,
          taskGUID: this.gUID,
          timeFinished: 0,
          orderID
        };

        taskOperations.set(newTaskOperationID, taskOperationData).then(() => {
          resolve(Object.assign(new TaskOperation(this.tasksService), taskOperationData));
        }, error);

      });

    }));
  }

  changeState(state: TaskStateType): Observable<any> {
    switch (state) {
      case TaskStateTypes.CREATED:
        return from(this.fireObject.update({state, timeCreated: moment.utc().valueOf()}));
      case TaskStateTypes.PERFORMED:
      case TaskStateTypes.REMOVED:
        return from(this.fireObject.update({state, timeChanged: moment.utc().valueOf()}));
      case TaskStateTypes.FINISHED:
        return from(this.fireObject.update({state, timeFinished: moment.utc().valueOf()}));
    }
  }

  remove() {
    return this.changeState(TaskStateTypes.REMOVED);
  }

  forceRemove(): Observable<void> {

    return from(new Promise((resolve, reject) => {

      forkJoin([
        this.getList<TaskOperation>(TaskOperation, 'serviceOperations').pipe(take(1)),
        this.getList<TaskPhoto>(TaskPhoto, 'taskPhotos').pipe(take(1)),
        of(true)
      ]).subscribe(([operations, photos]) => {

        forkJoin([
          from(this.fireObject.remove()),
          ...operations.map(operation => operation.forceRemove()),
          ...photos.map(photo => photo.forceRemove()),
          of(true)
        ]).subscribe(() => {
          resolve();
        }, reject);

      }, reject);

    }));
  }

  private getList<T extends Model>(
    model: { new(tasksService: TasksService, collectionName: string): T; },
    name: string,
    queryFn?: QueryFn
  ): Observable<T[]> {
    return this.tasksService.getList<T>(model, `/${name}/${this.gUID}`, queryFn);
  }
}

export class TaskState {
  constructor(public iD: TaskStateType, public title: string) {
  }

  toString() {
    return this.title;
  }
}

export class Machine extends Model {
  iD: number;
  divisionID: number;
  modelID: number;
  typeID: number;
  serviceStateID: number;
  stateID: number;
  description: string;
  serialNumber: string;
  timeChanged: number;
  comment?: string;
  redDate: number;
  orangeDate: number;
  private _tasks: Observable<Task[]>;

  get uid(): number {
    return Number(this.iD);
  }

  get division(): Division {
    return this.tasksService.divisions.find(division => Number(division.iD) === Number(this.divisionID));
  }

  get state(): MachineState {
    return this.tasksService.machineStates.find(state => Number(state.iD) === Number(this.stateID));
  }

  get type(): MachineType {
    return this.tasksService.machineTypes.find(type => Number(type.iD) === Number(this.typeID));
  }

  get model(): MachineModel {
    return this.tasksService.getCollection<MachineModel>('machineModels').items.find(model => {
      return Number(model.iD) === Number(this.modelID);
    });
  }

  get fullDescription(): string {
    return `${this.division.fullAddress} (${this.serialNumber || this.description})`;
  }

  get fireObject(): AngularFireObject<Machine> {
    return this.tasksService.fireObject<Machine>(`/machines/${this.iD}`);
  }

  get tasks(): Observable<Task[]> {
    if (!this._tasks) {
      this._tasks = this.tasksService.tasks.pipe(map(
        tasks => tasks.filter(task => Number(task.machineID) === Number(this.iD))
      ));
    }
    return this._tasks;
  }

  toString() {
    return this.description;
  }

  static create(tasksService: TasksService, formData: MachineFormData): Observable<Machine> {
    return tasksService.getCollection<Machine>('machines').addItem({
      serviceStateID: ServiceStateTypes.IN_EXPLOITATION,
      stateID: MachineStateTypes.WORK_BY_PLAN,
      divisionID: formData.division.iD,
      modelID: formData.machineModel.iD,
      typeID: formData.machineType.iD,
      description: formData.description,
      serialNumber: formData.serialNumber,
      comment: formData.comment,
      timeChanged: 0
    });
  }

  update(formData: MachineFormData): Observable<Machine> {
    const data = {
      divisionID: formData.division.iD,
      modelID: formData.machineModel.iD,
      typeID: formData.machineType.iD,
      description: formData.description,
      serialNumber: formData.serialNumber,
      timeChanged: moment.utc().valueOf(),
      comment: formData.comment
    };

    return from(new Promise((resolve, error) => {
      this.tasksService.fireObject<any>(`/machines/${this.iD}`).update(data).then(() => {
        resolve(Object.assign(this, data));
      }, error);
    }));
  }

  changeState(state: MachineStateType): Observable<any> {
    return from(this.tasksService.fireObject<Machine>(`/machines/${this.iD}`).update({stateID: state}));
  }

  remove(): Observable<boolean> {
    return from(new Promise((resolve, reject) => {

      this.tasks.pipe(take(1)).subscribe(tasks => {
        if (tasks.find(task => task.state != TaskStateTypes.REMOVED)) {
          reject('Оборудование используется!');
        } else {
          forkJoin([...tasks.map(task => task.forceRemove()), of(true)]).subscribe(() => {
            this.fireObject.remove().then(() => resolve(true), reject);
          });
        }

      });

    }));
  }
}

export class MachineModel extends Model {
  iD: number;
  description: string;

  get uid(): number {
    return Number(this.iD);
  }

  toString(): string {
    return this.description;
  }

  static create(tasksService: TasksService, description: string): Observable<MachineModel> {
    return tasksService.getCollection<MachineModel>('machineModels').addItem({description});
  }

  update(description: string): Observable<MachineModel> {
    const data = {description};
    return from(new Promise((resolve, error) => {
      this.tasksService.fireObject<any>(`/machineModels/${this.iD}`).update(data).then(() => {
        resolve(Object.assign(this, data));
      }, error);
    }));
  }
}

export class MachineType extends Model {
  iD: number;
  description: string;
  iconName: string;

  get uid(): number {
    return Number(this.iD);
  }

  get icon(): string {
    return require(`../assets/icons/${this.iconName}.png`);
  }

  toString() {
    return this.description;
  }
}

export class MachineState extends Model {
  iD: MachineStateTypes;
  description: string;
  iconName: string;

  get uid(): number {
    return Number(this.iD);
  }

  get icon(): string {
    return require(`../assets/icons/${this.iconName}.png`);
  }

  toString() {
    return this.description;
  }
}

/**
 * Район города
 */
export class Region extends Model {
  iD: number;
  description: string;

  get uid(): number {
    return Number(this.iD);
  }

  get divisions(): Division[] {
    return this.tasksService.divisions.filter(d => Number(d.regionID) === Number(this.iD));
  }

  toString() {
    return this.description;
  }
}

export class Division extends Model {
  iD: number;
  cityID: number;
  regionID?: number;
  clientID?: number;
  address: string;
  description: string;
  gPSLocationX: number;
  gPSLocationY: number;
  timeChanged: number;

  get uid(): number {
    return Number(this.iD);
  }

  get city(): City {
    return this.tasksService.cities.find(city => Number(city.iD) === Number(this.cityID));
  }

  get machines(): Machine[] {
    return this.tasksService.machines.filter(m => Number(m.division.iD) === Number(this.iD));
  }

  get client(): Client | null {
    return !this.clientID ? null : this.tasksService.clients.find(c => Number(c.iD) === Number(this.clientID));
  }

  get fullDescription(): string {
    return `${this.description} (${this.fullAddress})`;
  }

  get fullAddress() {
    return /(^\s*|\s+|,\s*)г\./i.test(this.address) ? this.address : `${this.address}, г. ${this.city}`;
  }

  get region(): Region | null {
    return !this.regionID ? null : this.tasksService.regions.find(r => Number(r.iD) === Number(this.regionID));
  }

  toString() {
    return this.description;
  }

  static create(tasksService: TasksService, formData: DivisionFormData): Observable<Division> {
    return tasksService.getCollection<Division>('divisions').addItem({
      cityID: formData.city.iD,
      regionID: formData.region ? formData.region.iD : 0,
      clientID: formData.client ? formData.client.iD : 0,
      address: formData.address,
      description: formData.description,
      gPSLocationX: 0,
      gPSLocationY: 0,
      timeChanged: 0
    });

  }

  update(formData: DivisionFormData): Observable<Division> {
    const data = {
      cityID: formData.city.iD,
      regionID: formData.region ? formData.region.iD : 0,
      clientID: formData.client ? formData.client.iD : 0,
      address: formData.address,
      description: formData.description,
      timeChanged: moment.utc().valueOf()
    };

    return from(new Promise((resolve, error) => {
      this.tasksService.fireObject<any>(`/divisions/${this.iD}`).update(data).then(() => {
        resolve(Object.assign(this, data));
      }, error);
    }));
  }

  remove(): Observable<void> {
    return from(this.tasksService.fireObject<any>(`/divisions/${this.iD}`).remove());
  }
}

export class City extends Model {
  iD: number;
  description: string;

  get uid(): number {
    return Number(this.iD);
  }

  get divisions(): Division[] {
    return this.tasksService.divisions.filter(d => d.cityID == this.iD);
  }

  get machines(): Machine[] {
    return this.tasksService.machines.filter(m => m.division.city.iD == this.iD);
  }

  toString() {
    return this.description;
  }

  static create(tasksService: TasksService, description: string): Observable<City> {
    return tasksService.getCollection<City>('cities').addItem({description});
  }

  update(description: string): Observable<City> {
    const data = {description};
    return from(new Promise((resolve, error) => {
      this.tasksService.fireObject<any>(`/cities/${this.iD}`).update(data).then(() => {
        resolve(Object.assign(this, data));
      }, error);
    }));
  }
}

export class User extends Model {
  iD: string;
  email: string;
  name: string;
  phoneNumber: string;
  role: number;
  timeChanged: number;

  get uid(): string {
    return this.iD;
  }

  get displayName(): string {
    return this.name.trim() || this.email.trim() || this.formatedPhoneNumber;
  }

  get formatedPhoneNumber() {
    const phoneRegexp = /^(\+\d)(\d{3})(\d{3})(\d{2})(\d{2})$/;
    return this.phoneNumber.trim().replace(phoneRegexp, '$1 ($2) $3-$4-$5');
  }

  toString() {
    return this.displayName;
  }
}

export class OperationType extends Model {
  iD: string;
  description: string;
  shortName: string;
  defaultMark: number;

  get uid(): string {
    return this.iD;
  }

  get fullDescription() {
    return `${this.description} (${this.shortName})`;
  }

  toString(): string {
    return this.fullDescription;
  }
}

export interface TaskOperationStateChangePayload {
  taskCompleted: boolean;
  completedCount: number;
}

export class TaskOperation extends Model {
  gUID: string;
  taskGUID: string;
  operationTypeID: string;
  description: string;
  orderID: number;
  state: TaskOperationStateType;
  timeFinished: number;
  private _mark: number;
  get mark(): number {
    return this._mark || this.operationType.defaultMark || 1;
  }

  set mark(value: number) {
    this._mark = value;
  }

  get uid(): string {
    return this.gUID;
  }

  toString(): string {
    return this.description;
  }

  get operationType(): OperationType {
    return this.operationTypeID
      ? this.tasksService.operationTypes.find(t => t.iD === this.operationTypeID)
      : this.tasksService.operationTypes.find(t => t.description === this.description);
  }

  get isFinished(): boolean {
    return this.state == TaskOperationStateTypes.FINISHED;
  }

  get task(): Observable<Task> {
    return this.tasksService.tasks.pipe(take(1), map((tasks: Task[]) => {
      return tasks.find(task => task.gUID === this.taskGUID);
    }));
  }

  private get path(): string {
    return `/serviceOperations/${this.taskGUID}/${this.gUID}`;
  }

  get fireObject(): AngularFireObject<TaskOperation> {
    return this.tasksService.fireObject<TaskOperation>(this.path);
  }

  changeMark(mark: number) {
    return from(this.tasksService.fireObject<TaskOperation>(this.path).update({mark}));
  }

  changeState(data: { state: TaskOperationStateType, timeFinished?: number }): Observable<TaskOperationStateChangePayload> {

    return from(new Promise((resolve, error) => {

      this.fireObject.update(data).then(() => {

        forkJoin([
          this.task.pipe(switchMap(task => task.operations.pipe(take(1)))),
          this.task
        ]).subscribe(([taskOperations, task]) => {

          const payload: TaskOperationStateChangePayload = {
            completedCount: taskOperations.filter(o => o.state == TaskOperationStateTypes.FINISHED).length,
            taskCompleted: taskOperations.every(o => o.state == TaskOperationStateTypes.FINISHED)
          };

          const taskState = payload.taskCompleted ? TaskStateTypes.FINISHED : TaskStateTypes.PERFORMED;
          task.changeState(taskState).subscribe(() => {
            resolve(payload)
          });

        });

      }, error);

    }));
  }

  remove(): Observable<void> {
    return from(new Promise(resolve => {
      this.changeState({state: TaskOperationStateTypes.REMOVED}).subscribe(() => resolve());
    }));
  }

  forceRemove(): Observable<void> {
    return from(this.fireObject.remove());
  }
}

export class TaskPhoto extends Model {
  gUID: string;
  authorUserID: string;
  orderID: number;
  photoUrl: string;
  size: number;
  state: TaskPhotoStateType;
  taskGUID: string;
  timeChanged: number;
  timeCreated: number;

  get uid(): string | number {
    return this.gUID;
  }

  get author(): User | undefined {
    return this.tasksService.users.find(user => user.iD === this.authorUserID);
  }

  get storagePath(): string {
    const regexp = new RegExp(`(\\/taskPhotos\\/\\d+\\/${this.taskGUID}\\/[^?]+)`);
    return decodeURIComponent(this.photoUrl).match(regexp)[0];
  }

  get path(): string {
    return `/taskPhotos/${this.taskGUID}/${this.gUID}`;
  }

  toString(): string {
    return this.photoUrl;
  }

  get fireObject(): AngularFireObject<TaskPhoto> {
    return this.tasksService.fireObject<TaskPhoto>(this.path);
  }

  remove(): Observable<void> {
    return from(this.fireObject.update({
      state: TaskPhotoStates.REMOVED,
      timeChanged: moment.utc().valueOf()
    }));
  }

  forceRemove(): Observable<void> {
    return from(new Promise((resolve, reject) => {
      forkJoin([
        this.fireObject.remove(),
        this.tasksService.storage.ref(this.storagePath).delete()
      ]).subscribe(() => resolve(), reject);
    }));
  }
}

export class Client extends Model {

  static readonly DEFAULT_STATUS = ClientStatuses.STANDARD;

  iD: number;
  description: string;

  get uid(): number {
    return Number(this.iD);
  }

  private _status: ClientStatusType;
  get status(): ClientStatuses {
    return this._status || Client.DEFAULT_STATUS;
  }

  set status(value: ClientStatuses) {
    this._status = value;
  }

  get statusTitle(): string {
    return this.tasksService.clientStatuses.find(status => status.id === Number(this.status)).title;
  }

  toString(): string {
    return this.description;
  }

  static create(tasksService: TasksService, data: ClientFormData): Observable<Client> {
    return tasksService.getCollection<Client>('clients').addItem(data);
  }

  update(data: ClientFormData): Observable<Client> {
    return from(new Promise((resolve, error) => {
      this.tasksService.fireObject<any>(`/clients/${this.iD}`).update(data).then(() => {
        resolve(Object.assign(this, data));
      }, error);
    }));
  }
}
