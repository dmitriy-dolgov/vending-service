import {NgModule} from '@angular/core';
import {Routes, RouterModule} from '@angular/router';
import {LoginPageComponent} from './pages/login-page/login-page.component';
import {HomePageComponent} from './pages/home-page/home-page.component';
import {AuthGuard} from './services/auth.guard';
import {LoginDialogComponent} from './components/dialogs/login-dialog/login-dialog.component';
import {TestPageComponent} from './pages/test-page/test-page.component';
import {TaskDetailsPageComponent} from './pages/task-details-page/task-details-page.component';
import {NotFoundPageComponent} from './pages/not-found-page/not-found-page.component';
import {TaskListPageComponent} from './pages/task-list-page/task-list-page.component';
import {TaskPhotosPageComponent} from './pages/task-photos-page/task-photos-page.component';
import {TaskOperationsPageComponent} from './pages/task-operations-page/task-operations-page.component';
import {TaskOperationDialogComponent} from './components/dialogs/task-operation-dialog/task-operation-dialog.component';
import {ConfirmDialogComponent} from './components/dialogs/confirm-dialog/confirm-dialog.component';
import {AlertDialogComponent} from '@app/components/dialogs/alert-dialog/alert-dialog.component';
import {TaskFormDialogComponent} from './components/dialogs/task-form-dialog/task-form-dialog.component';
import {MachineFormDialogComponent} from './components/dialogs/machine-form-dialog/machine-form-dialog.component';
import {DivisionFormDialogComponent} from './components/dialogs/division-form-dialog/division-form-dialog.component';
import {TaskPhotoDialogComponent} from './components/dialogs/task-photo-dialog/task-photo-dialog.component';
import {PromptDialogComponent} from './components/dialogs/prompt-dialog/prompt-dialog.component';
import {BaseModule} from '@app/base.module';
import {ReportPageComponent} from './pages/report-page/report-page.component';
import {CounterComponent} from './components/counter/counter.component';
import {ClassifierModule} from '@app/components/classifier/classifier.module';
import {ClientFormDialogComponent} from './components/dialogs/client-form-dialog/client-form-dialog.component';

const routes: Routes = [
  {
    path: '', canActivate: [AuthGuard], children: [
      {path: '', redirectTo: '/tasks', pathMatch: 'full'},
      {
        path: 'tasks', component: TaskListPageComponent, children: [
          {path: '', loadChildren: '@app/components/task-list/task-list.module#TaskListModule'},
          {
            path: ':task_id', component: TaskDetailsPageComponent, children: [
              {path: '', component: TaskOperationsPageComponent},
              {path: 'photos', component: TaskPhotosPageComponent},
            ]
          },
        ]
      },
      {path: 'classifier', loadChildren: '@app/pages/classifier-page/classifier-page-routing.module#ClassifierPageRoutingModule'},
      {path: 'report', component: ReportPageComponent},
      {path: 'map', loadChildren: '@app/pages/map-page/map-page.module#MapPageModule'},
      {path: 'test', component: TestPageComponent},
    ]
  },
  {path: 'login', component: LoginPageComponent},
  {path: '**', component: NotFoundPageComponent}
];

@NgModule({
  declarations: [
    HomePageComponent,
    LoginPageComponent,
    LoginDialogComponent,
    TestPageComponent,
    TaskDetailsPageComponent,
    NotFoundPageComponent,
    TaskListPageComponent,
    TaskPhotosPageComponent,
    TaskOperationsPageComponent,
    TaskOperationDialogComponent,
    ConfirmDialogComponent,
    AlertDialogComponent,
    TaskFormDialogComponent,
    MachineFormDialogComponent,
    DivisionFormDialogComponent,
    TaskPhotoDialogComponent,
    PromptDialogComponent,
    ReportPageComponent,
    CounterComponent,
    ClientFormDialogComponent
  ],
  imports: [
    RouterModule.forRoot(routes),
    ClassifierModule,
    BaseModule
  ],
  exports: [
    RouterModule,
    BaseModule
  ],
  entryComponents: [
    LoginDialogComponent,
    TestPageComponent,
    TaskDetailsPageComponent,
    NotFoundPageComponent,
    TaskListPageComponent,
    TaskPhotosPageComponent,
    TaskOperationsPageComponent,
    TaskOperationDialogComponent,
    ConfirmDialogComponent,
    AlertDialogComponent,
    TaskFormDialogComponent,
    TaskPhotoDialogComponent,
    MachineFormDialogComponent,
    DivisionFormDialogComponent,
    PromptDialogComponent,
    ReportPageComponent,
    CounterComponent,
    ClientFormDialogComponent
  ]
})
export class AppRoutingModule {
}
