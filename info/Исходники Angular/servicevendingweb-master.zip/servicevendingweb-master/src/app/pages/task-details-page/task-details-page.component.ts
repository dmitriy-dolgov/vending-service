import {Component, OnDestroy, OnInit} from '@angular/core';
import {TasksService} from '@app/services/tasks.service';
import {ActivatedRoute, Params} from '@angular/router';
import {switchMap, takeUntil} from 'rxjs/operators';
import {Observable, of, Subject} from 'rxjs';
import {Task} from '@app/models';

@Component({
  selector: 'app-task-details-page',
  templateUrl: './task-details-page.component.html',
  styleUrls: ['./task-details-page.component.scss']
})
export class TaskDetailsPageComponent implements OnInit, OnDestroy {

  taskNotExists$ = new Subject<boolean>();
  private destroed$ = new Subject();
  task$: Observable<Task>;
  queryParams: Params;
  taskID: string;
  task: Task;

  constructor(
    private tasksService: TasksService,
    private route: ActivatedRoute
  ) {
    this.taskID = this.route.snapshot.params['task_id'];
    this.queryParams = this.route.snapshot.queryParams;
  }

  ngOnInit() {
    this.task$ = this.tasksService.getTask(this.taskID).pipe(takeUntil(this.destroed$));

    this.task$.subscribe(task => {
      this.task = task;
    }, () => {
      this.taskNotExists$.next(true)
    });
  }

  ngOnDestroy() {
    this.destroed$.next();
  }
}
