import {Component, ElementRef, Inject, OnDestroy, OnInit, ViewChild} from '@angular/core';
import {TasksService} from '@app/services/tasks.service';
import {Subscription} from 'rxjs';
import {ActivatedRoute, Params, Router} from '@angular/router';
import {Task, TaskOperation, TaskOperationStateTypes} from '@app/models';
import {TaskDetailsPageComponent} from '@app/pages/task-details-page/task-details-page.component';
import {MatDialog} from '@angular/material';
import {TaskOperationDialogComponent} from '@app/components/dialogs/task-operation-dialog/task-operation-dialog.component';
import * as moment from 'moment';
import {PaginatorComponent} from '@app/components/paginator/paginator.component';
import {DOCUMENT} from '@angular/common';
import {TaskEditorService} from '@app/services/task-editor.service';
import {ConfirmDialogComponent} from '@app/components/dialogs/confirm-dialog/confirm-dialog.component';
import {Title} from '@angular/platform-browser';

@Component({
  selector: 'app-task-operations-page',
  templateUrl: './task-operations-page.component.html',
  styleUrls: ['./task-operations-page.component.scss']
})
export class TaskOperationsPageComponent implements OnInit, OnDestroy {

  @ViewChild('task_operation_list') taskOperationListElem: ElementRef<HTMLElement>;
  @ViewChild(PaginatorComponent) paginator: PaginatorComponent;
  private _subscriptions: Subscription[] = [];
  pageTaskOperations: TaskOperation[];
  taskOperations: TaskOperation[];
  queryParams: Params;
  task: Task;
  pageTitle = 'Детали задачи';

  constructor(
    @Inject(TaskDetailsPageComponent) private taskDetailsPage: TaskDetailsPageComponent,
    @Inject(DOCUMENT) private document: Document,
    private taskEditor: TaskEditorService,
    private tasksService: TasksService,
    protected titleService: Title,
    private route: ActivatedRoute,
    private dialog: MatDialog,
    private router: Router
  ) {
    this.queryParams = this.route.snapshot.queryParams;
    this.task = this.taskDetailsPage.task;
  }

  ngOnInit() {
    this.titleService.setTitle(this.pageTitle);
    this.taskDetailsPage.task$.subscribe(task => this.task = task);

    this.task.operations.subscribe(operations => {
      this.taskOperations = operations;
      this.paginator.length = operations.length;
      this.sliceTaskOperations();
    });

    this.paginator.page.subscribe(() => {
      this.sliceTaskOperations();
    });
  }

  editTask() {
    this.taskEditor.editTask(this.task);
  }

  removeTask() {
    this.taskEditor.removeTask(this.task, () => {
      this.router.navigate(['/tasks'], {queryParams: this.queryParams});
    });
  }

  operationChangeMark(mark, operation: TaskOperation) {
    operation.changeMark(mark);
  }

  operationChangeState(e: Event, operation: TaskOperation) {
    if((<HTMLInputElement>e.target).checked) {
      operation.changeState({state: TaskOperationStateTypes.FINISHED, timeFinished: moment.utc().valueOf()});
      operation.state = TaskOperationStateTypes.FINISHED;
    } else {
      operation.changeState({state: TaskOperationStateTypes.PENDING, timeFinished: 0});
      operation.state = TaskOperationStateTypes.PENDING;
    }
  }

  addOperation() {
    TaskOperationDialogComponent.openAsDialog(this.dialog, this.task);
  }

  removeOperation(operation: TaskOperation) {
    ConfirmDialogComponent.openAsDialog(this.dialog, {
      message: 'Вы уверены, что хотите удалить операцию?',
      btnText: 'Удалить операцию'
    }).afterClosed().subscribe(confirmed => {
      if(confirmed) {
        operation.remove();
      }
    });
  }

  ngOnDestroy(): void {
    while (this._subscriptions.length) {
      this._subscriptions.pop().unsubscribe();
    }
  }

  private sliceTaskOperations() {
    const scrollTop = this.document.scrollingElement.scrollTop;
    const startIndex = this.paginator.pageIndex * this.paginator.pageSize;
    this.pageTaskOperations = this.taskOperations.slice(startIndex, startIndex + this.paginator.pageSize);
    setTimeout(() => this.document.scrollingElement.scrollTop = scrollTop);
  }
}
