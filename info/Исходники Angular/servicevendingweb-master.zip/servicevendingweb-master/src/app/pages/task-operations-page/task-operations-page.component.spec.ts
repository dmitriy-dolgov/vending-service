import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TaskOperationsPageComponent } from './task-operations-page.component';

describe('TaskOperationsPageComponent', () => {
  let component: TaskOperationsPageComponent;
  let fixture: ComponentFixture<TaskOperationsPageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TaskOperationsPageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TaskOperationsPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
