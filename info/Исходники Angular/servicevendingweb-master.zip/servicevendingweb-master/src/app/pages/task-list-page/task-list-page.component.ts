import { Component, OnInit } from '@angular/core';
import {TasksService} from '@app/services/tasks.service';

@Component({
  selector: 'app-task-list-page',
  templateUrl: './task-list-page.component.html',
  styleUrls: ['./task-list-page.component.scss']
})
export class TaskListPageComponent implements OnInit {

  constructor(public tasksService: TasksService) {
  }

  ngOnInit() {
  }

}
