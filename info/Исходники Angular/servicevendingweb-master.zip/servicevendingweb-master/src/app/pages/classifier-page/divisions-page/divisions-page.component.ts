import {Component, OnDestroy, OnInit, QueryList, ViewChild, ViewChildren} from '@angular/core';
import {TasksService} from '@app/services/tasks.service';
import {City, Division} from '@app/models';
import {Observable, Subscription} from 'rxjs';
import {DivisionFormDialogComponent} from '@app/components/dialogs/division-form-dialog/division-form-dialog.component';
import {MatAutocompleteTrigger, MatDialog, MatOptionSelectionChange} from '@angular/material';
import {AbstractControl, FormControl, FormGroup} from '@angular/forms';
import {AppValidators} from '@app/validators';
import {map, startWith} from 'rxjs/operators';
import {AlertDialogComponent} from '@app/components/dialogs/alert-dialog/alert-dialog.component';
import {ConfirmDialogComponent} from '@app/components/dialogs/confirm-dialog/confirm-dialog.component';
import {ClassifierComponent} from '@app/components/classifier/classifier.component';
import {ClassifierEditorService} from '@app/services/classifier-editor.service';

@Component({
  selector: 'app-divisions-page',
  templateUrl: './divisions-page.component.html',
  styleUrls: ['../classifier-page.component.scss', './divisions-page.component.scss']
})
export class DivisionsPageComponent implements OnInit, OnDestroy {

  @ViewChildren(MatAutocompleteTrigger) autocompleteTriggers: QueryList<MatAutocompleteTrigger>;
  @ViewChild(ClassifierComponent) classifier: ClassifierComponent;

  private _subscriptions: Subscription[] = [];
  cities: Observable<City[]>;
  divisions: Observable<string[]>;
  filteredDivisions: Division[];
  allDivisions: Division[];
  filterForm: FormGroup;

  controls: {[name: string]: AbstractControl} = {
    city: new FormControl('', [AppValidators.isModel]),
    division: new FormControl('', [AppValidators.isModel]),
  };

  constructor(
    private classifierEditor: ClassifierEditorService,
    private tasksService: TasksService,
    private dialog: MatDialog
  ) { }

  ngOnInit() {
    this._subscriptions.push(
      this.tasksService.getCollection<Division>('divisions')
        .valueChanges().subscribe(divisions => {
          this.filteredDivisions = this.filterDivisions(this.allDivisions = divisions);
        })
    );

    this.filterForm = new FormGroup(this.controls);
    this.initAutocompletes();
  }

  addDivision() {
    DivisionFormDialogComponent.openAsDialog(this.dialog);
  }

  editDivision(division: Division) {
    DivisionFormDialogComponent.openAsDialog(this.dialog, {division: division});
  }

  addCity(e: MatOptionSelectionChange) {
    const control = this.controls.city;
    this.classifierEditor.addCity(control.value).subscribe(city => {
      control.setValue(city);
    });
  }

  addDivisionFromCombobox(e: MatOptionSelectionChange) {
    const control = this.controls.division;

    DivisionFormDialogComponent.openAsDialog(this.dialog, {
      description: control.value,
      city: this.controls.city.value
    }).afterClosed().subscribe((division: Division) => {
      control.setValue(division);
    });

    control.reset();
  }

  removeDivision(division: Division) {
    if(this.tasksService.machines.find(machine => Number(machine.divisionID) === Number(division.iD))) {
      AlertDialogComponent.openAsDialog(this.dialog, 'Торговая точка используется.');
    } else {
      ConfirmDialogComponent.openAsDialog(this.dialog, {
        message: 'Вы уверены, что хотите удалить торговую точку?',
        btnText: 'Удалить'
      }).afterClosed().subscribe(confirm => {
        if(confirm) {
          division.remove();
        }
      });
    }
  }

  filterFormSubmit() {
    this.filteredDivisions = this.filterDivisions(this.allDivisions);
    this.classifier.paginator.changePage(0);
  }

  ngOnDestroy(): void {
    while (this._subscriptions.length) {
      this._subscriptions.pop().unsubscribe();
    }
  }

  isObject(v) {
    return v && typeof v == 'object';
  }

  toggleAutocompletePanel(event: MouseEvent, trigger: MatAutocompleteTrigger, formControlName :string) {
    event.stopPropagation();
    this.autocompleteTriggers.forEach(t => {
      if(t.autocomplete.isOpen) {
        t.closePanel();
      } else if(t == trigger) {
        this.filterForm.controls[formControlName].reset();
        t.openPanel();
      }
    });
  }

  private filterDivisions(divisions: Division[]): Division[] {
    const filters = <{ division?: Division, city?: City }>this.filterForm.value;

    if(this.isObject(filters.division)) {
      return divisions.filter(division => division.iD === filters.division.iD);
    }

    if (typeof filters.division === 'string' && filters.division !== '') {
      // @ts-ignore
      return divisions.filter(division => division.fullDescription.includes(filters.division));
    }

    if(this.isObject(filters.city)) {
      return divisions.filter(division => division.city && division.city.iD === filters.city.iD);
    }

    return divisions.slice();
  }

  private initAutocompletes() {
    this.controls.city.valueChanges.subscribe(v => this.controls.division.reset());

    this.cities = this.controls.city.valueChanges.pipe(
      // startWith(''),
      map(v => {
        const value = (v || '').toString().trim().toLowerCase();
        let cities = this.tasksService.cities.slice();
        return !value ? cities : cities.filter(city => {
          return city.description.toLowerCase().includes(value);
        });
      })
    );

    this.divisions = this.controls.division.valueChanges.pipe(
      // startWith(''),
      map(v => this.autocompleteDivisionsFilter())
    );
  }

  private autocompleteDivisionsFilter(): string[] {
    const city = this.controls.city.value as City|null;
    let divisions: Division[];

    if(this.isObject(city)) {
      divisions = city.divisions;
    } else if(city) {
      return [];
    } else {
      divisions = this.tasksService.divisions.slice();
    }

    let divisionNames = divisions.map(d => d.fullDescription);

    const value = (this.controls.division.value || '').toString().trim().toLowerCase();
    return !value ? divisionNames : divisionNames.filter(divisionName => {
      return divisionName.toLowerCase().includes(value);
    });
  }

}
