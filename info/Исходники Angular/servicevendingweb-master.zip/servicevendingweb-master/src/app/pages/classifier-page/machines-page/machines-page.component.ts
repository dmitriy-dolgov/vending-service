import {
  ChangeDetectionStrategy,
  Component,
  ComponentFactoryResolver,
  OnDestroy,
  OnInit,
  QueryList,
  ViewChild,
  ViewChildren
} from '@angular/core';
import {TasksService} from '@app/services/tasks.service';
import {City, ClientStatuses, Division, Machine, Task, TaskStateTypes} from '@app/models';
import {forkJoin, from, Observable, of, Subscription} from 'rxjs';
import {MachineFormDialogComponent} from '@app/components/dialogs/machine-form-dialog/machine-form-dialog.component';
import {MatAutocompleteTrigger, MatDialog, MatOptionSelectionChange} from '@angular/material';
import {AbstractControl, FormControl, FormGroup} from '@angular/forms';
import {AppValidators} from '@app/validators';
import {finalize, map, take, tap} from 'rxjs/operators';
import {ConfirmDialogComponent} from '@app/components/dialogs/confirm-dialog/confirm-dialog.component';
import {AlertDialogComponent} from '@app/components/dialogs/alert-dialog/alert-dialog.component';
import {ClassifierComponent, ClassifierRowComponent} from '@app/components/classifier/classifier.component';
import {ClassifierEditorService} from '@app/services/classifier-editor.service';
import {DivisionFormDialogComponent} from '@app/components/dialogs/division-form-dialog/division-form-dialog.component';
import {LoadingService} from '@app/services/loading.service';
import {QuickAddTaskComponent} from '@app/components/quick-add-task/quick-add-task.component';
import * as moment from 'moment';
import {Moment} from 'moment';
import {machineServiceState, MachineServiceStates} from '@app/utils';
import {DATE_FORMAT} from '@src/environments/moment';
import {forEach} from "@angular/router/src/utils/collection";

type DataSourceItem = Machine & { region: string };

@Component({
  selector: 'app-machines-page',
  templateUrl: './machines-page.component.html',
  styleUrls: ['../classifier-page.component.scss', './machines-page.component.scss']
})
export class MachinesPageComponent implements OnInit, OnDestroy {

  @ViewChildren(MatAutocompleteTrigger) autocompleteTriggers: QueryList<MatAutocompleteTrigger>;
  @ViewChildren(ClassifierRowComponent) classifierRows: QueryList<ClassifierRowComponent>;
  @ViewChild(ClassifierComponent) classifier: ClassifierComponent;

  private _subscriptions: Subscription[] = [];
  divisions: Observable<Division[]>;
  allDivisions: Division[];
  serialNumbers: Observable<string[]>;
  filteredMachines: DataSourceItem[];
  allMachines: DataSourceItem[];
  cities: Observable<City[]>;
  filterForm: FormGroup;
  tasks: Task[] = [];
  taskSortedDataCount = {};
  machineIds = [];

  controls: { [name: string]: AbstractControl } = {
    city: new FormControl('', [AppValidators.isModel]),
    division: new FormControl('', [AppValidators.isModel]),
    serialNumber: new FormControl('', [AppValidators.isModel]),
  };

  constructor(
    private componentFactoryResolver: ComponentFactoryResolver,
    private classifierEditor: ClassifierEditorService,
    private tasksService: TasksService,
    private loading: LoadingService,
    private dialog: MatDialog
  ) {
  }

  ngOnInit() {

    const machineCollection = this.tasksService.getCollection<Machine>('machines');
    this._subscriptions.push(
      this.tasksService.tasks.subscribe(tasks => {
        this.tasks = tasks;
        this.initializeTotalCountsOfStates(machineCollection.items);

      })
    );

    this._subscriptions.push(
      machineCollection.valueChanges().subscribe(machines => {
        this.allMachines = machines.map(m => {
          return Object.assign(machineCollection.buildModel(m), m, {
            region: (m.division.region || '---').toString()
          }) as DataSourceItem;
        });
        this.tasksService.getCollection<Division>('divisions').valueChanges().subscribe((d: any) => {
          this.allDivisions = d;
          this.filteredMachines = this.filterMachines(this.allMachines);
          // this.initializeTotalCountsOfStates(this.filteredMachines);

        });

      })
    );
    this.filterForm = new FormGroup(this.controls);
    this.initAutocompletes();
  }

  addTask(machine: Machine, classifierRow: ClassifierRowComponent) {

    const componentFactory = this.componentFactoryResolver.resolveComponentFactory(QuickAddTaskComponent);
    const viewContainer = classifierRow.viewContainer;

    this.classifierRows.forEach(row => {
      if (row != classifierRow && row.viewContainer.length) {
        row.viewContainer.clear();
      }
    });

    if (!viewContainer.length) {
      const componentRef = viewContainer.createComponent(componentFactory);
      const taskForm = (componentRef.instance as QuickAddTaskComponent);
      taskForm.machine = machine;
      taskForm.addTask.subscribe(newTask => {
        viewContainer.clear();
      });
    } else {
      viewContainer.clear();
    }
  }

  addMachine() {
    MachineFormDialogComponent.openAsDialog(this.dialog, {
      division: this.controls.division.value,
      city: this.controls.city.value
    });
  }

  addMachineFromCombobox(e: MatOptionSelectionChange) {

    const control = this.controls.serialNumber;

    MachineFormDialogComponent.openAsDialog(this.dialog, {

      division: this.controls.division.value,
      city: this.controls.city.value,
      serialNumber: control.value

    }).afterClosed().subscribe((machine: Machine) => {
      control.setValue(machine);
    });

    control.reset();
  }

  timeConverter(timestamp) {
    const a = new Date(timestamp);
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    const month = a.getMonth() + 1;
    const date = a.getDate();

    function correctDate(d) {
      if (d < 10) {
        return '0' + d;
      }
      return d;
    }

    const time = correctDate(date) + '.' + correctDate(month);
    return time;
  }

  sampleFunction(machine) {
    if (!(machine.iD in this.machineIds)) {
      let tasks = machine.tasks;
      this.machineIds[machine.iD] = [];
      (tasks).subscribe(t => {
        let sortedData = [];

        t.map(data => {

          if (data.state === TaskStateTypes.FINISHED) {
            sortedData.push({timeFinished: data.timeFinished, description: data.operationsText});
          }
        });
        let temporalObjectArray = [];
        let size = 3;
        if (sortedData.length > 0) {
          sortedData = sortedData.sort((n1, n2) => n2.timeFinished - n1.timeFinished);
          sortedData.slice(0, size).map(i => {
            temporalObjectArray.push({time: this.timeConverter(i.timeFinished), description: i.description});
          });
          this.machineIds[machine.iD] = temporalObjectArray;
        }
      });
    }

    return this.machineIds[machine.iD];
  }

  editMachine(machine: Machine) {
    MachineFormDialogComponent.openAsDialog(this.dialog, {machine});
  }

  addCity(e: MatOptionSelectionChange) {
    const control = this.controls.city;
    this.classifierEditor.addCity(control.value).subscribe(city => {
      control.setValue(city);
    });
  }

  addDivision(e: MatOptionSelectionChange) {
    const control = this.controls.division;

    DivisionFormDialogComponent.openAsDialog(this.dialog, {
      description: control.value,
      city: this.controls.city.value
    }).afterClosed().subscribe((division: Division) => {
      control.setValue(division);
    });

    control.reset();
  }

  removeMachine(machine: Machine) {
    machine.tasks.pipe(take(1)).subscribe(tasks => {
      if (tasks.find(task => task.state != TaskStateTypes.REMOVED)) {
        AlertDialogComponent.openAsDialog(this.dialog, 'Оборудование используется.');
      } else {
        ConfirmDialogComponent.openAsDialog(this.dialog, {
          message: 'Вы уверены, что хотите удалить оборудование?',
          btnText: 'Удалить'
        }).afterClosed().subscribe(confirm => {
          if (confirm) {
            this.loading.show();
            machine.remove().pipe(finalize(() => this.loading.hide())).subscribe();
          }
        });
      }
    });
  }

  filterFormSubmit() {
    this.filteredMachines = this.filterMachines(this.allMachines);
    this.classifier.paginator.changePage(0);
  }

  ngOnDestroy(): void {
    while (this._subscriptions.length) {
      this._subscriptions.pop().unsubscribe();
    }
  }

  private initAutocompletes() {

    this.controls.city.valueChanges.subscribe(v => setTimeout(() => this.controls.division.reset(), 100));
    this.controls.division.valueChanges.subscribe(v => setTimeout(() => this.controls.serialNumber.reset(), 100));

    this.cities = this.controls.city.valueChanges.pipe(
      // startWith(''),
      map(v => {
        const value = (v || '').toString().trim().toLowerCase();
        const cities = this.tasksService.cities.slice();
        return !value ? cities : cities.filter(city => {
          return city.description.toLowerCase().includes(value);
        });
      })
    );

    this.divisions = this.controls.division.valueChanges.pipe(
      // startWith(''),
      map(v => this.autocompleteDivisionsFilter())
    );

    this.serialNumbers = this.controls.serialNumber.valueChanges.pipe(
      // startWith(''),
      map(v => this.autocompleteMachinesFilter())
    );
  }

  private getUtcTime(m: Moment, time: string) {
    return moment(`${m.format(moment.HTML5_FMT.DATE)} ${time}`).utc().valueOf();
  }

  autocompleteDisplayWithDivisions(division: Division) {
    return division ? division.fullDescription : undefined;
  }

  isObject(v) {
    return v && typeof v == 'object';
  }

  toggleAutocompletePanel(event: MouseEvent, trigger: MatAutocompleteTrigger, formControlName: string) {
    event.stopPropagation();
    this.autocompleteTriggers.forEach(t => {
      if (t.autocomplete.isOpen) {
        t.closePanel();
      } else if (t == trigger) {
        this.filterForm.controls[formControlName].reset();
        t.openPanel();
      }
    });
  }

  sortFn(m1: DataSourceItem, m2: DataSourceItem) {
    const compare = (s1, s2) => s1.toString().localeCompare(s2.toString(), undefined, {
      sensitivity: 'base', numeric: true
    });
    const compareRegion = compare(m1.region, m2.region);
    return !compareRegion
      ? (compare(m1.division.fullDescription, m2.division.fullDescription) || compare(m1.serialNumber, m2.serialNumber))
      : (compareRegion > 0 && m1.division.regionID && m2.division.regionID ? 1 : -1);
  }

  private initializeTotalCountsOfStates(machines) {
    let yellowMachines = 0;
    let redMachines = 0;
    let greenMachines = 0;

    const filters = this.filterForm.value as { division?: Division | string, serialNumber?: string, city?: City };

    for (const machine of machines) {

      //console.log('machine : ' + machine.iD);
      //console.log('machine r : ' + machine.redDate);

      if ((filters.city.iD != undefined)&& (machine.division.city != filters.city))
        continue;

      switch (machineServiceState(machine, this.tasks)) {
        case MachineServiceStates.CRITICAL:
          redMachines++;
          break;
        case MachineServiceStates.WARNING:
          yellowMachines++;
          break;
        default:
          greenMachines++;
      }
    }
    this.taskSortedDataCount = {
      warning: yellowMachines,
      normal: greenMachines,
      critical: redMachines
    };
  }

  private filterMachines(machines: DataSourceItem[]): DataSourceItem[] {
    console.log('machines filter event fire');

    const filters = this.filterForm.value as { division?: Division | string, serialNumber?: string, city?: City };

    if (filters.serialNumber) {
      if (/^\s+$/.test(filters.serialNumber)) {
        machines = machines.filter(machine => !machine.serialNumber);
      } else {
        machines = machines.filter(machine => machine.serialNumber.includes(filters.serialNumber));
      }
    }

    if (filters.division) {
      const division = (typeof filters.division == 'string' ? filters.division : filters.division.fullDescription).toLowerCase();
      machines = machines.filter(machine => machine.division && machine.division.fullDescription.toLowerCase().includes(division));
    }

    if (this.isObject(filters.city)) {
      machines = machines.filter(machine => machine.division && machine.division.city && machine.division.city.iD === filters.city.iD);
    }

    this.initializeTotalCountsOfStates (machines);

    console.log('machines filter event fire end');
    
    return machines.slice();

  }

  private autocompleteDivisionsFilter(): Division[] {
    console.log('autocomplete divisions filter');
    const city = this.controls.city.value as City | null;
    let divisions: Division[];

    if (this.isObject(city)) {
      divisions = city.divisions;
    } else if (city) {
      return [];
    } else {
      divisions = this.tasksService.divisions.slice();
    }

    const value = (this.controls.division.value || '').toString().trim().toLowerCase();
    return !value ? divisions : divisions.filter(division => {
      return division.fullDescription.toLowerCase().includes(value);
    });
  }

  private autocompleteMachinesFilter(): string[] {
    console.log('autocompleteMachinesFilter');
    const division = this.controls.division.value as Division | null;
    const city = this.controls.city.value as City | null;
    let machines: Machine[];

    if (this.isObject(division)) {
      machines = division.machines;
    } else if (this.isObject(city)) {
      machines = city.machines;
    } else {
      machines = this.tasksService.machines.slice();
    }

    const value = (this.controls.serialNumber.value || '').toString().trim().toLowerCase();
    let serialNumbers = machines.filter(m => !!m.serialNumber).map(m => m.serialNumber);

    if (value) {
      serialNumbers = serialNumbers.filter(serialNumber => {
        return serialNumber.toLowerCase().includes(value);
      });
    }

    return serialNumbers.sort((s1, s2) => {
      return s1.localeCompare(s2, undefined, {
        sensitivity: 'base', numeric: true
      });
    });
  }

  downloadReport() {

    if (!this.filteredMachines.length) {
      return;
    }

    const escape = v => v.replace(/"([^"]+)"/g, '«$1»');
    const createCsvRow = (...cols: string[]): string => cols.map(col => `${escape(col)}`).join('; ');

    this.filteredMachines.forEach(data => this.sampleFunction(data));

    setTimeout(() => {
      const csv = [
        createCsvRow('Торговая точка', 'Адрес', 'Серийный номер', 'Комментарий', 'Последние работы'),
        ...this.filteredMachines.map(data => createCsvRow(
          (data.division || '').toString(),
          data.division.fullAddress.toString(),
          data.serialNumber.toString(),
          data.comment.toString(),
          this.machineIds[data.iD].map(i => `${i.time} - ${i.description || ''}`).join('; ')
          )
        )].join('\n');
      this.saveBlob(new Blob([csv], {type: 'text/csv;charset=ANSI;'}),
        `Отчёт по оборудованию(${moment().format('YYYYMMDDHHmmss')}).csv`);
    }, 1000);
  }

  private saveBlob(blob: Blob, fileName: string) {
    if (typeof navigator.msSaveBlob !== 'undefined') {
      navigator.msSaveBlob(blob, fileName);
      return;
    }

    const tmpLink = document.createElement('a');

    if (typeof tmpLink.download === 'undefined') {
      window.location.href = URL.createObjectURL(blob);
      return;
    }

    tmpLink.href = URL.createObjectURL(blob);
    tmpLink.download = fileName;
    document.body.appendChild(tmpLink);

    tmpLink.addEventListener('click', () => {
      document.body.removeChild(tmpLink);
    }, false);

    tmpLink.click();
  }
}
