import {NgModule} from '@angular/core';
import {Routes, RouterModule} from '@angular/router';
import {ClassifierPageComponent} from '@app/pages/classifier-page/classifier-page.component';
import {DivisionsPageComponent} from './divisions-page/divisions-page.component';
import {ClassifierModule} from '@app/components/classifier/classifier.module';
import {BaseModule} from '@app/base.module';

const routes: Routes = [
  {path: '', redirectTo: 'machines'},
  {
    path: '', component: ClassifierPageComponent, children: [
      {path: 'machines', loadChildren: './machines-page/machines-page.module#MachinesPageModule'},
      {path: 'divisions', component: DivisionsPageComponent},
    ]
  }
];

@NgModule({
  declarations: [
    ClassifierPageComponent,
    DivisionsPageComponent
  ],
  imports: [
    RouterModule.forChild(routes),
    BaseModule,
    ClassifierModule
  ],
  exports: [RouterModule],
  entryComponents: [
    DivisionsPageComponent
  ],
})
export class ClassifierPageRoutingModule {
}
