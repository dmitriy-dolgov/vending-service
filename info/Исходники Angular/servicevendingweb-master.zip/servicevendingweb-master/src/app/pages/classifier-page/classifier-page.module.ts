import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ClassifierPageRoutingModule } from './classifier-page-routing.module';

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    ClassifierPageRoutingModule
  ]
})
export class ClassifierPageModule { }
