import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ClassifierPageComponent } from './classifier-page.component';

describe('ClassifiersPageComponent', () => {
  let component: ClassifierPageComponent;
  let fixture: ComponentFixture<ClassifierPageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ClassifierPageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ClassifierPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
