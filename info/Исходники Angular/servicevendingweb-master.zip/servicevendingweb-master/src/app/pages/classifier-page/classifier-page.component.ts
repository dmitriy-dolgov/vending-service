import { Component, OnInit } from '@angular/core';
import {TasksService} from '@app/services/tasks.service';

@Component({
  selector: 'app-classifier-page',
  templateUrl: './classifier-page.component.html',
  styleUrls: ['./classifier-page.component.scss']
})
export class ClassifierPageComponent implements OnInit {
  constructor(public tasksService: TasksService) {
  }
  ngOnInit(): void {
  }
}
