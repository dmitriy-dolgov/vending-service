import {NgModule} from '@angular/core';
import {RouterModule} from '@angular/router';
import {BaseModule} from '@app/base.module';
import {ClassifierModule} from '@app/components/classifier/classifier.module';
import {MachinesPageComponent} from './machines-page.component';
import {MachineServiceStatePipe, TodayTaskAddedPipe} from '@app/pipes/machine.pipes';

@NgModule({
  declarations: [
    MachinesPageComponent,
    TodayTaskAddedPipe,
    MachineServiceStatePipe
  ],
  imports: [
    BaseModule,
    ClassifierModule,
    RouterModule.forChild([
      {path: '', component: MachinesPageComponent}
    ])
  ]
})
export class MachinesPageModule {
}
