import {Component, Inject, OnInit, ViewChild} from '@angular/core';
import {TasksService} from '@app/services/tasks.service';
import {ActivatedRoute, Params} from '@angular/router';
import {AuthenticationService} from '@app/services/authentication.service';
import {TaskDetailsPageComponent} from '@app/pages/task-details-page/task-details-page.component';
import {SpinnerComponent, SpinnerModes} from '@app/components/spinner/spinner.component';
import {PaginatorComponent} from '@app/components/paginator/paginator.component';
import {Task, TaskPhoto} from '@app/models';
import {User} from 'firebase';
import {MatDialog} from '@angular/material';
import {TaskPhotoDialogComponent} from '@app/components/dialogs/task-photo-dialog/task-photo-dialog.component';
import {Title} from '@angular/platform-browser';

@Component({
  selector: 'app-task-photos-page',
  templateUrl: './task-photos-page.component.html',
  styleUrls: ['./task-photos-page.component.scss']
})
export class TaskPhotosPageComponent implements OnInit {

  @ViewChild('progress_spinner') progressSpinner: SpinnerComponent;
  @ViewChild(PaginatorComponent) paginator: PaginatorComponent;
  pageTaskPhotos: TaskPhoto[];
  taskPhotos: TaskPhoto[];
  queryParams: Params;
  task: Task;
  user: User;

  showProgress = false;
  pageTitle = "Фотографии";

  constructor(
    @Inject(TaskDetailsPageComponent) private taskDetailsPage: TaskDetailsPageComponent,
    private auth: AuthenticationService,
    private tasksService: TasksService,
    protected titleService: Title,
    private route: ActivatedRoute,
    private dialog: MatDialog
  ) {
    this.queryParams = this.route.snapshot.queryParams;
    this.task = this.taskDetailsPage.task;
  }

  ngOnInit() {
    this.titleService.setTitle(`Детали задачи | ${this.pageTitle}`);
    this.taskDetailsPage.task$.subscribe(task => this.task = task);
    this.auth.user.subscribe(user => this.user = user);

    this.task.photos.subscribe(photos => {
      this.taskPhotos = photos;
      this.paginator.length = photos.length;
      this.sliceTaskPhotos();
    });

    this.paginator.page.subscribe(() => {
      this.sliceTaskPhotos();
    });
  }

  addPhoto(e: Event) {
    const fileList: FileList = (<HTMLInputElement>e.target).files;
    const files: File[] = Array.prototype.slice.call(fileList).filter(f => this.isImage(f));

    if(files.length) {
      this.upload(files).then(() => {
      });
    }
  }

  photoOpen(photo: TaskPhoto) {
    TaskPhotoDialogComponent.openAsDialog(this.dialog, this.task, photo);
  }

  isImage(file: File): boolean {
    return /^image\/(jpeg|gif|png)$/.test(file.type);
  }

  private upload(files: File[]): Promise<void> {

    this.progressSpinner.mode = SpinnerModes.DETERMINATE;
    this.progressSpinner.progress = 5;
    this.showProgress = true;

    let percents = files.map(() => 0);
    let completeds = 0;

    return new Promise(resolve => {

      files.forEach((file, i) => {

        this.task.addPhoto(file, this.user, percent => {

          percents[i] = this.round(percent);
          const totalPercent = percents.reduce((p, c) => p + c, 0);
          const progress = this.round(totalPercent / files.length);

          if(progress == 100) {
            this.progressSpinner.mode = SpinnerModes.INDETERMINATE;
          } else if(progress > 5) {
            this.progressSpinner.progress = progress;
          }

        }).subscribe(() => {

          if(++completeds == files.length) {
            this.progressSpinner.progress = 0;
            this.showProgress = false;
            resolve();
          }

        });

      });

    });
  }

  private round(val: number, digits: number = 2): number {
    return parseFloat(val.toFixed(digits));
  }

  private sliceTaskPhotos() {
    const startIndex = this.paginator.pageIndex * this.paginator.pageSize;
    this.pageTaskPhotos = this.taskPhotos.slice(startIndex, startIndex + this.paginator.pageSize);
  }
}
