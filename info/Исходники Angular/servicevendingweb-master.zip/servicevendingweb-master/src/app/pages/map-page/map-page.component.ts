import {
  Component,
  ComponentFactoryResolver,
  ElementRef,
  NgZone,
  OnDestroy,
  OnInit, QueryList,
  ViewChild, ViewChildren,
  ViewContainerRef
} from '@angular/core';
import {TasksService} from '@app/services/tasks.service';
import {Division, OperationType, Task, User, Machine, City, TaskStateTypes} from '@app/models';
import {AbstractControl, FormControl, FormGroup} from '@angular/forms';
import {forkJoin, Observable, Subject} from 'rxjs';
import {map, switchMap, take, takeUntil} from 'rxjs/operators';
import {divisionCenterCoordinates, divisionServiceState, MachineServiceStates, uuidGenerate} from '@app/utils';
import {YandexMapService} from '@app/components/yandex-map/services/yandex-map/yandex-map.service';
import {AuthenticationService} from '@app/services/authentication.service';
import * as YMaps from 'yandex-maps';
import {IPlacemarkOptions} from 'yandex-maps';
import * as moment from 'moment';
import {MatSnackBar} from '@angular/material';
import {LoadingService} from '@app/services/loading.service';
import {AppValidators} from '@app/validators';
import {MatAutocompleteTrigger} from '@angular/material/autocomplete';
import {Moment} from 'moment';


type DataSourceItem = Machine & { region: string };

@Component({
  selector: 'app-map-page',
  templateUrl: './map-page.component.html',
  styleUrls: ['./map-page.component.scss']
})
export class MapPageComponent implements OnInit, OnDestroy {

  filterForm: FormGroup;
  controls = {
    city: new FormControl('', [AppValidators.isModel]),
    division: new FormControl('', [AppValidators.isModel]),
    serialNumber: new FormControl('', [AppValidators.isModel]),
  };
  destroyed$ = new Subject();
  filteredDivisions: Division[];
  divisions: Division[];
  divisionsAutocomplete: Observable<Division[]>;
  tasks: Task[];
  cities: Observable<City[]>;
  currentUser: User;
  workers: User[];
  serialNumbers: Observable<string[]>;
  selectedWorker: User;
  machines: Machine[];
  boundsCenter: any[];

  @ViewChildren(MatAutocompleteTrigger) autocompleteTriggers: QueryList<MatAutocompleteTrigger>;
  @ViewChild('divisionMap') private mapRef: ElementRef<HTMLElement>;
  mapCenter = [55.796289, 49.108795]; // Казань
  mapOptions: any = {};
  mapZoom = 4;
  map: YMaps.Map;
  private ymapsClusterer: YMaps.Clusterer;
  private objectManager: any;
  ymaps: typeof YMaps | any;
  loading = true;
  operationTypes: OperationType[];
  selectedOperations: OperationType[] = [];
  // filterString: string = '';
  filteredMachines: DataSourceItem[];
  allMachines: DataSourceItem[];
  mapStatus = false;

  clusterer = {
    preset: 'islands#invertedVioletClusterIcons',
    hasBaloon: false
  };

  constructor(
    private componentFactoryResolver: ComponentFactoryResolver,
    private viewContainer: ViewContainerRef,
    private auth: AuthenticationService,
    private tasksService: TasksService,
    private ymapService: YandexMapService,
    private loadingService: LoadingService,
    private zone: NgZone
  ) {
  }

  autocompleteDisplayWithDivisions(division: Division) {
    return division ? division.fullDescription : undefined;
  }

  isObject(v) {
    return v && typeof v === 'object';
  }

  private autocompleteDivisionsFilter(): Division[] {
    const city = this.controls.city.value as City | null;
    let divisions: Division[];

    if (this.isObject(city)) {
      divisions = city.divisions;
    } else if (city) {
      return [];
    } else {
      divisions = this.tasksService.divisions.slice();
    }

    const value = (this.controls.division.value || '').toString().trim().toLowerCase();
    return !value ? divisions : divisions.filter(division => {
      return division.fullDescription.toLowerCase().includes(value);
    });
  }

  private initAutocompletes() {

    this.controls.city.valueChanges.subscribe(v => setTimeout(() => this.controls.division.reset(), 100));
    this.controls.division.valueChanges.subscribe(v => setTimeout(() => this.controls.serialNumber.reset(), 100));

    this.cities = this.controls.city.valueChanges.pipe(
      // startWith(''),
      map(v => {
        const value = (v || '').toString().trim().toLowerCase();
        const cities = this.tasksService.cities.slice();
        return !value ? cities : cities.filter(city => {
          return city.description.toLowerCase().includes(value);
        });
      })
    );

    this.divisionsAutocomplete = this.controls.division.valueChanges.pipe(
      // startWith(''),
      map(v => this.autocompleteDivisionsFilter())
    );

    this.serialNumbers = this.controls.serialNumber.valueChanges.pipe(
      // startWith(''),
      map(v => this.autocompleteMachinesFilter())
    );
  }

  private autocompleteMachinesFilter(): string[] {
    const division = this.controls.division.value as Division | null;
    const city = this.controls.city.value as City | null;
    let machines: Machine[];

    if (this.isObject(division)) {
      machines = division.machines;
    } else if (this.isObject(city)) {
      machines = city.machines;
    } else {
      machines = this.tasksService.machines.slice();
    }

    const value = (this.controls.serialNumber.value || '').toString().trim().toLowerCase();
    let serialNumbers = machines.filter(m => !!m.serialNumber).map(m => m.serialNumber);

    if (value) {
      serialNumbers = serialNumbers.filter(serialNumber => {
        return serialNumber.toLowerCase().includes(value);
      });
    }

    return serialNumbers.sort((s1, s2) => {
      return s1.localeCompare(s2, undefined, {
        sensitivity: 'base', numeric: true
      });
    });
  }

  ngOnInit() {
    const machineCollection = this.tasksService.getCollection<Machine>('machines');

    machineCollection.valueChanges().subscribe(machines => {
      this.allMachines = machines.map(m => {
        if (m.division) {
          return Object.assign(machineCollection.buildModel(m), m, {
            region: (m.division.region || '---').toString()
          }) as DataSourceItem;
        } else {
          return Object.assign(machineCollection.buildModel(m), m, {
            region: ('---').toString()
          }) as DataSourceItem;
        }
      });
      this.filteredMachines = this.filterMachines(this.allMachines);
    });

    this.auth.user.subscribe(user => {
      this.tasksService.getCollection<User>('users').valueChanges().subscribe(users => {
        this.currentUser = users.filter(u => {
          return u.iD === user.uid;
        })[0];
        this.workers = users;
        if (!this.tasks) {
          this.tasksService.tasks.subscribe(tasks => {
            this.tasks = tasks;
            console.log(1);
            if (!this.mapStatus) {
              this.mapStatus = true;
              this.mapInit();
            }
          });
        }
      });
    });
    this.filterForm = new FormGroup(this.controls);
    this.tasksService.getCollection<OperationType>('operationTypes')
      .valueChanges().subscribe(operationTypes => {
      this.operationTypes = operationTypes;
    });
  }

  filterFormSubmit() {
    this.filteredMachines = this.filterMachines(this.allMachines);
    console.log(2);
    this.mapInit();

    this.map.setCenter(divisionCenterCoordinates([this.filteredMachines[0].division]), 18);
  }

  private filterMachines(machines: DataSourceItem[]): DataSourceItem[] {

    const filters = this.filterForm.value as { division?: Division | string, serialNumber?: string, city?: City };

    if (filters.serialNumber) {
      if (/^\s+$/.test(filters.serialNumber)) {
        machines = machines.filter(machine => !machine.serialNumber);
      } else {
        machines = machines.filter(machine => machine.serialNumber.includes(filters.serialNumber));
      }
    }

    if (filters.division) {
      const division = (typeof filters.division === 'string' ? filters.division : filters.division.fullDescription).toLowerCase();
      machines = machines.filter(machine => machine.division && machine.division.fullDescription.toLowerCase().includes(division));
    }

    if (this.isObject(filters.city)) {
      machines = machines.filter(machine => machine.division && machine.division.city && machine.division.city.iD === filters.city.iD);
    }

    return machines.slice();
  }

  filterDivision(divisions: Division[]): Division[] {
    const data = this.filterForm.value as { division: string };
    if (!data.division) {
      return divisions.slice();
    }
    const value = data.division.toLowerCase();
    return divisions.filter(division => {
      return division.fullDescription.toLowerCase().includes(value);
    });
  }

  ngOnDestroy(): void {
    this.destroyed$.next();
    if (this.map) {
      this.map.destroy();
    }
  }

  private getUtcTime(m: Moment, time: string) {
    return moment(`${m.format(moment.HTML5_FMT.DATE)} ${time}`).utc().valueOf();
  }

  getLastTask(tasks: Task[], machine) {
    const currentDayTime = this.getUtcTime(moment(), '00:00:00');
    return !!(tasks || []).find(task => {
      return task.machineID === machine.iD
        && task.state !== TaskStateTypes.REMOVED
        && task.datetime >= currentDayTime;
    });
  }

  private mapInit() {
    console.log('map init');

    forkJoin([
      this.ymapService.mapReady().pipe(take(1)),
      this.tasksService.getCollection<Division>('divisions').valueChanges().pipe(take(1)),
      this.tasksService.getCollection<Machine>('machines').valueChanges().pipe(take(1)),
    ]).pipe(takeUntil(this.destroyed$)).subscribe(([ymaps, divisions, machines]) => {
      this.initAutocompletes();
      (document.querySelector('.map') as HTMLBaseElement).innerHTML = '';

      if (this.filteredMachines) {
        this.machines = this.filteredMachines;
        this.divisions = this.filteredMachines.map((m) => {
          return divisions.filter(d => {
            return d.iD === m.divisionID;
          })[0];
        });
        // console.log('filtered divisions : ', this.divisions);
      } else {
        this.machines = machines;
        this.divisions = divisions.filter(d => d.gPSLocationX && d.gPSLocationY);
      }
      // this.filteredDivisions = this.filterDivision(this.divisions);


      this.ymaps = ymaps;

      // if (!this.boundsCenter) {
        this.map = this.createMap((this.ymaps));
      // } else {
      //   this.map.geoObjects.each(function(context) {
      //     this.map.geoObjects.remove(context);
      //   });
      // }
      // this.map.
      // --- new generator

      const clusterer = new this.ymaps.Clusterer({
        clusterHideIconOnBalloonOpen: false,
        geoObjectHideIconOnBalloonOpen: false
      });

      // tslint:disable-next-line:no-shadowed-variable
      clusterer.createCluster = function (center, geoItems) {
        // tslint:disable-next-line:prefer-const
        let clusterPlacemark = ymaps.Clusterer.prototype.createCluster.call(this, center, geoItems);
        const presets = {};


        for (let i = 0, l = geoItems.length; i < l; i++) {
          // tslint:disable-next-line:prefer-const
          const placemarkPreset = geoItems[i].options.get('preset');
          presets[placemarkPreset] = presets[placemarkPreset] ? presets[placemarkPreset] + 1 : 1;
        }

        let popularPreset;
        if (presets['islands#redIcon']) {
          popularPreset = 'islands#redIcon';
        } else if (presets['islands#orangeIcon']) {
          popularPreset = 'islands#orangeIcon';
        } else {
          popularPreset = 'islands#greenIcon';
        }

        clusterPlacemark.options.set('preset', popularPreset.replace('Icon', 'ClusterIcons'));
        return clusterPlacemark;
      };

      const workOperation = this.operationTypes.filter((o) => {
        return o.iD === 'id00009';
      })[0];

      const otherOperation = this.operationTypes.filter((o) => {
        return o.iD === 'id00019';
      })[0];

      let operations = `<div class="quick-add-block-map">
        <div style="width: 100%; float: left;">
        <input data-oriented="id00009" style="display: none; width: 48%; margin-right: 3px; float: left;
                      height: 25px;
                      border-radius: 5px;
                      outline: none;
                      padding: 2px;
                      border: 1px solid silver;
                      box-shadow: none;
                      margin-bottom: 2px;
                  " type="text" value="${workOperation.description}">
        <input data-oriented="id00019" style="display: none; width: 48%; margin-right: 3px; float: left;
                      height: 25px;
                      border-radius: 5px;
                      outline: none;
                      padding: 10px;
                      border: 1px solid silver;
                      box-shadow: none;
                      margin-bottom: 2px;
                  " type="text" value="${otherOperation.description}"></div>`;
      this.operationTypes.forEach(operation => {
        operations += `<label data-op-id="${operation.iD}" style="cursor: pointer; margin-right: 5px; margin-bottom: 2px; width: 61px;" class="btn btn-outline-secondary ">${operation.shortName}</label>`;
      });
      operations += '</div>';

      let workers = `<div
                    style="overflow: scroll;
                     margin-bottom: 5px;
                      height: 185px;
                      position: absolute;
                      width: 100%;
                      background-color: rgb(255, 255, 255);
                      display: none;"
                      class="workers-selectable-area">`;
      this.workers.forEach(worker => {
        workers += `<div data-worker-item="${worker.iD}"
                    data-worker-display="${worker.displayName}"
                    style="margin-bottom: 5px; cursor: pointer;"
                    class="worker-item">${worker.displayName}</div>`;
      });
      workers += `</div>`;

      const getPointData = (machine) => {
        const division = this.divisions.filter(d => {
          return d.iD === machine.divisionID;
        })[0];
        const serial = machine.serialNumber;
        let isNewTitle = '';
        if (this.getLastTask(this.tasks, machine)) {
          isNewTitle = 'task-color-green-low';
        } else {
          isNewTitle = `task-color-${this.divisionStateColor(division)}`;
        }
        return [{
          type: 'Point',
          coordinates: [
            division.gPSLocationX,
            division.gPSLocationY
          ]
        },
          {
            balloonContentHeader: `<div class="${isNewTitle}">${division.fullDescription}
            <div style="display: block;" >${serial}</div> <br></div>`,
            balloonContentBody:
              `<input class="taskWorkerSearch" type="text" placeholder="Исполнитель" style="
                      width: 100%;
                      height: 35px;
                      border-radius: 5px;
                      outline: none;
                      margin-bottom: 5px;
                      padding: 10px;
                      border: 1px solid silver;
                      box-shadow: none;
                  "><span style="display: none;" data-serial="${serial}" data-machine-id="${machine.iD}"></span>` +
              `${workers}` +
              `<br>${operations}`,
            balloonContentFooter: `<div style="width: 100%; position: relative; text-align: center;"><button data-save-for="${division.iD}" style="display: inline-block; margin-bottom: 10px;background-color: #ccc;padding-left: 20px;border-radius: 15px;padding-right: 20px;color: white;" class="btn">Добавить задачу</button></div>`,
          },
          {
            iconLayout: 'default#image',
            iconImageHref: require(`../../../assets/icons/map/ic_pin_${this.divisionStateColor(division, machine)}.png`),
            iconImageSize: [64, 64],
            preset: `islands#${this.divisionStateColor(division)}Icon`,
          }];
      };

      const geoItems = [];

      for (let i = 0, len = this.machines.length; i < len; i++) {
        geoItems[i] = new ymaps.Placemark(...getPointData(this.machines[i]));
      }

      clusterer.add(geoItems);
      this.map.geoObjects.add(clusterer);
      this.map.events.add('balloonopen', () => {
        this.mapTaskAddEvents();
      });
      this.loading = false; //  ymaps.util.bounds.getCenterAndZoom
      if (this.boundsCenter) {
        this.map.setBounds(this.boundsCenter, {checkZoomRange: true});
      } else {
        this.map.setBounds(clusterer.getBounds(), {checkZoomRange: true});
      }
      // tslint:disable-next-line:only-arrow-functions
      this.map.events.add('boundschange', (e: any) => {
        // tslint:disable-next-line:prefer-const
        this.mapCenter = e.originalEvent.newCenter;
        this.mapZoom = e.originalEvent.newZoom;
        this.boundsCenter = e.originalEvent.newBounds;
      });

    });

  }

  private mapTaskAddEvents() {
    const that = this;
    this.selectedWorker = undefined;
    const checkForValidation = () => {
      if (that.selectedWorker && document.querySelectorAll('[data-selected-op]').length) {
        (document.querySelector('[data-save-for]') as HTMLButtonElement).style.backgroundColor = '#15bfbf';
      } else {
        if ((document.querySelector('[data-save-for]'))) {
          (document.querySelector('[data-save-for]') as HTMLButtonElement).style.backgroundColor = '#ccc';
        }
      }
    };

    if (document.querySelector('.ymaps-2-1-75-b-cluster-tabs__menu-item')) {
      document.querySelectorAll('.ymaps-2-1-75-b-cluster-tabs__menu-item').forEach(item => {
        if (!!!(item as HTMLBaseElement).onclick) {
          (item as HTMLBaseElement).onclick = () => {
            setTimeout(() => {
              that.mapTaskAddEvents();
            }, 300);
          };
        }
      });
    }


    document.querySelectorAll('[data-worker-item]').forEach(worker => {
      worker.addEventListener('click', (e) => {
        checkForValidation();
        that.selectedWorker = that.workers.filter(w => {
          return w.iD === (e.target as HTMLBaseElement).dataset.workerItem;
        })[0];
        (document.querySelector('.taskWorkerSearch') as HTMLInputElement).value = that.selectedWorker.displayName;
      });
    });

    const search = (e) => {
      const value = (e.target as HTMLInputElement).value;
      if (value !== '') {
        document.querySelectorAll('[data-worker-display]').forEach(w => {
          if (!(w as HTMLBaseElement).dataset.workerDisplay.toLowerCase().includes(value.toLowerCase())) {
            (w as HTMLBaseElement).style.display = 'none';
          }
        });
      } else {
        document.querySelectorAll('[data-worker-display]').forEach(w => {
          (w as HTMLBaseElement).style.display = 'block';
        });
      }
    };

    // submit for form to save data
    document.querySelector('[data-save-for]').addEventListener('click', (e) => {
      that.selectedOperations = new Array<OperationType>();
      const division: Division = this.divisions.filter(d => {
        return d.iD === Number((e.target as HTMLButtonElement).dataset.saveFor);
      })[0];
      document.querySelectorAll('[data-selected-op]').forEach(op => {
        const selectedOp = that.operationTypes.filter(type => {
          return type.iD === (op as HTMLBaseElement).dataset.opId;
        })[0];
        if (selectedOp.iD === 'id00019' || selectedOp.iD === 'id00009') {
          selectedOp.description = (document.querySelector(`[data-oriented='${selectedOp.iD}']`) as HTMLInputElement).value;
        }
        that.selectedOperations.push(selectedOp);
      });
      if (division.machines.length && that.selectedWorker && that.selectedOperations.length) {
        this.loadingService.show();
        const machineD = that.machines.filter(m => {
          return m.iD === Number((document.querySelector(`[data-machine-id]`) as HTMLBaseElement).dataset.machineId);
        })[0];
        Task.create(that.tasksService, this.currentUser, {
          worker: that.selectedWorker,
          machine: machineD
        }).pipe(switchMap(newTask => {
          return forkJoin(that.selectedOperations.map(operationType => {
            return newTask.addOperation({operationType, description: operationType.description});
          })).pipe(map(taskOperations => newTask));
        })).subscribe(newTask => {
          this.loadingService.hide();
          (document.querySelector('.ymaps-2-1-75-balloon__close-button') as HTMLBaseElement).click();
          that.mapInit();
        });
      }
    });

    // chage down for input search
    document.querySelector('.taskWorkerSearch').addEventListener('keydown', (e) => {
      search(e);
    });

    // change up for input for search
    document.querySelector('.taskWorkerSearch').addEventListener('keyup', (e) => {
      search(e);
    });

    // outside click to close workers list
    document.querySelector('body').addEventListener('click', (e) => {
      if ((e.target as HTMLBaseElement).className !== 'taskWorkerSearch') {
        checkForValidation();
        if (document.querySelector('.workers-selectable-area')) {
          (document.querySelector('.workers-selectable-area') as HTMLBaseElement).style.display = 'none';
        }
      } else {
        (document.querySelector('.workers-selectable-area') as HTMLBaseElement).style.display = 'block';
      }
    });

    // focus input to show workers list
    document.querySelector('.taskWorkerSearch').addEventListener('focus', () => {
      // to open workers list
      (document.querySelector('.workers-selectable-area') as HTMLBaseElement).style.display = 'block';
    });

    // select and deselection of operation types
    document.querySelectorAll('[data-op-id]').forEach(option => {
      (option as HTMLBaseElement).onclick = (e) => {
        if ((e.target as HTMLBaseElement).hasAttribute('data-selected-op')) {
          if ((e.target as HTMLBaseElement).dataset.opId === 'id00009' || (e.target as HTMLBaseElement).dataset.opId === 'id00019') { // Р
            (document.querySelector(`[data-oriented='${(e.target as HTMLBaseElement).dataset.opId}']`) as HTMLInputElement).style.display = 'none';
          }
          (e.target as HTMLBaseElement).removeAttribute('data-selected-op');
          (e.target as HTMLBaseElement).style.backgroundColor = '#fff';
          (e.target as HTMLBaseElement).style.color = '#B5BDCC';
        } else {
          if ((e.target as HTMLBaseElement).dataset.opId === 'id00009' || (e.target as HTMLBaseElement).dataset.opId === 'id00019') { // Р
            (document.querySelector(`[data-oriented='${(e.target as HTMLBaseElement).dataset.opId}']`) as HTMLInputElement).style.display = 'block';
          }
          (e.target as HTMLBaseElement).setAttribute('data-selected-op', '');
          (e.target as HTMLBaseElement).style.backgroundColor = '#76839D';
          (e.target as HTMLBaseElement).style.color = '#fff';
        }
      };
    });
  }


  private divisionStateColor(division: Division, machine?: Machine): any {
    let iconColor = 'red';
    if (machine && this.getLastTask(this.tasks, machine)) {
      // console.log(division.fullDescription, machine,  this.getLastTask(this.tasks, machine));
    }
    if (machine && this.getLastTask(this.tasks, machine)) {
      iconColor = 'green-low';
    } else {
      if (this.tasks) {
        switch (divisionServiceState(division, this.tasks, this.machines)) {
          case MachineServiceStates.NORMAL:
            iconColor = 'green';
            break;
          case MachineServiceStates.WARNING:
            iconColor = 'orange';
            break;
        }
      }
    }
    return iconColor;
  }

  private createMap(ymaps: typeof YMaps): YMaps.Map {
    this.mapRef.nativeElement.id = `map-${uuidGenerate()}`;
    return new ymaps.Map(this.mapRef.nativeElement.id, {
      center: this.mapCenter,
      zoom: this.mapZoom
    }, this.mapOptions);
  }
}
