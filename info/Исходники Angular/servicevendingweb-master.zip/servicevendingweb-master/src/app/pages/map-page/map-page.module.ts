import {NgModule} from '@angular/core';
import {MapPageComponent} from './map-page.component';
import {RouterModule} from '@angular/router';
import {BaseModule} from '@app/base.module';
import {AngularYandexMapsModule} from '@app/components/yandex-map/angular-yandex-maps.module';
import {
  DivisionCenterCoordinatesPipe,
  DivisionPlacemarkPropertiesPipe,
  DivisionServiceStatePipe,
  DivisionPlacemarkOptionsPipe
} from '@app/pipes/division.pipes';

@NgModule({
  declarations: [
    MapPageComponent,
    DivisionServiceStatePipe,
    DivisionCenterCoordinatesPipe,
    DivisionPlacemarkPropertiesPipe,
    DivisionPlacemarkOptionsPipe
  ],
  imports: [
    RouterModule.forChild([ {path: '', component: MapPageComponent} ]),
    AngularYandexMapsModule,
    BaseModule
  ]
})
export class MapPageModule {
}
