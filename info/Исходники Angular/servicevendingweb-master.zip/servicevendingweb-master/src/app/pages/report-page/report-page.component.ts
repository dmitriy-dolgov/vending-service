import {Component, OnInit, QueryList, ViewChildren} from '@angular/core';
import * as moment from 'moment';
import {Moment} from 'moment';
import {TasksService} from '@app/services/tasks.service';
import {AbstractControl, FormControl, FormGroup, Validators} from '@angular/forms';
import {AppValidators} from '@app/validators';
import {forkJoin, Observable} from 'rxjs';
import {Task, TaskStateTypes, User} from '@app/models';
import {MatAutocompleteTrigger} from '@angular/material';
import {map, switchMap, take} from 'rxjs/operators';
import {DATE_FORMAT} from '@src/environments/moment';
import {LoadingService} from '@app/services/loading.service';

interface Filters {
  worker: User;
  dateFrom?: moment.Moment;
  dateTo?: moment.Moment;
}

interface FilteredData {
  task: Task,
  operations: string;
  totalMarks: number;
}

@Component({
  selector: 'app-report-page',
  templateUrl: './report-page.component.html',
  styleUrls: ['./report-page.component.scss']
})
export class ReportPageComponent implements OnInit {

  @ViewChildren(MatAutocompleteTrigger)
  autocompleteTriggers: QueryList<MatAutocompleteTrigger>;

  controls: {[name: string]: AbstractControl} = {
    worker: new FormControl('', [AppValidators.isModel, Validators.required]),
    dateFrom: new FormControl('', []),
    dateTo: new FormControl('', []),
  };
  filterForm: FormGroup = new FormGroup(this.controls);
  workers: Observable<User[]>;
  tasks: Task[];

  searchNotFound = false;
  filteredData: FilteredData[] = [];
  readonly row: FilteredData;
  totalMark: number;

  constructor(
    private tasksService: TasksService,
    public loading: LoadingService
  ) { }

  ngOnInit() {

    this.tasksService.tasks.subscribe(tasks => this.tasks = tasks);

    this.workers = this.controls.worker.valueChanges.pipe(
      // startWith(''),
      //debounceTime(250),
      switchMap(value => {
        value = (value || '').toString().trim().toLowerCase();
        return this.tasksService.getCollection<User>('users').valueChanges().pipe(
          take(1),
          map(users => users.filter(user => user.displayName.toLowerCase().includes(value)))
        )
      })
    );
  }

  generateReport() {

    if(!this.filterForm.valid) {
      this.searchNotFound = false;
      this.filteredData = [];
      this.totalMark = 0;
      return;
    }

    this.loading.show();

    const filters: Filters = this.filterForm.value;
    let filteredTasks = this.tasks.filter(task => {
      return task.worker && task.worker.iD === filters.worker.iD && task.state === TaskStateTypes.FINISHED;
    });

    if(filters.dateFrom) {
      let time = this.getUtcTime(filters.dateFrom, '00:00:00');
      filteredTasks = filteredTasks.filter((task: Task) => task.datetime >= time);
    }

    if(filters.dateTo) {
      let time = this.getUtcTime(filters.dateTo, '23:59:59');
      filteredTasks = filteredTasks.filter((task: Task) => task.datetime <= time);
    }

    const operations: Observable<FilteredData>[] = filteredTasks.map(
      task => task.finishedOperations.pipe(
        take(1),
        map(operations => {
          return {
            task,
            operations: operations.map(o => o.operationType.shortName).join(', '),
            totalMarks: operations.map(o => o.mark).reduce((p, c) => p + c, 0)
          };
        })
      )
    );

    if(operations.length) {
      forkJoin(operations).subscribe(allOperations => {
        this.totalMark = allOperations.map(data => data.totalMarks).reduce((p, c) => p + c, 0);
        this.filteredData = allOperations;
        this.searchNotFound = false;
        this.loading.hide();
      });
    } else {
      this.searchNotFound = true;
      this.filteredData = [];
      this.loading.hide();
      this.totalMark = 0;
    }
  }

  downloadReport() {

    if(!this.filteredData.length) return;

    const escape = v => v.replace(/"([^"]+)"/g, '«$1»');
    const createCsvRow = (...cols: string[]): string => cols.map(col => `"${escape(col)}"`).join(';');
    const filters = <Filters>this.filterForm.value;
    const dateFrom = filters.dateFrom ? filters.dateFrom.format(DATE_FORMAT) : '--.--.----';
    const dateTo = filters.dateTo ? filters.dateTo.format(DATE_FORMAT) : '--.--.----';

    const csv = [
      createCsvRow('Исполнитель:', filters.worker.displayName),
      createCsvRow('Период отчета:', `с ${dateFrom} по ${dateTo}`),
      createCsvRow(''),
      createCsvRow(''),
      createCsvRow('Дата', 'Серийный номер', 'Торговая точка', 'Адрес', 'Работы', 'Баллы'),

      ...this.filteredData.map(data => createCsvRow(
        moment(data.task.datetime).format(DATE_FORMAT),
        data.task.machine.serialNumber,
        (data.task.machine.division || '').toString(),
        data.task.machine.division.fullAddress,
        data.operations,
        data.totalMarks.toString()
      )),

      createCsvRow(''),
      createCsvRow(`Итого баллов - ${this.totalMark}`)
    ].join('\n');

    this.saveBlob(new Blob([csv], { type: 'text/csv;charset=utf-8;' }),
      `Отчёт по баллам (${moment().format('YYYYMMDDHHmmss')}).csv`);
  }

  toggleAutocompletePanel(event: MouseEvent, trigger: MatAutocompleteTrigger, formControlName :string) {
    event.stopPropagation();
    this.autocompleteTriggers.forEach(t => {
      if(t.autocomplete.isOpen) {
        t.closePanel();
      } else if(t == trigger) {
        this.filterForm.controls[formControlName].reset();
        t.openPanel();
      }
    });
  }

  private saveBlob(blob: Blob, fileName: string)
  {
    if (typeof navigator.msSaveBlob !== 'undefined') {
      navigator.msSaveBlob(blob, fileName);
      return;
    }

    const tmpLink = document.createElement("a");

    if (typeof tmpLink.download === 'undefined') {
      window.location.href = URL.createObjectURL(blob);
      return;
    }

    tmpLink.href = URL.createObjectURL(blob);
    tmpLink.download = fileName;
    document.body.appendChild(tmpLink);

    tmpLink.addEventListener('click', function(){
      document.body.removeChild(tmpLink);
    }, false);

    tmpLink.click();
  }

  private getUtcTime(m: Moment, time: string) {
    return moment(`${m.format(moment.HTML5_FMT.DATE)} ${time}`).utc().valueOf();
  }

}
