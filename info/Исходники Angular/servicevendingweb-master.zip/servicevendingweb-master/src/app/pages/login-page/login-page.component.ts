import {Component, OnDestroy, OnInit} from '@angular/core';
import {MatDialog, MatDialogRef} from '@angular/material';
import {LoginDialogComponent} from '@app/components/dialogs/login-dialog/login-dialog.component';
import {AuthenticationService} from '@app/services/authentication.service';
import {TasksService} from '@app/services/tasks.service';
import {Router} from '@angular/router';
import * as firebase from 'firebase';
import {from, Subscription} from 'rxjs';
import * as moment from 'moment';
import {take} from 'rxjs/operators';
import {Title} from '@angular/platform-browser';

@Component({
  selector: 'app-login-page',
  templateUrl: './login-page.component.html',
  styleUrls: ['./login-page.component.scss']
})
export class LoginPageComponent implements OnInit, OnDestroy {

  showSpinner = true;
  private _authSubscription: Subscription;
  private _loginDialog: MatDialogRef<LoginDialogComponent>|null;

  constructor(
    private auth: AuthenticationService,
    private tasksService: TasksService,
    protected titleService: Title,
    private dialog: MatDialog,
    private router: Router
  ) {
  }

  ngOnInit() {
    this.titleService.setTitle('Аутентификация');
    this.dialog.closeAll();
    this._authSubscription = this.auth.user.subscribe((user: firebase.User | null) => {
      this.showSpinner = false;

      if(!user) {
        this._loginDialog = LoginDialogComponent.openAsDialog(this.dialog);
        return this._loginDialog;
      }

      const userFireObj = this.tasksService.fireObject<any>(`/users/${user.uid}`);

      from(new Promise((resolve, reject) => {

        userFireObj.snapshotChanges().pipe(take(1)).subscribe(action => {

          if(action.payload.exists()) {
            return resolve();
          }

          userFireObj.set({
            iD: user.uid,
            email: user.email || ' ',
            name: user.displayName || ' ',
            phoneNumber: user.phoneNumber,
            timeChanged: moment.utc().valueOf(),
            role: 0
          }).then(() => { resolve() }, reject);

        });

      })).subscribe(() => {

        return this.router.navigate(['/']);

      });

    });
  }

  ngOnDestroy(): void {
    if(this._loginDialog) {
      this._loginDialog.close();
    }
    this._authSubscription.unsubscribe();
  }
}
