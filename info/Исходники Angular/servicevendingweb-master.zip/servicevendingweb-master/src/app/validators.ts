import {FormControl} from '@angular/forms';
import {Model} from '@app/models';

export class AppValidators {

  static isModel(control: FormControl) {
    if(!control.value) return null;
    const isValid = typeof control.value == 'object' && control.value instanceof Model;
    return !isValid ? {model: true} : null;
  }

  static noWhitespaceValidator(control: FormControl) {
    if(!control.value) return null;
    const isValid = control.value.toString().trim().length > 0;
    return !isValid ? {whitespace: true} : null;
  }

  static phoneValidator() {
    return (control: FormControl) => {
      if(!control.value) return null;
      const val = AppValidators.clearPhone(control);
      return val && !/^\d{10,11}$/.test(val) ? {phone: true} : null;
    };
  }

  static clearPhone(control: FormControl) {
    return (control.value || '').trim().replace(/\D+/g, '');
  }
}
