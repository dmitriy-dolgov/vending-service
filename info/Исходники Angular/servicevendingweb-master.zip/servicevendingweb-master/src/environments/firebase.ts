export const firebaseConfig = {
  apiKey: 'AIzaSyB6MD5f5ZhaGMNoUo6RKY__bnJdsGuT9Lo',
  authDomain: 'servicevending-de9ca.firebaseapp.com',
  databaseURL: 'https://servicevending-de9ca.firebaseio.com',
  projectId: 'servicevending-de9ca',
  storageBucket: 'servicevending-de9ca.appspot.com',
  messagingSenderId: '309202162260',
  appId: '1:309202162260:web:dfcc0ab98062e22fad93c1'
};
