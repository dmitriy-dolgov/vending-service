
import baseEnvironment from './environment.base';

export const environment = {
  ... baseEnvironment,
  production: true
};
