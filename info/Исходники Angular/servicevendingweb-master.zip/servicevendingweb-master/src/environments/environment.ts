// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The fileList of file replacements can be found in `angular.json`.

import baseEnvironment from './environment.base';

export const environment = {
  ... baseEnvironment,
  production: false
};
