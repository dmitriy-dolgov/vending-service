import {MatDateFormats} from '@angular/material';

export const DATETIME_FORMAT = "DD.MM.YYYY HH:mm:ss";
export const DATE_FORMAT = "DD.MM.YYYY";
export const TIME_FORMAT = "HH:mm:ss";
export const LOCALE = 'ru-RU';

export const DATEPICKER_FORMATS: MatDateFormats = {
  parse: {
    dateInput: DATE_FORMAT,
  },
  display: {
    monthYearA11yLabel: 'MMMM YYYY',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: DATE_FORMAT,
    dateInput: DATE_FORMAT,
  }
};
