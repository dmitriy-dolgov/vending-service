export default {
  app: {
    title: 'Сервис вендинга'
  }
};
