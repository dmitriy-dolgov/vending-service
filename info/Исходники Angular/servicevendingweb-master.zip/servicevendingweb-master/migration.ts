import {City, Client, ClientStatuses, ClientStatusType, Division, Machine, MachineModel, Task, TaskOperation} from './src/app/models';
import {DataSnapshot} from '@angular/fire/database/interfaces';
import {firebaseConfig} from './src/environments/firebase';
import * as firebase from 'firebase';
import * as moment from 'moment';

firebase.initializeApp(firebaseConfig);
const database = firebase.database();

type OperationType = {
  iD: string,
  description: string,
  shortName: string,
  defaultMark: number
};

type DivisionType = {
  name: string,
  address: string,
  serialNumber: string,
  regionID: number,
  clientStatus: 'К' | 'З' | 'С',
  clientID: number,
  comment: string
};

type ClientType = {
  name: string,
  address: string,
  serialNumber: string,
  machineModel: string
};

const operationTypes: OperationType[] = Object.values(require('./migrations/operationTypes.json'));
const divisions: DivisionType[] = require('./migrations/divisions.json');
const clients: ClientType[] = require('./migrations/clients.json');

function addOperationTypes(): Promise<void> {
  return Promise.all(operationTypes.map(operationType => {
    return database.ref(`/operationTypes/${operationType.iD}`).set(operationType).then(() => {
      console.log('Add operation type', operationType.description);
      return Promise.resolve();
    });
  })).then(() => Promise.resolve());
}

function addTaskOperations(): Promise<void> {
  return Promise.all([
    database.ref('/serviceOperations').once('value'),
    database.ref('/operationTypes').once('value')
  ]).then(([snapshotServiceOperations, snapshotOperationTypes]) => {

    const taskServiceOperations = <{[taskId: string]: {[taskOperationID: number]: TaskOperation}}>snapshotServiceOperations.val();
    const operationTypes = <{[operationTypeID: string]: OperationType}>snapshotOperationTypes.val();
    const promises: Promise<void>[] = [];

    Object.entries(taskServiceOperations).forEach(([taskId, serviceOperations]: [string, TaskOperation[]]) => {

      Object.values(serviceOperations).forEach((serviceOperation: TaskOperation) => {

        const operationType = operationTypes[serviceOperation.operationTypeID];

        if(operationType) {
          promises.push(snapshotServiceOperations.child(`${taskId}/${serviceOperation.gUID}`).ref.update({
            description: operationType.description,
            mark: operationType.defaultMark
          }).then(() => {
            console.log('Update', operationType.description);
            return Promise.resolve();
          }));
        }

      });

    });

    return Promise.all(promises).then(() => Promise.resolve());
  });
}

function removeTaskOperations(): Promise<void> {
  return database.ref('/serviceOperations').once('value').then(snapshotServiceOperations => {
    const promises: Promise<void>[] = [];
    let i = 0;
    Object.entries(snapshotServiceOperations.val()).forEach(([taskId, serviceOperations]) => {
      Object.values(serviceOperations).forEach((serviceOperation: TaskOperation) => {
        if(!serviceOperation.operationTypeID) {
          promises.push(snapshotServiceOperations.child(`${taskId}/${serviceOperation.gUID}`).ref.remove().then(() => {
            process.stdout.write(`\rRemoved ${++i}`);
          }));
        }
      });
    });
    return Promise.all(promises).then(() => Promise.resolve());
  });
}

function initCityRegions(): Promise<void> {
  const promises: Promise<void>[] = [];
  let cityRegionID = 0;

  Object.values(divisions).forEach((division, i) => {
    if (division.name.trim().toLowerCase() === 'район') {
      ++cityRegionID;
      promises.push(database.ref(`/regions/${cityRegionID}`).set({
        description: `Район ${cityRegionID}`,
        iD: cityRegionID
      }));
    } else {
      division.regionID = cityRegionID;
    }
  });

  return Promise.all(promises).then(() => Promise.resolve());
}

function addClients(): Promise<void> {
  return database.ref('/clients').remove().then(() => {

    Promise.all(clients.map(c => c.name).filter((it, i, arr) => arr.indexOf(it) === i).map((description, i) => {

      const serialNumber = clients.find(c => c.name == description).serialNumber.toString();
      const division = divisions.find(c => (c.serialNumber || '').toString() == serialNumber);
      let clientStatus: ClientStatusType = ClientStatuses.STANDARD;

      switch (division ? division.clientStatus : 'С') {
        case 'К': clientStatus = ClientStatuses.CRUCIAL; break;
        case 'З': clientStatus = ClientStatuses.SIGNIFICANT; break;
        default: clientStatus = ClientStatuses.STANDARD;
      }

      return database.ref(`/clients/${i + 1}`)
        .set({iD: i + 1, description, status: clientStatus})
        .then(() => {
          console.log('Add ', description);
          return Promise.resolve();
        });

    }));

  });
}

function addMachineModels(): Promise<void> {
  return database.ref('/machineModels').once('value').then(snapshot => {
    const machineModels = (<MachineModel[]>snapshot.val()).filter(m => !!m);
    const keys = machineModels.map(it => Number(it.iD)).sort((a, b) => a - b);
    let newModelId = (keys.length ? keys.pop() : 0) + 1;

    return Promise.all(
      clients.map(c => c.machineModel)
        .filter((it, i, arr) => arr.indexOf(it) === i)
        .filter(modelName => !machineModels.find(model => model.description == modelName))
        .map(modelName => {
          database.ref(`/machineModels/${newModelId}`)
            .set({iD: newModelId, description: modelName})
            .then(() => {
              console.log('Add ', modelName);
              return Promise.resolve();
            });
          newModelId++;
          return Promise.resolve();
        })
    ).then(() => Promise.resolve());
  });
}

function updateClassifiers(): Promise<void> {

  initCityRegions();

  return Promise.all(
    ['cities', 'divisions', 'machineModels', 'machines', 'clients'].map(
      list => database.ref(`/${list}`).once('value')
    )
  ).then((
    [
      snapshotSities,
      snapshotDivisions,
      snapshotMachineModels,
      snapshotMachines,
      snapshotClients
    ]: DataSnapshot[]
  ) => {

    const city = (<City[]>snapshotSities.val()).find(c => c && /^Казань$/i.test(c.description));
    const existedDivisions = (<Division[]>Object.values(snapshotDivisions.val())).filter(division => division.cityID == city.iD);
    const divisionIds = existedDivisions.map(m => Number(m.iD)).sort((a, b) => a - b);
    let lastDivisionID = (divisionIds.length ? divisionIds.pop() : 0);

    const existedMachineModels = (<MachineModel[]>Object.values(snapshotMachineModels.val())).filter(it => !!it);
    const existedMachines = (<Machine[]>Object.values(snapshotMachines.val())).filter(it => !!it);
    const existedClients = (<Client[]>Object.values(snapshotClients.val())).filter(it => !!it);

    const divisionKeys = existedDivisions.map(it => Number(it.iD)).sort((a, b) => a - b);
    let lastDivisionId = (divisionKeys.length ? divisionKeys.pop() : 0);

    const machineKeys = existedMachines.map(it => Number(it.iD)).sort((a, b) => a - b);
    let lastMachineId = (machineKeys.length ? machineKeys.pop() : 0);

    return Promise.all(divisions.filter(d => !!d.regionID).map(division => {

      const serialNumber = (division.serialNumber || '').toString();
      const client = !serialNumber ? null : clients.find(c => (c.serialNumber || '').toString() === serialNumber);

      division.clientID = !client ? 0 : existedClients.find(c => c && c.description == client.name).iD;

      const existedDivision = existedDivisions.find(d => {
        return d.address.toLowerCase() == division.address.toLowerCase().trim() && (
          d.description.toLowerCase() == division.name.toLowerCase().trim() ||
          d.description.toLowerCase() == division.address.toLowerCase().trim()
        );
      });

      const divisionData = {
        iD: existedDivision ? existedDivision.iD : ++lastDivisionId,
        description: division.name.trim(),
        regionID: division.regionID,
        clientID: division.clientID
      };

      if(!existedDivision) {
        existedDivisions.push(<Division>Object.assign(divisionData, {
          description: division.name.trim(),
          address: division.address.trim(),
          cityID: city.iD,
          gPSLocationX: 0,
          gPSLocationY: 0,
          timeChanged: 0
        }));
      }

      return database.ref(`/divisions/${divisionData.iD}`).update(divisionData).then(() => {

        console.log(existedDivision ? 'Update' : 'Add', 'division', divisionData.iD);

        const machineModel = client
          ? existedMachineModels.find(m => m.description == client.machineModel)
          : existedMachineModels.find(m => m.description == 'Nescafe Alegria 10/60');

        if(
          existedMachines.find(m => {
            return m.serialNumber.toString() == serialNumber
              && Number(m.divisionID) == divisionData.iD
              && Number(m.modelID) == machineModel.iD;
          })
        ){
          return Promise.resolve();
        }

        const newMachine = {
          iD: ++lastMachineId,
          description: machineModel.description,
          comment: division.comment.trim(),
          serialNumber: serialNumber,
          divisionID: divisionData.iD,
          modelID: machineModel.iD,
          serviceStateID: 1,
          timeChanged: 0,
          stateID: 3,
          typeID: 2
        };

        existedMachines.push(<Machine>newMachine);

        return database.ref(`/machines/${newMachine.iD}`).set(newMachine).then(() => {
          console.log('    Add machine', divisionData.iD, newMachine.description);
          return Promise.resolve();
        });

      });

    })).then(() => Promise.resolve());

  });
}

function restoreClassifiers(): Promise<void> {
  const divisions: {[iD: string]: Division} = {};
  const machines: {[iD: string]: Machine} = {};

  Object.values(<(Division|null)[]>require('./migrations/divisions.backup.json'))
    .filter(d => !!d).forEach(d => {
    if(typeof d.regionID == 'undefined') {
      d.regionID = 0;
    }
    divisions[d.iD] = d;
  });

  Object.values(<(Machine|null)[]>require('./migrations/machines.backup.json'))
    .filter(m => !!m).forEach(m => {
    if(typeof m.comment == 'undefined') {
      m.comment = '';
    }
    machines[m.iD] = m;
  });

  return Promise.all([
    database.ref('/divisions').set(divisions),
    database.ref('/machines').set(machines)
  ]).then(() => updateClassifiers());
}

function bugFixTaskOperationsTypeID(): Promise<void> {
  return Promise.all([
    database.ref('/serviceOperations').once('value'),
    database.ref('/operationTypes').once('value'),
  ]).then((
    [
      serviceOperationsSnapshot,
      operationTypesSnapshot
    ]: DataSnapshot[]
  ) => {

    const operationTypes: OperationType[] = Object.values(operationTypesSnapshot.val());
    const promises = [];

    Object.entries(serviceOperationsSnapshot.val()).forEach(([taskId, serviceOperations]) => {
      Object.values(serviceOperations).forEach((operation: TaskOperation) => {
        if(!operation.operationTypeID) {
          const operationType = operationTypes.find(type => type.description == operation.description);
          if(operationType) {
            promises.push(
              serviceOperationsSnapshot.child(`${taskId}/${operation.gUID}`).ref.update({
                operationTypeID: operationType.iD
              }).then(() => {
                console.log(`Add operationTypeID ${operation.description}`);
                return Promise.resolve();
              })
            );
          } else {
            console.warn(`Operation type "${operation.description}" not found!`);
          }
        }
      });
    });

    return Promise.all(promises).then(() => Promise.resolve());

  });
}


function listTotals() {
  database.ref('/').once('value').then(snapshot => {
    Object.entries(snapshot.val()).forEach(([name, items]: [string, any[]|{}]) => {
      console.log(`${name}: ${Object.values(items).length}`);
    });
    process.exit();
  });
}


function setDivisionGeoCoordinates() {
  const request = require('request-promise');

  Promise.all([
    database.ref('/divisions').once('value'),
    database.ref('/cities').once('value')
  ]).then(async ([snapshotDivisions, snapshotCities]) => {

    const cities: {[id: string]: City} = snapshotCities.val();
    const divisions = (<Division[]>Object.values(snapshotDivisions.val())); // .filter(d => !d.gPSLocationX || !d.gPSLocationY);
    let successed = 0;

    for(let i = 0, division: Division; (division = divisions[i]); i++) {

      const address = !/(^\s*|\s+|,\s*)г\./i.test(division.address)
        ? `г. ${cities[division.cityID].description}, ${division.address}`
        : division.address;

      const resp = await request({
        method: 'GET',
        json: true,
        uri: 'https://geocode-maps.yandex.ru/1.x/',
        qs: {
          apikey: '658f67a2-fd77-42e9-b99e-2bd48c4ccad4',
          geocode: address,
          format: 'json'
        }
      });

      const geoObjectCollection = resp.response.GeoObjectCollection;
      const featureMember = <Array<any> | undefined>geoObjectCollection.featureMember;
      let coordinates = [0, 0];

      if(featureMember && featureMember.length) {
        coordinates = (<string>featureMember[0].GeoObject.Point.pos).split(/\s+/).map(parseFloat);
        console.log(++successed, coordinates);
      }

      await database.ref(`/divisions/${division.iD}`).update({
        gPSLocationX: coordinates[0],
        gPSLocationY: coordinates[1],
      });

    }

    process.exit();

  });
}

// setDivisionGeoCoordinates();


// listTotals();

// restoreClassifiers().then(() => process.exit());
// updateClassifiers().then(() => process.exit());
// bugFixTaskOperationsTypeID().then(() => process.exit());









Promise.all([
  database.ref('/divisions').once('value'),
  database.ref('/machines').once('value'),
  database.ref('/tasks').once('value'),
  database.ref('/cities').once('value'),
]).then((
  [
    divisionsSnapshot,
    machinesSnapshot,
    tasksSnapshot,
    citiesSnapshot,
  ]: DataSnapshot[]
) => {

  const _divisions: Division[] = Object.values(divisionsSnapshot.val());
  const machines: Machine[] = Object.values(machinesSnapshot.val());
  const tasks: Task[] = Object.values(tasksSnapshot.val());
  const cities: City[] = Object.values(citiesSnapshot.val());

  /*return;

  const city = cities.find(c => c && /^Казань$/i.test(c.description));


  _divisions
    .filter(division => Number(division.cityID) === Number(city.iD))
    .forEach((division, i) => {

      machines
        .filter(m => Number(m.divisionID) === Number(division.iD))
        .filter(machine => {
          return machine.serialNumber && !divisions.find(d => {
            return d.serialNumber && d.serialNumber.toString() === machine.serialNumber.toString();
          })
        })
        .forEach(machine => {
          console.log(`${i}) ${division.address} ${machine.serialNumber} (${tasks.filter(t => Number(t.machineID) == Number(machine.iD)).length})`);
        });

        // database.ref(`/divisions/${division.iD}`).remove()

    })
  ;

  process.exit();
  return;

  console.log('divisions', _divisions.length);
  console.log('machines', machines.length);
  process.exit();
  return;*/

  const invalidDivisions = _divisions.filter(d => {
    return !machines.find(m => Number(m.divisionID) === Number(d.iD));
  });

  const invalidMachines = machines.filter(m => {
    return !m.divisionID || !_divisions.find(d => Number(d.iD) === Number(m.divisionID));
  });

  const invalidTasks = tasks.filter(t => {
    return !t.machineID || !machines.find(m => Number(m.iD) === Number(t.machineID));
  });

  /*Promise.all(invalidDivisions.map((d, i) => {
    return database.ref(`/divisions/${d.iD}`).remove().then(() => {
      console.log(`\rRemoved ${i}`);
      return Promise.resolve(true);
    });
  })).then(() => {
    process.exit();
  });*/

  /*Promise.all(
    [].concat.apply([],
      invalidMachines.map(m => [].concat(
        // Удаление битой записи оборудования
        database.ref(`/machines/${m.iD}`).remove(),
        // Удаление задач, связанных с удаляемым оборудованием
        tasks.filter(t => Number(t.machineID) === Number(m.iD)).map(t => database.ref(`/tasks/${t.gUID}`).remove())
      ))
    )
  ).then(() => {
    process.exit();
  });*/

});

